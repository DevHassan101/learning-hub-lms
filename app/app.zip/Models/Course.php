<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    use HasFactory;
    protected $guarded = ['id'];

    public function lessons() {
        return $this->hasMany(Lesson::class, 'course_id');
    }
    public function examQuestions() {
        return $this->hasMany(ExamQuestion::class);
    }
    public function quizQuestions() {
        return $this->hasMany(QuizQuestion::class);
    }
    public function flashCards() {
        return $this->hasMany(FlashCard::class);
    }

    public function timerQuizes() {
        return $this->hasMany(QuizQuestion::class)->where('type','time restricted');
    }
    public function normalQuizes() {
        return $this->hasMany(QuizQuestion::class)->where('type','normal');
    }

    public function enrollments() {
        return $this->hasMany(UserCourse::class);
    }
}
