<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\ExamQuestion;
use App\Models\Lesson;
use App\Models\Plan;
use App\Models\QuizQuestion;
use App\Models\User;
use App\Models\UserCourse;
use App\Models\UserExam;
use App\Models\UserExamAnswer;
use App\Models\UserLesson;
use App\Models\UserQuiz;
use App\Models\UserQuizAnswer;
use App\Models\UserSubscription;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Stripe\Charge;
use Stripe\Stripe;
use Unicodeveloper\Paystack\Facades\Paystack;
use Srmklive\PayPal\Services\PayPal as PayPalClient;

class WebController extends Controller
{
    public function index()
    {
        $courses = Course::with('lessons')->get();
        $plans = Plan::get();
        return view('website.pages.index', compact('courses', 'plans'));
    }
    public function course()
    {
        $courses = Course::with('lessons')->get();
        return view('website.pages.course', compact('courses'));
    }
    public function courseDetail($slug)
    {
        $name = str_replace('-', ' ', $slug);
        $course = Course::with('lessons')->where('title', $name)->firstOrFail();
        return view('website.pages.course-detail', compact('course'));
    }
    public function courseQuiz($slug)
    {
        $course = Course::where('slug', $slug)->firstOrFail();
        $userCourse = UserCourse::where('user_id', Auth::user()->id)->where('course_id', $course->id)->first();
        if (!$userCourse) {
            return redirect()->back()->with('error', 'You have to enroll in this course.');
        }
        return view('website.pages.course-quiz', compact('slug', 'course'));
    }
    public function startQuiz($course, $type)
    {
        $course = Course::where('slug', $course)->firstOrFail();
        $quizQuestions = QuizQuestion::where('course_id', $course->id)->where('type', str_replace('-', ' ', $type))->get();
        if (count($quizQuestions) == 0) {
            return redirect()->back()->with('error', 'Quiz not available');
        }
        return view('website.pages.start-quiz', compact('course', 'quizQuestions', 'type'));
    }
    public function quizResult($userQuiz)
    {
        $userQuiz = UserQuiz::where('user_quiz_id', $userQuiz)->firstOrFail();

        $totalQuestions = QuizQuestion::where([
            ['course_id', $userQuiz->course_id],
            ['type', $userQuiz->type]
        ])->count();

        $attemptedQuestions = UserQuizAnswer::where('user_quiz_id', $userQuiz->id)
            ->with('quizQuestion:id,answer')->get();

        $correctAnswers = $attemptedQuestions->filter(function ($attempt) {
            return $attempt->quizQuestion->answer === $attempt->answer;
        })->count();

        $percentage = $totalQuestions > 0 ? ($correctAnswers / $totalQuestions) * 100 : 0;

        return view('website.pages.quiz-result', compact('totalQuestions', 'attemptedQuestions', 'correctAnswers', 'percentage', 'userQuiz'));
    }
    public function quizResultAnswers($userQuiz)
    {
        $userQuiz = UserQuiz::where('user_quiz_id', $userQuiz)->firstOrFail();
        $quizQuestions = QuizQuestion::where([
            ['course_id', $userQuiz->course_id],
            ['type', $userQuiz->type]
        ])->get();
        foreach ($quizQuestions as $quizQuestion) {
            $userQuizAnswer = UserQuizAnswer::where('user_quiz_id', $userQuiz->id)->where('quiz_question_id', $quizQuestion->id)->first();
            $quizQuestion->userAnswer = $userQuizAnswer ? $userQuizAnswer->answer : '';
        }

        $totalQuestions = count($quizQuestions);
        $userQuizAnswers = UserQuizAnswer::where('user_quiz_id', $userQuiz->id)
            ->with('quizQuestion:id,answer')->get();
        $correctAnswers = $userQuizAnswers->filter(function ($attempt) {
            return $attempt->quizQuestion->answer === $attempt->answer;
        })->count();
        $percentage = $totalQuestions > 0 ? ($correctAnswers / $totalQuestions) * 100 : 0;
        return view('website.pages.quiz-result-answers', compact('userQuiz', 'quizQuestions', 'correctAnswers', 'percentage'));
    }
    public function courseExam($slug)
    {
        $course = Course::where('slug', $slug)->firstOrFail();
        $userCourse = UserCourse::where('user_id', Auth::user()->id)->where('course_id', $course->id)->first();
        if (!$userCourse) {
            return redirect()->back()->with('error', 'You have to enroll in this course.');
        }
        return view('website.pages.course-exam', compact('course', 'slug'));
    }
    public function startExam($slug)
    {
        $course = Course::where('slug', $slug)->firstOrFail();
        if (count($course->examQuestions) == 0) {
            return redirect()->back()->with('error', 'Exam not available');
        }
        $examId = Str::uuid();
        UserExam::create([
            'user_exam_id' => $examId,
            'user_id' => Auth::user()->id,
            'course_id' => $course->id,
            'start_time' => now()
        ]);
        return redirect('exam/' . $examId);
    }
    public function startExam2($examId)
    {
        $userExam = UserExam::where('user_exam_id', $examId)->firstOrFail();
        $course = Course::findOrFail($userExam->course_id);
        $examQuestions = ExamQuestion::where('course_id', $course->id)->get();
        return view('website.pages.start-exam', compact('examId', 'course', 'examQuestions'));
    }
    public function submitExam($examId, Request $request)
    {
        $userExam = UserExam::where('user_exam_id', $examId)->firstOrFail();
        $userExam->update([
            'end_time' => now()
        ]);
        if ($request->answer) {
            foreach ($request->answer as $questionId => $answer) {
                UserExamAnswer::create([
                    'user_exam_id' => $userExam->id,
                    'exam_question_id' => $questionId,
                    'answer' => $answer
                ]);
            }
        }

        return redirect('course/exam/' . $userExam->user_exam_id . '/result');
    }
    public function examResult($userExam)
    {
        $userExam = UserExam::where('user_exam_id', $userExam)->firstOrFail();

        $totalQuestions = ExamQuestion::where('course_id', $userExam->course_id)->count();

        $attemptedQuestions = UserExamAnswer::where('user_exam_id', $userExam->id)
            ->with('examQuestion:id,answer')->get();

        $correctAnswers = $attemptedQuestions->filter(function ($attempt) {
            return $attempt->examQuestion->answer === $attempt->answer;
        })->count();

        $percentage = $totalQuestions > 0 ? ($correctAnswers / $totalQuestions) * 100 : 0;

        return view('website.pages.exam-result', compact('totalQuestions', 'attemptedQuestions', 'correctAnswers', 'percentage', 'userExam'));
    }
    public function examResultAnswers($userExam)
    {
        $userExam = UserExam::where('user_exam_id', $userExam)->firstOrFail();
        $examQuestions = ExamQuestion::where('course_id', $userExam->course_id)->get();
        foreach ($examQuestions as $examQuestion) {
            $userExamAnswer = UserExamAnswer::where('user_exam_id', $userExam->id)->where('exam_question_id', $examQuestion->id)->first();
            $examQuestion->userAnswer = $userExamAnswer ? $userExamAnswer->answer : '';
        }

        $totalQuestions = count($examQuestions);
        $userExamAnswers = UserExamAnswer::where('user_exam_id', $userExam->id)
            ->with('examQuestion:id,answer')->get();
        $correctAnswers = $userExamAnswers->filter(function ($attempt) {
            return $attempt->examQuestion->answer === $attempt->answer;
        })->count();
        $percentage = $totalQuestions > 0 ? ($correctAnswers / $totalQuestions) * 100 : 0;
        return view('website.pages.exam-result-answers', compact('userExam', 'examQuestions', 'correctAnswers', 'percentage'));
    }
    public function courseLectures($course, $lecture)
    {
        $course = Course::with('lessons')->where('slug', $course)->firstOrFail();
        $userCourse = UserCourse::where('user_id', Auth::user()->id)->where('course_id', $course->id)->first();
        if (!$userCourse) {
            return redirect()->back()->with('error', 'You have to enroll in this course.');
        }
        $lecture = Lesson::with('course')->where('slug', $lecture)->firstOrFail();
        return view('website.pages.course-lectures', compact('lecture', 'course', 'userCourse'));
    }
    public function courseLecturesPdf($course, $lecture)
    {
        $lecture = Lesson::with('course')->where('slug', $lecture)->firstOrFail();
        $course = Course::with('lessons')->where('slug', $course)->firstOrFail();
        $userCourse = UserCourse::where('user_id', Auth::user()->id)->where('course_id', $course->id)->first();
        if (!$userCourse) {
            return redirect()->back()->with('error', 'You have to enroll in this course.');
        }
        // return redirect($lecture->attachments);
        return view('website.pages.course-lectures-pdf', compact('lecture','userCourse'));
    }
    public function courseEnroll($course)
    {
        $user = Auth::user();
        $course = Course::where('slug', $course)->firstOrFail();

        if (UserCourse::where('course_id', $course->id)->where('user_id', $user->id)->exists()) {
            return redirect()->back()->with('error', 'You are already enrolled in this course.');
        }

        if ($user->activeSubscription()) {
            UserCourse::create([
                'user_course_id' => Str::uuid(),
                'course_id' => $course->id,
                'user_id' => $user->id
            ]);

            return redirect()->back()->with('success', 'Course enrolled successfully.');
        }

        return redirect('/plan');
    }



    public function submitQuiz(Course $course, Request $request)
    {
        $userQuiz = UserQuiz::create([
            'user_quiz_id' => Str::uuid(),
            'course_id' => $course->id,
            'user_id' => Auth::user()->id,
            'type' => str_replace('-', ' ', strtolower($request->type))
        ]);
        if ($request->answer) {
            foreach ($request->answer as $questionId => $answer) {
                UserQuizAnswer::create([
                    'user_quiz_id' => $userQuiz->id,
                    'quiz_question_id' => $questionId,
                    'answer' => $answer
                ]);
            }
        }

        return redirect('course/quiz/' . $userQuiz->user_quiz_id . '/result');
    }
    public function userLesson(Request $request)
    {
        if (UserLesson::where('lesson_id', $request->lessonId)->where('user_id', Auth::user()->id)->exists()) {
            return response()->json([
                'error' => true,
                'message' => 'Lecture already watched'
            ]);
        }
        UserLesson::create([
            'lesson_id' => $request->lessonId,
            'user_course_id' => $request->userCourseId,
            'user_id' => Auth::user()->id
        ]);
        $userCourse = UserCourse::find($request->userCourseId);
        if (count($userCourse->course->lessons) == count($userCourse->userLessons)) {
            $userCourse->status = 'completed';
            $userCourse->update();
        }
        return response()->json([
            'error' => false,
            'message' => 'Lecture added successfully'
        ]);
    }

    public function processPayment(Request $request)
    {
        $request->validate([
            'payment_method' => 'required',
        ]);
        $startDate = Carbon::now();
        $plan = Plan::findOrFail($request->plan);
        switch ($plan->name) {
            case 'Monthly':
                $endDate = Carbon::now()->addMonth(1);
                break;
            case 'Quaterly':
                $endDate = Carbon::now()->addMonths(3);
                break;
            case 'Annual':
                $endDate = Carbon::now()->addYear(1);
                break;
            default:
                $endDate = Carbon::now();
                break;
        }
        if (Auth::user()->activeSubscription()) {
            $subscription  = Auth::user()->activeSubscription();
            $subscription->update([
                'status' => 'expired',
                'expired_at' => Carbon::now(),
            ]);
        }

        $userSubscription = UserSubscription::create([
            'user_subscription_id' => Str::uuid(),
            'user_id' => Auth::user()->id,
            'plan_id' => $request->plan,
            'payment_method' => $request->payment_method,
            'start_at' => $startDate,
            'end_at' => $endDate,
        ]);

        $paymentMethod = $request->payment_method;

        if ($paymentMethod === 'stripe') {
            return $this->processStripePayment($request, $userSubscription);
        } elseif ($paymentMethod === 'paystack') {
            return $this->processPaystackPayment($request, $userSubscription);
        } elseif ($paymentMethod === 'paypal') {
            return $this->processPaypalPayment($request, $userSubscription);
        } else {
            return back()->with('error', 'Invalid payment method selected.');
        }
    }

    // ✅ Stripe Payment
    private function processStripePayment(Request $request, $userSubscription)
    {
        Stripe::setApiKey(env('STRIPE_SECRET'));
        try {
            Charge::create([
                "amount" => $userSubscription->plan->price * 100,
                "currency" => "usd",
                "source" => $request->stripeToken,
                "description" => "Payment for " . $userSubscription->plan->name . " package"
            ]);
            $userSubscription->update([
                'status' => 'active'
            ]);
            return redirect('courses')->with('success', 'Stripe payment successful!');
        } catch (\Exception $e) {
            $userSubscription->update([
                'status' => 'failed'
            ]);
            return back()->with('error', 'Stripe payment failed: ' . $e->getMessage());
        }
    }

    // ✅ Paystack Payment
    private function processPaystackPayment(Request $request)
    {
        try {
            return Paystack::getAuthorizationUrl()->redirectNow();
        } catch (\Exception $e) {
            return back()->with('error', 'Paystack payment failed: ' . $e->getMessage());
        }
    }

    // ✅ PayPal Payment
    private function processPaypalPayment(Request $request)
    {
        $paypal = new PayPalClient;
        $paypal->setApiCredentials(config('paypal'));
        $paypalToken = $paypal->getAccessToken();

        $response = $paypal->createOrder([
            "intent" => "CAPTURE",
            "purchase_units" => [
                [
                    "amount" => [
                        "currency_code" => env('PAYPAL_CURRENCY'),
                        "value" => "10.00"
                    ]
                ]
            ]
        ]);

        if (isset($response['id']) && $response['status'] == "CREATED") {
            foreach ($response['links'] as $link) {
                if ($link['rel'] === 'approve') {
                    return redirect()->away($link['href']);
                }
            }
        }

        return back()->with('error', 'PayPal payment failed.');
    }
}
