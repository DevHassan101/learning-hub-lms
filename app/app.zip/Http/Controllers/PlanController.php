<?php

namespace App\Http\Controllers;

use App\Models\Plan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PlanController extends Controller
{
    function index()
    {
        $plans = Plan::get();
        return view('admin.plan.index', compact('plans'));
    }

    function update(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required',
            'price' => 'required|numeric',
        ]);

        Plan::findOrFail($request->id)->update($validatedData);
        return redirect()->back()->with('success', 'Plan updated successfully.');
    }


    function selectPlan()
    {
        $plans = Plan::get();
        return view('website.pages.select-plan', compact('plans'));
    }
    function payment($plan)
    {
        $plan = Plan::where('name', $plan)->firstOrFail();
        return view('website.pages.payment', compact('plan'));
    }
}

