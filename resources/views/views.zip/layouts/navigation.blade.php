<div :class="sidebarOpen ? 'block' : 'hidden'" @click="sidebarOpen = false"
    class="fixed z-20 inset-0 bg-black opacity-50 transition-opacity lg:hidden"></div>

<div :class="sidebarOpen ? 'translate-x-0 ease-out' : '-translate-x-full ease-in'"
    class="shadow-2xl fixed z-30 inset-y-0 left-0 w-64 transition duration-300 transform bg-[#DFDCF3] overflow-y-auto lg:translate-x-0 lg:static lg:inset-0">
    <div class="flex items-center justify-center my-3">
        <div class="flex items-center">
            <a href="{{ url('/') }}">
                <img src="{{ asset('logo.png') }}" height="70px" width="100px" alt="">
            </a>
            {{-- <svg class="h-12 w-12" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M364.61 390.213C304.625 450.196 207.37 450.196 147.386 390.213C117.394 360.22 102.398 320.911 102.398 281.6C102.398 242.291 117.394 202.981 147.386 172.989C147.386 230.4 153.6 281.6 230.4 307.2C230.4 256 256 102.4 294.4 76.7999C320 128 334.618 142.997 364.608 172.989C394.601 202.981 409.597 242.291 409.597 281.6C409.597 320.911 394.601 360.22 364.61 390.213Z" fill="#4C51BF" stroke="#4C51BF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M201.694 387.105C231.686 417.098 280.312 417.098 310.305 387.105C325.301 372.109 332.8 352.456 332.8 332.8C332.8 313.144 325.301 293.491 310.305 278.495C295.309 263.498 288 256 275.2 230.4C256 243.2 243.201 320 243.201 345.6C201.694 345.6 179.2 332.8 179.2 332.8C179.2 352.456 186.698 372.109 201.694 387.105Z" fill="white"/>
            </svg>

            <span class="text-white text-2xl mx-2 font-semibold">{{ __('Dashboard') }}</span> --}}
        </div>
    </div>

    <nav class="mt-10" x-data="{ isMultiLevelMenuOpen: false }">
        <div class="rounded-xl border border-[#4128E2] flex items-center mx-3 p-3">
            <svg width="49" height="49" viewBox="0 0 49 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M24.5 49C38.0309 49 49 38.0311 49 24.5C49 10.969 38.0309 0 24.5 0C10.969 0 0 10.969 0 24.5C0 38.0311 10.969 49 24.5 49Z"
                    fill="white" />
                <path
                    d="M24.4999 12.0781C19.4284 12.0781 15.3124 16.1941 15.3124 21.2655C15.3124 26.239 19.2079 30.2815 24.3774 30.4285C24.4509 30.4285 24.5489 30.4285 24.5979 30.4285C24.6469 30.4285 24.7204 30.4285 24.7694 30.4285C24.7939 30.4285 24.8184 30.4285 24.8184 30.4285C29.7674 30.257 33.6629 26.239 33.6874 21.2655C33.6874 16.1941 29.5714 12.0781 24.4999 12.0781Z"
                    fill="#102935" />
                <path
                    d="M41.1139 42.5073C36.7529 46.5253 30.9219 48.9998 24.5029 48.9998C18.0839 48.9998 12.2528 46.5253 7.89185 42.5073C8.47985 40.2778 10.0723 38.2443 12.3998 36.6763C19.0884 32.2173 29.9664 32.2173 36.6059 36.6763C38.9579 38.2443 40.5259 40.2778 41.1139 42.5073Z"
                    fill="#102935" />
            </svg>
            <span class="ml-3">
                Admin
            </span>
        </div>
        <x-nav-link href="{{ route('users.index') }}" :active="request()->routeIs('users.index')">
            {{ __('User Managment') }}
        </x-nav-link>

        <x-nav-link href="{{ route('course.index') }}" :active="request()->routeIs('course.index')">
            {{ __('Course Management') }}
        </x-nav-link>

        <x-nav-link href="{{ route('program.index') }}" :active="request()->routeIs('program.index')">
            {{ __('Manage Programs') }}
        </x-nav-link>

        <x-nav-link href="{{ route('flash-card.index') }}" :active="request()->routeIs('flash-card.index')">
            {{ __('Flash card') }}
        </x-nav-link>

        <x-nav-link href="{{ route('progress.index') }}" :active="request()->routeIs('progress.index')">
            {{ __('Progress Tracking & Reporting') }}
        </x-nav-link>

        <x-nav-link href="{{ route('blog.index') }}" :active="request()->routeIs('blog.index')">
            {{ __('Blogs') }}
        </x-nav-link>

        <x-nav-link href="{{ route('contact.index') }}" :active="request()->routeIs('contact.index')">
            {{ __('Contact us') }}
        </x-nav-link>

        <x-nav-link href="{{ route('notification.index') }}" :active="request()->routeIs('notification.index')">
            {{ __('Notification Management') }}
        </x-nav-link>

        {{-- <x-nav-link href="{{ route('manage-subscription.index') }}" :active="request()->routeIs('manage-subscription.index')">
            {{ __('Management Subscription') }}
        </x-nav-link> --}}
    </nav>
</div>
