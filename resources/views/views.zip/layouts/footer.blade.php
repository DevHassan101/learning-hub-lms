<header class="z-20 flex justify-center items-center py-4 px-6 bg-[#DFDCF3] shadow-2xl">

    <span class="text-[15px] text-center">
        Copyright @ 2024 Quiz Portal, All Rights Reserved
    </span>
</header>
