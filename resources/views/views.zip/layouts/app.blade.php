<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="icon" type="image/x-icon" href="{{asset('icon.png')}}">
    <title>@yield('title')</title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Roboto:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <style>
        body {
            font-family: "Roboto", serif;
            color: #102935
        }
    </style>
    @stack('head')
</head>

<body>
    <div x-data="{ sidebarOpen: false }" class="flex h-screen bg-[#DFDCF3] font-roboto">
        @include('layouts.navigation')

        <div class="flex overflow-hidden flex-col flex-1">
            @include('layouts.header')

            <main class="overflow-y-auto overflow-x-hidden flex-1 bg-[#DFDCF3]">
                <div class="container px-6 py-8 mx-auto h-full">
                    @if (isset($header))
                        <h3
                            class="mb-4 text-[22px] sm:text-[26px] md:text-[30px] xl:text-[36px] font-semibold text-[#102935]">
                            {{ $header }}
                        </h3>
                    @endif

                    {{ $slot }}
                </div>
            </main>
            @include('layouts.footer')
        </div>
    </div>

    <div id="delete-modal"
        class="h-screen hidden flex items-center justify-center w-full bg-black bg-opacity-15 absolute top-0 bottom-0 right-0 z-[100]">
        <div class="bg-white rounded-xl p-10 min-w-[350px] shadow-2xl">
            <form action="" id="delete-form" method="post">
                @csrf
                @method('DELETE')
                <center>
                    <svg width="100px" height="100px" viewBox="0 0 24 24" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 11V17" stroke="#6956E7" stroke-width="1" stroke-linecap="round"
                            stroke-linejoin="round" />
                        <path d="M14 11V17" stroke="#6956E7" stroke-width="1" stroke-linecap="round"
                            stroke-linejoin="round" />
                        <path d="M4 7H20" stroke="#6956E7" stroke-width="1" stroke-linecap="round"
                            stroke-linejoin="round" />
                        <path d="M6 7H12H18V18C18 19.6569 16.6569 21 15 21H9C7.34315 21 6 19.6569 6 18V7Z"
                            stroke="#6956E7" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5V7H9V5Z" stroke="#6956E7"
                            stroke-width="1" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </center>
                <p class="my-3 text-center">
                    Do you really want to delete this <span id="object">user</span>?
                </p>
                <div class="flex justify-around">
                    <button type="submit"
                        class="py-2 px-7 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500">Yes</button>
                    <button type="button" id="close-delete-modal"
                        class="py-2 px-7 text-center bg-red-500 rounded-xl text-white text-[16px] font-semibold hover:bg-red-600">No</button>
                </div>
            </form>
        </div>
    </div>
    @stack('script')

    <script>
        $('#close-delete-modal').click(function(e) {
            e.preventDefault();
            $('#delete-modal').addClass('hidden');
            $('#delete-modal').removeClass('flex');
            $('#delete-form').attr('action', null);
        });
        const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            }
        });
    </script>
    @session('success')
        <script>
            Toast.fire({
                icon: "success",
                title: "{{ session('success') }}"
            });
        </script>
    @endsession
</body>

</html>
