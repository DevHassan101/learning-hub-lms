<x-guest-layout>
    <a href="{{ url('/') }}" class="flex justify-center items-center">
        <img src="{{ asset('logo.png') }}" alt="">
        {{-- <x-application-logo class="w-20 h-20 fill-current text-gray-500" /> --}}
    </a>
    <h1 class="text-center font-medium text-[74px] mt-5">
        Welcome
    </h1>
    <p class="text-center text-[16px] ">
        Sign up to access <a href="#" class="hover:underline font-bold">ClinEd Learning Hub</a> content
    </p>
    <!-- Session Status -->
    <x-auth-session-status class="mb-4" :status="session('status')" />

    <form method="POST" action="{{ route('register') }}" class="mt-5">
        @csrf

        <!-- Name -->
        <div>
            <x-input-label for="name" :value="__('Full Name')" />
            <x-text-input type="text" name="name" id="name" value="{{ old('name') }}" required autofocus
                placeholder="Full Name" />
            <x-input-error :messages="$errors->get('name')" class="mt-2" />
        </div>

        <!-- Email Address -->
        <div class="mt-3">
            <x-input-label for="email" :value="__('Email')" />
            <x-text-input type="email" name="email" id="email" value="{{ old('email') }}"
                placeholder="example@domain.com" required />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
        </div>

        <!-- Password -->
        <div class="mt-3">
            <x-input-label for="password" :value="__('Password')" />
            <div class="relative">
                <x-text-input type="password" name="password" id="password" required autocomplete="current-password"
                    placeholder="Enter your password" />
                <button type="button" onclick="togglePassword(this, 'password')" data-status="text"
                    class="absolute inset-y-0 end-0 flex items-center z-20 px-3 cursor-pointer text-gray-400 rounded-e-md focus:outline-none focus:text-[#442AE2]">
                    <i class="fa-regular fa-eye-slash" id="icon-password"></i>
                </button>
            </div>
            <x-input-error :messages="$errors->get('password')" class="mt-2" />
        </div>

        <!-- Confirm Password -->
        <div class="mt-3">
            <x-input-label for="password_confirmation" :value="__('Confirm Password')" />
            <div class="relative">
                <x-text-input type="password" name="password_confirmation" id="password_confirmation" required
                    placeholder="Re-enter your password" />
                <button type="button" onclick="togglePassword(this, 'password_confirmation')" data-status="text"
                    class="absolute inset-y-0 end-0 flex items-center z-20 px-3 cursor-pointer text-gray-400 rounded-e-md focus:outline-none focus:text-[#442AE2]">
                    <i class="fa-regular fa-eye-slash" id="icon-password_confirmation"></i>
                </button>
            </div>
            <x-input-error :messages="$errors->get('password_confirmation')" class="mt-2" />
        </div>

        <div class="flex flex-col items-center mt-4">
            <x-primary-button class="w-full">
                {{ __('Signup') }}
            </x-primary-button>

            <a class="mt-4 text-sm text-[#102935] hover:underline" href="{{ route('login') }}">
                {{ __('Have an account? ') }}
                <span class="text-[#4228E2]">Login</span>
            </a>
        </div>
    </form>

</x-guest-layout>
