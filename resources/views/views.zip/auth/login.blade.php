@section('title', 'Login')
<x-guest-layout>
    <a href="{{ url('/') }}" class="flex justify-center items-center">
        <img src="{{ asset('logo.png') }}" alt="">
        {{-- <x-application-logo class="w-20 h-20 fill-current text-gray-500" /> --}}
    </a>
    <h1 class="text-center font-medium text-[74px] mt-5">
        Welcome
    </h1>
    <p class="text-center text-[16px] font-bold">
        New to ClinEd Learning Hub? <a href="{{ route('register') }}" class="text-[#442AE2] hover:underline"> Create an
            account now</a>
    </p>

    <!-- Session Status -->
    <x-auth-session-status class="mb-4" :status="session('status')" />

    <form method="POST" action="{{ route('login') }}" class="mt-4">
        @csrf

        <!-- Email Address -->
        <div>
            <x-input-label for="email" :value="__('Email')" />
            <x-text-input placeholder="example@domain.com" type="email" name="email" id="email"
                value="{{ old('email') }}" required autofocus />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
        </div>

        <!-- Password -->
        <div class="mt-3">
            <x-input-label for="password" :value="__('Password')" />
            <div class="relative">
                <x-text-input placeholder="Enter your password" type="password" name="password" id="password" required
                    autocomplete="current-password" />
                <button type="button" onclick="togglePassword(this, 'password')" data-status="text"
                    class="absolute inset-y-0 end-0 flex items-center z-20 px-3 cursor-pointer text-gray-400 rounded-e-md focus:outline-none focus:text-[#442AE2]">
                    <i class="fa-regular fa-eye-slash" id="icon-password"></i>
                </button>
            </div>
            <x-input-error :messages="$errors->get('password')" class="mt-2" />
        </div>

        <div class="flex justify-between mt-4">
            <!-- Remember Me -->
            <div>
                {{-- <label class="inline-flex items-center">
                    <input type="checkbox" class="form-checkbox text-indigo-600" name="remember">
                    <span class="mx-2 text-gray-600 text-sm">{{ __('Remember me') }}</span>
                </label> --}}
            </div>

            <div>
                @if (Route::has('password.request'))
                    <a class="block text-sm fontme text-[#102935] underline"
                        href="{{ route('password.request') }}">{{ __('Forgot password?') }}</a>
                @endif
            </div>
        </div>

        <div class="mt-6">
            <x-primary-button class="w-full">
                {{ __('Login now') }}
            </x-primary-button>
        </div>

    </form>
</x-guest-layout>
