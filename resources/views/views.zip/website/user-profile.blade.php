@extends('layouts.app2')
@section('main')
    <section class="h-[90vh] border border-[#442AE2] rounded-2xl m-5 my-[5vh] p-5 shadow-xl shadow-[#432ae256]">

        <a href="{{ url('/') }}">
            <svg width="18" height="14" viewBox="0 0 18 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd"
                    d="M0.21934 7.29865C0.0788893 7.15802 -2.87182e-07 6.9674 -2.9587e-07 6.76865C-3.04557e-07 6.56989 0.0788893 6.37927 0.21934 6.23865L6.21934 0.238644C6.288 0.164958 6.3708 0.105856 6.4628 0.0648639C6.5548 0.0238721 6.65411 0.00183076 6.75482 5.40642e-05C6.85552 -0.00172264 6.95555 0.0168015 7.04894 0.0545222C7.14233 0.0922429 7.22716 0.148389 7.29838 0.219607C7.3696 0.290826 7.42574 0.37566 7.46346 0.469048C7.50118 0.562437 7.51971 0.662464 7.51793 0.763167C7.51615 0.86387 7.49411 0.963185 7.45312 1.05518C7.41213 1.14718 7.35303 1.22998 7.27934 1.29865L2.55934 6.01865L16.7493 6.01864C16.9483 6.01864 17.139 6.09766 17.2797 6.23831C17.4203 6.37897 17.4993 6.56973 17.4993 6.76864C17.4993 6.96756 17.4203 7.15832 17.2797 7.29897C17.139 7.43963 16.9483 7.51864 16.7493 7.51864L2.55934 7.51865L7.27934 12.2386C7.35303 12.3073 7.41213 12.3901 7.45312 12.4821C7.49411 12.5741 7.51616 12.6734 7.51793 12.7741C7.51971 12.8748 7.50118 12.9749 7.46346 13.0682C7.42574 13.1616 7.3696 13.2465 7.29838 13.3177C7.22716 13.3889 7.14233 13.445 7.04894 13.4828C6.95555 13.5205 6.85552 13.539 6.75482 13.5372C6.65412 13.5355 6.5548 13.5134 6.4628 13.4724C6.3708 13.4314 6.288 13.3723 6.21934 13.2986L0.21934 7.29865Z"
                    fill="#442AE2" />
            </svg>

        </a>
        <div class="flex h-[90%] justify-center  items-center">
            <div class="sm:w-[500px]">
                <!-- Session Status -->
                <x-auth-session-status class="mb-4" :status="session('status')" />

                <h1
                    class="text-[#102935] text-center text-[24px] sm:text-[28px] md:text-[32px] lg:text-[36px] xl:text-[40px]">
                    User Profile
                </h1>

                <form method="POST" action="{{ route('user.profile-update') }}">
                    @csrf
                    @method('PUT')
                    <div class="mb-4">
                        <!-- name Address -->
                        <x-input-label for="name" :value="__('Name')" />
                        <x-text-input type="name" name="name" id="name"
                            value="{{ old('name', auth()->user()->name) }}" required autofocus />
                        <x-input-error :messages="$errors->get('name')" class="mt-2" />

                    </div>
                    <div class="mb-4">
                        <!-- Email Address -->
                        <x-input-label for="email" :value="__('Email')" />
                        <x-text-input type="email" name="email" id="email"
                            value="{{ old('email', auth()->user()->email) }}" required autofocus />
                        <x-input-error :messages="$errors->get('email')" class="mt-2" />

                    </div>
                    <div class="mb-4">
                        <!-- password Address -->
                        <x-input-label for="password" :value="__('Password')" />
                        <div class="relative">
                            <x-text-input type="password" name="password" id="password" value="{{ old('password') }}"
                                autofocus />
                            <button type="button" onclick="togglePassword(this, 'password')" data-status="text"
                                class="absolute inset-y-0 end-0 flex items-center z-20 px-3 cursor-pointer text-gray-400 rounded-e-md focus:outline-none focus:text-[#442AE2]">
                                <i class="fa-regular fa-eye-slash" id="icon-password"></i>
                            </button>
                        </div>
                        <x-input-error :messages="$errors->get('password')" class="mt-2" />

                    </div>

                    <div class="flex items-center justify-end mt-4">
                        <x-primary-button class="w-full">
                            {{ __('Update profile') }}
                        </x-primary-button>
                    </div>
                </form>

            </div>
        </div>

    </section>
@endsection
