@extends('website.app')
@section('title', 'Subscriptions')
@section('main')
    <section class="min-h-[85vh] flex py-10 justify-center">
        <div class="grid grid-cols-3 gap-8 lg:px-20 w-full">
            @foreach ($blogs as $blog)
                <div class="card rounded-lg border shadow-2xl">
                    <div class="card-header">
                        <img src="{{ $blog->banner }}" class="h-full min-w-full" alt="">
                    </div>
                    <div class="card-body p-5">
                        <a href="{{ url('blogs/' . str_replace(' ', '-', strtolower($blog->title))) }}" class="text-[26px] font-semibold hover:underline">
                            {{ $blog->title }}
                        </a>
                        <p>
                            {{ $blog->description }}
                        </p>
                        <a href="{{ url('blogs/' . str_replace(' ', '-', strtolower($blog->title)))  }}" class="text-[#442AE2] font-medium hover:underline">Read more</a>
                    </div>
                </div>
            @endforeach
        </div>
    </section>
@endsection
