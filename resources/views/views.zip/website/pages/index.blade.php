@extends('website.app')
@section('main')
    <section class="banner relative h-[85vh] text-white w-full overflow-x-hidden">
        <div class="absolute top-[20px]">
            <img src="{{ asset('lines.png') }}" alt="" srcset="">
        </div>
        <div class="absolute bottom-[5px] right-[-30px]">
            <img src="{{ asset('lines.png') }}" alt="" srcset="">
        </div>
        <div class="absolute bottom-[40px] right-[50%]">
            <img src="{{ asset('lines.png') }}" alt="" srcset="">
        </div>
        <div class="lg:flex h-full max-w-[100%]">
            <div class="p-5 h-full flex justify-center items-center lg:w-[60%]" style="line-height: 1.2">
                <div>
                    <p class="text-[20px] sm:text-[24px]">
                        Welcome to ClinEd Learning Hub
                    </p>
                    <div class="mt-5 mb-10 sm:my-0">
                        <h1 class="uppercase text-[25px] sm:text-[35px] lg:text-[45px] font-medium">
                            the leading learning
                        </h1>
                        <h1 class="uppercase text-[25px] sm:text-[35px] lg:text-[45px] font-medium">
                            platform for healthcare
                        </h1>
                        <h1 class="uppercase text-[25px] sm:text-[35px] lg:text-[45px] font-medium mb-5">
                            students and professionals.
                        </h1>

                    </div>
                    <a href="{{ url('programs') }}"
                        class="bg-white my-3 mt-10 py-3 px-10 rounded-xl text-[#493BE6] text-[14px] sm:text-[15px] lg:text-[16px] font-medium">
                        Our Programs
                    </a>

                </div>

            </div>
            <div class="hidden sm:block lg:w-[40%]">
                <img src="{{ asset('medical.png') }}" class="h-full" alt="" srcset="">
            </div>
        </div>
    </section>
    @role('user')
        <section class="welcome py-10 px-5 lg:p-20 w-full">
            <div class="flex justify-between items-center">
                <div class="flex items-center">
                    {{-- <img src="{{asset('')}}" alt=""> --}}
                    <div
                        class="mr-5 h-10 sm:h-20 w-10 sm:w-20 text-[13px] sm:text-[25px] rounded-full bg-[#876AEB] text-white flex justify-center items-center">
                        {{ Auth::user()->name[0] }}
                    </div>
                    <div>
                        <h1 class="text-[20px] sm:text-[26px] lg:text-[32px] text-[#102935]">
                            Welcome {{ Auth::user()->name }}!
                        </h1>
                        <h2 class="text-[10px] sm:text-[18px] lg:text-[20px] text-[#102935]">
                            Here is an overview of your course
                        </h2>
                    </div>
                </div>
                <div class="mt-3 sm:mt-0">
                    <button id="nclex"
                        class="py-2 px-2 md:px-3 text-nowrap lg:px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#876AEB] rounded-xl text-white text-[12px] sm:text-[14px] lg:text-[16px] font-semibold hover:bg-indigo-500">
                        NCLEX & IELTS
                    </button>
                    {{-- @foreach ($activeSubscriptions as $activeSubscription)
                        <button id="open-modal"
                            class="my-subscription py-2 px-2 md:px-3 text-nowrap lg:px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#876AEB] rounded-xl text-white text-[12px] sm:text-[14px] lg:text-[16px] font-semibold hover:bg-indigo-500">
                            {{ $activeSubscription->plan->name }}
                        </button>
                    @endforeach --}}
                    {{-- @if (Auth::user()->activeSubscription())
                        <button id="open-modal"
                            class="my-subscription py-2 px-2 md:px-3 text-nowrap lg:px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#876AEB] rounded-xl text-white text-[12px] sm:text-[14px] lg:text-[16px] font-semibold hover:bg-indigo-500">
                            {{ Auth::user()->activeSubscription()->plan->name }}
                        </button>
                    @endif --}}
                    @if (count($activeSubscriptions) > 0)
                        <button id="open-modal"
                            class="my-subscription py-2 px-2 md:px-3 text-nowrap lg:px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#876AEB] rounded-xl text-white text-[12px] sm:text-[14px] lg:text-[16px] font-semibold hover:bg-indigo-500">
                            My Subscriptions
                        </button>
                    @endif
                </div>
            </div>
            <div class="hidden nclex-modal p-5 absolute bg-white z-[100]"
                style="box-shadow: 0px 5px 10px rgba(90, 90, 90, 0.600);">
                <div class="flex">
                    <div class="min-w-[300px] p-3 py-10 shadow-2xl">
                        <div class="flex justify-end">
                            <select name="" id=""
                                class="currency w-[100px] border border-slate-300 rounded py-1 px-3">
                                <option value="USD" data-symbol="$">USD</option>
                                <option value="NGN" data-symbol="₦">Naira</option>
                                <option value="GBP" data-symbol="£">GBP</option>
                            </select>
                        </div>
                        <center>

                            <p class="text-[32px] text-center">
                                NCLEX & IELTS
                            </p>
                            <p class="text-[32px] text-center my-5">
                                <span class="mr-1" id="symbol">$</span><span id="amount">{{ $plans[3]->price }}</span>
                            </p>
                            <form action="{{ route('selected-plan') }}" method="post">
                                @csrf
                                <input type="hidden" name="currency" value="USD" class="currency-input">
                                <input type="hidden" name="plan_id" value="{{ $plans[3]->id }}">
                                <input type="hidden" name="amount" id="amount-input" value="{{ $plans[3]->price }}">
                                <button type="submit"
                                    class="py-2 px-8 mb-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white  text-[14px] sm:text-[15px] lg:text-[16px] xl:text-[18px] 2xl:text-[20px] font-semibold hover:bg-[#442AE2]">
                                    Buy Now
                                </button>
                            </form>
                            {{-- <a href="{{ url('payment/' . $plans[0]->name) }}"
                                class="py-2 px-8 mb-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white  text-[14px] sm:text-[15px] lg:text-[16px] xl:text-[18px] 2xl:text-[20px] font-semibold hover:bg-[#442AE2]">
                                Buy Now
                            </a> --}}
                            <span
                                class="text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px] text-[#442AE2] block mt-4 mb-8">
                                Cancel anytime
                            </span>
                        </center>

                        <div>

                            <ul class="space-y-5 list-none 2xl:p-5">
                                <li class="flex">
                                    <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                            stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    <span
                                        class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                                        is a long established fact that a reader will be.</span>
                                </li>
                                <li class="flex">
                                    <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                            stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    <span
                                        class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                                        is a long established fact that a reader will be.</span>
                                </li>
                                <li class="flex">
                                    <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                            stroke="black" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg>
                                    <span
                                        class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                                        is a long established fact that a reader will be.</span>
                                </li>
                                <li class="flex">
                                    <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                            stroke="black" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg>
                                    <span
                                        class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                                        is a long established fact that a reader will be.</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="min-h-full px-20 flex items-center">
                        <p>
                            It is a long established fact that a reader will be distracted by the readable content of a page
                            when
                            looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal
                            distribution
                            of letters, as opposed to using 'Content here, content here', making it look like readable English.
                        </p>

                    </div>
                </div>
            </div>
            <div class="grid sm:grid-cols-2 gap-5 my-10">
                <div class="border border-[#4329E2] rounded-3xl text-center py-5 shadow-lg">
                    <h1 class="text-[20px] sm:text-[23px] lg:text-[26px] font-medium text-[#102935]">
                        Total Enrolled
                    </h1>
                    <h2 class="text-[20px] sm:text-[23px] lg:text-[26px] font-medium text-[#102935]">
                        {{ count(Auth::user()->courses) }}
                    </h2>
                </div>
                <div class="border border-[#4329E2] rounded-3xl text-center py-5 shadow-lg">
                    <h1 class="text-[20px] sm:text-[23px] lg:text-[26px] font-medium text-[#102935]">
                        Completed
                    </h1>
                    <h2 class="text-[20px] sm:text-[23px] lg:text-[26px] font-medium text-[#102935]">
                        {{ count(Auth::user()->completedCourses) }}
                    </h2>
                </div>
            </div>
            @if (count(Auth::user()->continueCourses) > 0)
                <h1 class="text-[18px] sm:text-[32px] lg:text-[36px] text-[#102935] font-bold pt-5 uppercase my-5">
                    Continue Courses
                </h1>
            @endif
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-10 px-2 sm:px-5 md:px-10 xl:px-20">
                @forelse (Auth::user()->courses as $course)
                    {{-- @if (count($course->course->lessons) != count($course->userLessons)) --}}
                    <div class="border border-[#4329E2] rounded-2xl text-center p-5 shadow-xl">
                        <a href="{{url('courses/' . $course->course->slug)}}" class="uppercase hover:underline text-[#102935] text-[24px] sm:text-[32px] lg:text-[36px] font-bold">
                            {{ $course->course->title }}
                        </a>
                        @php
                            $completedLessons = count($course->userLessons);
                            $totalLessons = count($course->course->lessons);
                            $completionPercentage = $totalLessons > 0 ? ($completedLessons / $totalLessons) * 100 : 0;
                        @endphp
                        <div class="progress-container mt-7 mb-5">
                            <div class="progress-bar w-[{{ $completionPercentage }}%]" id="progress"></div>
                        </div>
                        <p class="text-[16px] sm:text-[18px] md:text-[20px] lg:text-[24px] text-[#102935]">
                            {{ count($course->userLessons) }}/{{ count($course->course->lessons) }} LESSONS
                        </p>
                        <p class="text-[16px] sm:text-[18px] md:text-[20px] lg:text-[24px] text-[#102935]  uppercase">
                            Quiz Score
                        </p>
                        <p class="text-[16px] sm:text-[18px] md:text-[20px] lg:text-[24px] text-[#102935]">
                            {{ Auth::user()->userQuizScore($course->course_id) }}
                            {{-- {{ count($course->course->quizQuestions) }} --}}
                        </p>
                    </div>
                    {{-- @endif --}}
                @empty
                @endforelse
            </div>
            @if (count(Auth::user()->completedCourses) > 0)
                <h1 class="text-[18px] sm:text-[32px] lg:text-[36px] text-[#102935] font-bold pt-5 my-5">
                    Completed Courses
                </h1>
            @endif
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-10 px-2 sm:px-5 md:px-10 xl:px-20">
                @forelse (Auth::user()->completedCourses as $course)
                    @if (count($course->userLessons) == count($course->course->lessons))
                        <div class="border border-[#4329E2] rounded-2xl text-center p-5 shadow-xl">
                            <h1 class="uppercase text-[#102935] text-[24px] sm:text-[32px] lg:text-[36px] font-bold">
                                {{ $course->course->title }}
                            </h1>
                            @php
                                $completedLessons = count($course->userLessons);
                                $totalLessons = count($course->course->lessons);
                                $completionPercentage =
                                    $totalLessons > 0 ? ($completedLessons / $totalLessons) * 100 : 0;
                            @endphp
                            <div class="progress-container mt-7 mb-5">
                                <div class="progress-bar w-[{{ $completionPercentage }}%]" id="progress"></div>
                            </div>
                            <p class="text-[20px] lg:text-[24px] text-[#102935]">
                                {{ count($course->userLessons) }}/{{ count($course->course->lessons) }} LESSONS
                            </p>
                            <div class="flex justify-around">
                                <div>
                                    <p
                                        class="text-[16px] sm:text-[18px] md:text-[20px] lg:text-[24px] text-[#102935]  uppercase">
                                        Quiz Score
                                    </p>
                                    <p class="text-[16px] sm:text-[18px] md:text-[20px] lg:text-[24px] text-[#102935]">
                                        {{ Auth::user()->userQuizScore($course->course_id) }}
                                        {{-- {{ count($course->course->quizQuestions) }} --}}
                                    </p>
                                </div>
                                <div>
                                    <p
                                        class="text-[16px] sm:text-[18px] md:text-[20px] lg:text-[24px] text-[#102935]  uppercase">
                                        Exam Score
                                    </p>
                                    <p class="text-[16px] sm:text-[18px] md:text-[20px] lg:text-[24px] text-[#102935]">
                                        {{ Auth::user()->userExamScore($course->course_id) }}
                                        {{-- {{ count($course->course->examQuestions) }} --}}
                                    </p>
                                </div>
                            </div>
                        </div>
                    @endif
                @empty
                @endforelse
            </div>
        </section>

        <div class="relative">
            <img src="{{ asset('banner-completed-course.png') }}" alt="" srcset="" class="w-full">
            <h1
                class="absolute bottom-3 sm:bottom-10 text-[15px] sm:text-[30px] lg:text-[40px] xl:text-[63px] text-center w-full font-medium text-white">
                Your Gateway to Excellence in HEALTHCARE EDUCATION
            </h1>
        </div>


        {{-- @if (Auth::user()->activeSubscription()) --}}
        <section id="subscription-modal"
            class="hidden h-full  justify-center items-center absolute bg-black bg-opacity-25 w-full top-0 bottom-0 overflow-hidden">
            <div class="w-[350px] sm:w-[450px] bg-white rounded p-5 relative block max-h-[90vh] overflow-y-auto">
                @foreach ($activeSubscriptions as $activeSubscription)
                    <div class="border-b py-4">
                        <span class="text-[#4329E2] font-semibold text-[22px]">
                            {{ $activeSubscription->plan->name }}
                        </span>
                        <div class="mt-2">
                            <p>
                                <b>Program:</b> {{ $activeSubscription->plan->category->title ?? '' }}
                            </p>
                            <p>
                                <b>Start Date:</b> {{ date('d F, Y', strtotime($activeSubscription->start_at)) }}
                            </p>
                            <p>
                                <b>End Date:</b>
                                {{ $activeSubscription->end_at ? date('d F, Y', strtotime($activeSubscription->end_at)) : 'Life time subscription' }}
                            </p>

                        </div>
                        <form action="{{ route('cancel-subscription') }}" method="post">
                            @csrf
                            <input type="hidden" name="subscription_id"
                                value="{{ $activeSubscription->user_subscription_id }}">
                            <div class="mt-5">
                                <button type="submit"
                                    class='py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500'>
                                    Cancel subscription
                                </button>
                            </div>
                        </form>
                        <button id="close-modal" class="absolute top-[5px] right-[10px] text-slate-400">
                            X
                        </button>
                    </div>
                @endforeach

            </div>
        </section>
        {{-- @endif --}}
    @endrole
    <section class="py-10 px-5 lg:p-20 w-full">
        <span class="text-[12px] sm:text-[18px] lg:text-[20px] text-[#493BE6] uppercase">
            Browse Categories
        </span>
        <h2 class="text-[22px] sm:text-[32px] lg:text-[36px] text-[#102935] font-bold uppercase my-2 lg:my-5">
            Top courses
        </h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 lg:gap-10 xl:gap-14 2xl:gap-16 p-3">
            @forelse ($courses as $course)
                <div class="group bg-white hover:bg-[#876AEB] overflow-hidden rounded"
                    style="box-shadow: 0px 5px 10px rgba(90, 90, 90, 0.600);">
                    <div class="h-60 2xl:h-70 shadow-xl">
                        <img src="{{ asset($course->thumbnail) }}" class="h-full w-full" alt="" srcset="">
                    </div>
                    <div class="p-4 sm:p-4 2xl:p-8 2xl:pb-20">
                        <div class="flex justify-between">
                            <div
                                class="flex items-center text-[12px] xl:text-[14px] text-[#876AEB] group-hover:text-white">
                                <svg width="20" height="15" viewBox="0 0 20 15" fill="none" class="mr-2"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M18.8274 0.00181828C16.9246 0.105947 13.1426 0.484963 10.8078 1.86308C10.6467 1.95817 10.5554 2.12725 10.5554 2.30404V14.4871C10.5554 14.8738 10.9939 15.1183 11.3637 14.9388C13.7659 13.773 17.2399 13.4549 18.9576 13.3678C19.5441 13.338 20 12.8847 20 12.3413V1.02972C20.0003 0.436749 19.467 -0.033003 18.8274 0.00181828ZM9.19217 1.86308C6.85776 0.484963 3.07575 0.106282 1.17294 0.00181828C0.533342 -0.033003 0 0.436749 0 1.02972V12.3416C0 12.8854 0.455911 13.3387 1.04238 13.3682C2.76081 13.4552 6.23657 13.7736 8.63869 14.9401C9.00745 15.1193 9.44461 14.8752 9.44461 14.4895V2.29801C9.44461 2.12089 9.35363 1.95851 9.19217 1.86308Z"
                                        fill="currentColor" />
                                </svg>
                                {{ count($course->lessons) }} Lessons
                            </div>

                            {{-- <div class="flex items-center text-[12px] xl:text-[14px] text-[#876AEB] group-hover:text-white">
                                <svg width="20" height="25" viewBox="0 0 20 25" fill="none" class="mr-2"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M19.9988 14.8438C19.9988 20.4541 15.5231 25 9.9994 25C4.47569 25 0 20.4541 0 14.8438C0 9.76562 3.66805 5.55664 8.46103 4.80957V3.125H7.11496C6.79767 3.125 6.53807 2.86133 6.53807 2.53906V0.585938C6.53807 0.263672 6.79767 0 7.11496 0H12.8838C13.2011 0 13.4607 0.263672 13.4607 0.585938V2.53906C13.4607 2.86133 13.2011 3.125 12.8838 3.125H11.5378V4.80957C13.3405 5.09277 14.9847 5.86426 16.3307 6.98731L17.6528 5.64453C17.8787 5.41504 18.2441 5.41504 18.47 5.64453L19.8305 7.02637C20.0565 7.25586 20.0565 7.62695 19.8305 7.85644L18.4172 9.29199L18.3883 9.32129C19.4075 10.9033 19.9988 12.8027 19.9988 14.8438ZM11.5378 16.6016V9.2041C11.5378 8.88184 11.2782 8.61816 10.9609 8.61816H9.03792C8.72063 8.61816 8.46103 8.88184 8.46103 9.2041V16.6016C8.46103 16.9238 8.72063 17.1875 9.03792 17.1875H10.9609C11.2782 17.1875 11.5378 16.9238 11.5378 16.6016Z"
                                        fill="currentColor" />
                                </svg>
                                1hr 17min
                            </div> --}}
                        </div>
                        <a href="{{ route('course-detail', ['course' => $course->slug]) }}"
                            class="hover:underline text-[18px] sm:text-[20px] lg:text-[22px] 2xl:text-[26px] font-medium text-[#102935] group-hover:text-white my-3">
                            {{ $course->title }}
                        </a>
                        <p
                            class="text-[14px] sm:text-[15px] lg:text-[16px] 2xl:text-[18px] text-[#102935] group-hover:text-white">
                            {{ $course->description }}
                        </p>
                    </div>
                </div>

            @empty
            @endforelse
        </div>
    </section>
    {{-- <section class="plan-for-you py-10 px-5 lg:p-20 w-full">
        <h1
            class="text-[22px] sm:text-[28px] md:text-[32px] lg:text-[36px] font-bold text-center text-white uppercase mb-5">
            Plans For You
        </h1>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 p-3">
            <div class="bg-white p-5 2xl:py-20">
                <center>
                    <h1
                        class="text-center text-[20px] sm:text-[28px] lg:text-[32px] xl:text-[36px] 2xl:text-[40px] text-[#102935]">
                        {{ $plans[0]->name }}
                    </h1>
                    <h2
                        class=" font-bold text-center text-[20px] sm:text-[28px] lg:text-[32px] xl:text-[36px] 2xl:text-[40px] text-[#102935] mb-7 flex justify-center items-center">
                        <svg width="16" height="18" viewBox="0 0 16 18" fill="none" class="mr-2"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M1.86502 0H4.46104C4.48924 0.00155573 4.51664 0.00996248 4.54085 0.0244921C4.56507 0.0390216 4.58538 0.0592359 4.60002 0.083384L8.06045 5.87301H11.5584V0.175106C11.5579 0.152427 11.5618 0.129864 11.5701 0.108732C11.5783 0.0876011 11.5907 0.0683245 11.6065 0.0520261C11.6223 0.0357277 11.6411 0.0227337 11.662 0.0138015C11.6829 0.00486935 11.7053 0.000177677 11.728 0L14.1294 0C14.1748 0 14.2182 0.0180094 14.2503 0.0500663C14.2823 0.0821233 14.3004 0.125602 14.3004 0.170937V5.86884H15.8291C15.8744 5.86884 15.9179 5.88685 15.9499 5.91891C15.982 5.95097 16 5.99445 16 6.03978V7.58099C16 7.62633 15.982 7.66981 15.9499 7.70187C15.9179 7.73392 15.8744 7.75193 15.8291 7.75193H14.3004V9.05967H15.8291C15.8742 9.05967 15.9174 9.07749 15.9494 9.10925C15.9815 9.141 15.9996 9.18413 16 9.22922V10.7677C15.9996 10.8127 15.9815 10.8559 15.9494 10.8876C15.9174 10.9194 15.8742 10.9372 15.8291 10.9372H14.3004V16.9131C14.3004 16.9584 14.2823 17.0019 14.2503 17.0339C14.2182 17.066 14.1748 17.084 14.1294 17.084H11.728C11.6998 17.0824 11.6724 17.074 11.6482 17.0595C11.6239 17.045 11.6036 17.0248 11.589 17.0006L8.06045 10.9372H4.62225V16.9131C4.62044 16.9579 4.60106 17.0002 4.5683 17.0309C4.53554 17.0616 4.49202 17.0782 4.44715 17.077H1.86502C1.81969 17.077 1.77621 17.059 1.74415 17.027C1.71209 16.9949 1.69409 16.9514 1.69409 16.9061V10.9372H0.165378C0.121253 10.9358 0.0793933 10.9173 0.0485663 10.8857C0.0177393 10.8541 0.000335624 10.8118 0 10.7677L0 9.22922C0.000366631 9.18413 0.0185378 9.141 0.0505551 9.10925C0.0825723 9.07749 0.125842 9.05967 0.170937 9.05967H1.69964V7.75193H0.170937C0.148489 7.75193 0.126261 7.74751 0.105522 7.73892C0.0847833 7.73033 0.0659393 7.71774 0.0500664 7.70187C0.0180094 7.66981 0 7.62633 0 7.58099L0 6.04395C0 5.99861 0.0180094 5.95514 0.0500664 5.92308C0.0821233 5.89102 0.125602 5.87301 0.170937 5.87301H1.69964V0.175106C1.69852 0.130001 1.71527 0.0862812 1.74625 0.053479C1.77723 0.0206768 1.81993 0.00145329 1.86502 0ZM4.62225 7.75193V9.05967H6.9848L6.37332 7.75193H4.62225ZM9.72813 9.05967H11.5584V7.75193H9.12777L9.72813 9.05967ZM11.5584 10.9372H10.8232L11.5584 12.4659V10.9372ZM4.62225 4.55277V5.87301H5.25736L4.62225 4.55277Z"
                                fill="#102935" />
                        </svg>

                        {{ number_format($plans[0]->price) }}
                    </h2>
                    <a href="{{ url('plan/') }}"
                        class="py-2 px-8 mb-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white  text-[14px] sm:text-[15px] lg:text-[16px] xl:text-[18px] 2xl:text-[20px] font-semibold hover:bg-[#442AE2]">
                        Buy Now
                    </a>
                    <span
                        class="text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px] text-[#442AE2] block mt-4 mb-8">
                        Cancel anytime
                    </span>
                </center>

                <ul class="space-y-5 list-none 2xl:p-5">
                    <li class="flex">
                        <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span
                            class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                            is a long established fact that a reader will be.</span>
                    </li>
                    <li class="flex">
                        <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span
                            class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                            is a long established fact that a reader will be.</span>
                    </li>
                    <li class="flex">
                        <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span
                            class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                            is a long established fact that a reader will be.</span>
                    </li>
                    <li class="flex">
                        <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span
                            class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                            is a long established fact that a reader will be.</span>
                    </li>
                </ul>

            </div>
            <div class="bg-white p-5 2xl:py-20">
                <center>
                    <h1
                        class="text-center text-[20px] sm:text-[28px] lg:text-[32px] xl:text-[36px] 2xl:text-[40px] text-[#102935]">
                        {{ $plans[1]->name }}
                    </h1>
                    <h2
                        class=" font-bold text-center text-[20px] sm:text-[28px] lg:text-[32px] xl:text-[36px] 2xl:text-[40px] text-[#102935] mb-7 flex justify-center items-center">
                        <svg width="16" height="18" viewBox="0 0 16 18" fill="none" class="mr-2"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M1.86502 0H4.46104C4.48924 0.00155573 4.51664 0.00996248 4.54085 0.0244921C4.56507 0.0390216 4.58538 0.0592359 4.60002 0.083384L8.06045 5.87301H11.5584V0.175106C11.5579 0.152427 11.5618 0.129864 11.5701 0.108732C11.5783 0.0876011 11.5907 0.0683245 11.6065 0.0520261C11.6223 0.0357277 11.6411 0.0227337 11.662 0.0138015C11.6829 0.00486935 11.7053 0.000177677 11.728 0L14.1294 0C14.1748 0 14.2182 0.0180094 14.2503 0.0500663C14.2823 0.0821233 14.3004 0.125602 14.3004 0.170937V5.86884H15.8291C15.8744 5.86884 15.9179 5.88685 15.9499 5.91891C15.982 5.95097 16 5.99445 16 6.03978V7.58099C16 7.62633 15.982 7.66981 15.9499 7.70187C15.9179 7.73392 15.8744 7.75193 15.8291 7.75193H14.3004V9.05967H15.8291C15.8742 9.05967 15.9174 9.07749 15.9494 9.10925C15.9815 9.141 15.9996 9.18413 16 9.22922V10.7677C15.9996 10.8127 15.9815 10.8559 15.9494 10.8876C15.9174 10.9194 15.8742 10.9372 15.8291 10.9372H14.3004V16.9131C14.3004 16.9584 14.2823 17.0019 14.2503 17.0339C14.2182 17.066 14.1748 17.084 14.1294 17.084H11.728C11.6998 17.0824 11.6724 17.074 11.6482 17.0595C11.6239 17.045 11.6036 17.0248 11.589 17.0006L8.06045 10.9372H4.62225V16.9131C4.62044 16.9579 4.60106 17.0002 4.5683 17.0309C4.53554 17.0616 4.49202 17.0782 4.44715 17.077H1.86502C1.81969 17.077 1.77621 17.059 1.74415 17.027C1.71209 16.9949 1.69409 16.9514 1.69409 16.9061V10.9372H0.165378C0.121253 10.9358 0.0793933 10.9173 0.0485663 10.8857C0.0177393 10.8541 0.000335624 10.8118 0 10.7677L0 9.22922C0.000366631 9.18413 0.0185378 9.141 0.0505551 9.10925C0.0825723 9.07749 0.125842 9.05967 0.170937 9.05967H1.69964V7.75193H0.170937C0.148489 7.75193 0.126261 7.74751 0.105522 7.73892C0.0847833 7.73033 0.0659393 7.71774 0.0500664 7.70187C0.0180094 7.66981 0 7.62633 0 7.58099L0 6.04395C0 5.99861 0.0180094 5.95514 0.0500664 5.92308C0.0821233 5.89102 0.125602 5.87301 0.170937 5.87301H1.69964V0.175106C1.69852 0.130001 1.71527 0.0862812 1.74625 0.053479C1.77723 0.0206768 1.81993 0.00145329 1.86502 0ZM4.62225 7.75193V9.05967H6.9848L6.37332 7.75193H4.62225ZM9.72813 9.05967H11.5584V7.75193H9.12777L9.72813 9.05967ZM11.5584 10.9372H10.8232L11.5584 12.4659V10.9372ZM4.62225 4.55277V5.87301H5.25736L4.62225 4.55277Z"
                                fill="#102935" />
                        </svg>

                        {{ number_format($plans[1]->price) }}
                    </h2>
                    <a href="{{ url('plan/') }}"
                        class="py-2 px-8 mb-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white  text-[14px] sm:text-[15px] lg:text-[16px] xl:text-[18px] 2xl:text-[20px] font-semibold hover:bg-[#442AE2]">
                        Buy Now
                    </a>
                    <span
                        class="text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px] text-[#442AE2] block mt-4 mb-8">
                        Cancel anytime
                    </span>
                </center>

                <ul class="space-y-5 list-none 2xl:p-5">
                    <li class="flex">
                        <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span
                            class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                            is a long established fact that a reader will be.</span>
                    </li>
                    <li class="flex">
                        <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span
                            class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                            is a long established fact that a reader will be.</span>
                    </li>
                    <li class="flex">
                        <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span
                            class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                            is a long established fact that a reader will be.</span>
                    </li>
                    <li class="flex">
                        <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span
                            class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                            is a long established fact that a reader will be.</span>
                    </li>
                </ul>

            </div>
            <div class="bg-white p-5 2xl:py-20">
                <center>
                    <h1
                        class="text-center text-[20px] sm:text-[28px] lg:text-[32px] xl:text-[36px] 2xl:text-[40px] text-[#102935]">
                        {{ $plans[2]->name }}
                    </h1>
                    <h2
                        class=" font-bold text-center text-[20px] sm:text-[28px] lg:text-[32px] xl:text-[36px] 2xl:text-[40px] text-[#102935] mb-7 flex justify-center items-center">
                        <svg width="16" height="18" viewBox="0 0 16 18" fill="none" class="mr-2"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M1.86502 0H4.46104C4.48924 0.00155573 4.51664 0.00996248 4.54085 0.0244921C4.56507 0.0390216 4.58538 0.0592359 4.60002 0.083384L8.06045 5.87301H11.5584V0.175106C11.5579 0.152427 11.5618 0.129864 11.5701 0.108732C11.5783 0.0876011 11.5907 0.0683245 11.6065 0.0520261C11.6223 0.0357277 11.6411 0.0227337 11.662 0.0138015C11.6829 0.00486935 11.7053 0.000177677 11.728 0L14.1294 0C14.1748 0 14.2182 0.0180094 14.2503 0.0500663C14.2823 0.0821233 14.3004 0.125602 14.3004 0.170937V5.86884H15.8291C15.8744 5.86884 15.9179 5.88685 15.9499 5.91891C15.982 5.95097 16 5.99445 16 6.03978V7.58099C16 7.62633 15.982 7.66981 15.9499 7.70187C15.9179 7.73392 15.8744 7.75193 15.8291 7.75193H14.3004V9.05967H15.8291C15.8742 9.05967 15.9174 9.07749 15.9494 9.10925C15.9815 9.141 15.9996 9.18413 16 9.22922V10.7677C15.9996 10.8127 15.9815 10.8559 15.9494 10.8876C15.9174 10.9194 15.8742 10.9372 15.8291 10.9372H14.3004V16.9131C14.3004 16.9584 14.2823 17.0019 14.2503 17.0339C14.2182 17.066 14.1748 17.084 14.1294 17.084H11.728C11.6998 17.0824 11.6724 17.074 11.6482 17.0595C11.6239 17.045 11.6036 17.0248 11.589 17.0006L8.06045 10.9372H4.62225V16.9131C4.62044 16.9579 4.60106 17.0002 4.5683 17.0309C4.53554 17.0616 4.49202 17.0782 4.44715 17.077H1.86502C1.81969 17.077 1.77621 17.059 1.74415 17.027C1.71209 16.9949 1.69409 16.9514 1.69409 16.9061V10.9372H0.165378C0.121253 10.9358 0.0793933 10.9173 0.0485663 10.8857C0.0177393 10.8541 0.000335624 10.8118 0 10.7677L0 9.22922C0.000366631 9.18413 0.0185378 9.141 0.0505551 9.10925C0.0825723 9.07749 0.125842 9.05967 0.170937 9.05967H1.69964V7.75193H0.170937C0.148489 7.75193 0.126261 7.74751 0.105522 7.73892C0.0847833 7.73033 0.0659393 7.71774 0.0500664 7.70187C0.0180094 7.66981 0 7.62633 0 7.58099L0 6.04395C0 5.99861 0.0180094 5.95514 0.0500664 5.92308C0.0821233 5.89102 0.125602 5.87301 0.170937 5.87301H1.69964V0.175106C1.69852 0.130001 1.71527 0.0862812 1.74625 0.053479C1.77723 0.0206768 1.81993 0.00145329 1.86502 0ZM4.62225 7.75193V9.05967H6.9848L6.37332 7.75193H4.62225ZM9.72813 9.05967H11.5584V7.75193H9.12777L9.72813 9.05967ZM11.5584 10.9372H10.8232L11.5584 12.4659V10.9372ZM4.62225 4.55277V5.87301H5.25736L4.62225 4.55277Z"
                                fill="#102935" />
                        </svg>

                        {{ number_format($plans[2]->price) }}
                    </h2>
                    <a href="{{ url('plan/') }}"
                        class="py-2 px-8 mb-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white  text-[14px] sm:text-[15px] lg:text-[16px] xl:text-[18px] 2xl:text-[20px] font-semibold hover:bg-[#442AE2]">
                        Buy Now
                    </a>
                    <span
                        class="text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px] text-[#442AE2] block mt-4 mb-8">
                        Cancel anytime
                    </span>
                </center>

                <ul class="space-y-5 list-none 2xl:p-5">
                    <li class="flex">
                        <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span
                            class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                            is a long established fact that a reader will be.</span>
                    </li>
                    <li class="flex">
                        <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span
                            class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                            is a long established fact that a reader will be.</span>
                    </li>
                    <li class="flex">
                        <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span
                            class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                            is a long established fact that a reader will be.</span>
                    </li>
                    <li class="flex">
                        <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <span
                            class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                            is a long established fact that a reader will be.</span>
                    </li>
                </ul>

            </div>
        </div>
    </section> --}}
    <section class="py-10 px-5 lg:p-20 w-full relative max-w-[100%] overflow-x-hidden">
        <h2 class="uppercase text-[#493BE6] text-[14px] sm:text-[18px] lg:text-[20px] text-center">
            Clients
        </h2>
        <h1 class="uppercase text-[#102935] text-[22px] sm:text-[32px] lg:text-[36px] text-center font-bold">
            WHAT OUR STUDENTS SAY
        </h1>

        <div class="swiper-container mt-5">
            <div class="swiper-wrapper">
                <div class="swiper-slide rounded-xl border-l-4 border-[#4026E2] py-20 px-5 shadow-2xl"
                    style="box-shadow: 0px 4px 20px rgba(90, 90, 90, 0.452);">
                    <p>
                        There are many variations of passages of lorem ipsum available. The majority have suffered
                        alteration in
                        some form by injected humour.
                    </p>
                    <div class="flex justify-between items-center mt-4">
                        <div>
                            <span class="text-[#000000] font-medium block">Name Here</span>
                            <span class="text-[#7F7F7F] text-[18px]">Founder & CEO</span>
                        </div>
                        <div>
                            <svg width="48" height="42" viewBox="0 0 48 42" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M13 0H23L10 42H0L13 0Z" fill="#4026E2" />
                                <path d="M38 0H48L35 42H25L38 0Z" fill="#4026E2" />
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide rounded-xl border-l-4 border-[#4026E2] py-20 px-5 shadow-2xl"
                    style="box-shadow: 0px 4px 20px rgba(90, 90, 90, 0.452);">
                    <p>
                        There are many variations of passages of lorem ipsum available. The majority have suffered
                        alteration in
                        some form by injected humour.
                    </p>
                    <div class="flex justify-between items-center mt-4">
                        <div>
                            <span class="text-[#000000] font-medium block">Name Here</span>
                            <span class="text-[#7F7F7F] text-[18px]">Founder & CEO</span>
                        </div>
                        <div>
                            <svg width="48" height="42" viewBox="0 0 48 42" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M13 0H23L10 42H0L13 0Z" fill="#4026E2" />
                                <path d="M38 0H48L35 42H25L38 0Z" fill="#4026E2" />
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide rounded-xl border-l-4 border-[#4026E2] py-20 px-5 shadow-2xl"
                    style="box-shadow: 0px 4px 20px rgba(90, 90, 90, 0.452);">
                    <p>
                        There are many variations of passages of lorem ipsum available. The majority have suffered
                        alteration in
                        some form by injected humour.
                    </p>
                    <div class="flex justify-between items-center mt-4">
                        <div>
                            <span class="text-[#000000] font-medium block">Name Here</span>
                            <span class="text-[#7F7F7F] text-[18px]">Founder & CEO</span>
                        </div>
                        <div>
                            <svg width="48" height="42" viewBox="0 0 48 42" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M13 0H23L10 42H0L13 0Z" fill="#4026E2" />
                                <path d="M38 0H48L35 42H25L38 0Z" fill="#4026E2" />
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide rounded-xl border-l-4 border-[#4026E2] py-20 px-5 shadow-2xl"
                    style="box-shadow: 0px 4px 20px rgba(90, 90, 90, 0.452);">
                    <p>
                        There are many variations of passages of lorem ipsum available. The majority have suffered
                        alteration in
                        some form by injected humour.
                    </p>
                    <div class="flex justify-between items-center mt-4">
                        <div>
                            <span class="text-[#000000] font-medium block">Name Here</span>
                            <span class="text-[#7F7F7F] text-[18px]">Founder & CEO</span>
                        </div>
                        <div>
                            <svg width="48" height="42" viewBox="0 0 48 42" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M13 0H23L10 42H0L13 0Z" fill="#4026E2" />
                                <path d="M38 0H48L35 42H25L38 0Z" fill="#4026E2" />
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide rounded-xl border-l-4 border-[#4026E2] py-20 px-5 shadow-2xl"
                    style="box-shadow: 0px 4px 20px rgba(90, 90, 90, 0.452);">
                    <p>
                        There are many variations of passages of lorem ipsum available. The majority have suffered
                        alteration in
                        some form by injected humour.
                    </p>
                    <div class="flex justify-between items-center mt-4">
                        <div>
                            <span class="text-[#000000] font-medium block">Name Here</span>
                            <span class="text-[#7F7F7F] text-[18px]">Founder & CEO</span>
                        </div>
                        <div>
                            <svg width="48" height="42" viewBox="0 0 48 42" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M13 0H23L10 42H0L13 0Z" fill="#4026E2" />
                                <path d="M38 0H48L35 42H25L38 0Z" fill="#4026E2" />
                            </svg>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide rounded-xl border-l-4 border-[#4026E2] py-20 px-5 shadow-2xl"
                    style="box-shadow: 0px 4px 20px rgba(90, 90, 90, 0.452);">
                    <p>
                        There are many variations of passages of lorem ipsum available. The majority have suffered
                        alteration in
                        some form by injected humour.
                    </p>
                    <div class="flex justify-between items-center mt-4">
                        <div>
                            <span class="text-[#000000] font-medium block">Name Here</span>
                            <span class="text-[#7F7F7F] text-[18px]">Founder & CEO</span>
                        </div>
                        <div>
                            <svg width="48" height="42" viewBox="0 0 48 42" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M13 0H23L10 42H0L13 0Z" fill="#4026E2" />
                                <path d="M38 0H48L35 42H25L38 0Z" fill="#4026E2" />
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-pagination" style="bottom: 15px"></div>
        </div>

    </section>



@endsection

@push('head')
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <style>
        #subscription-modal {
            position: fixed;
            top: 0%;
            left: 50%;
            transform: translateX(-50%);
            /* display: none; */
            z-index: 9999;
        }

        #subscription-modal .modal-content {
            width: 350px;
            max-width: 90%;
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
        }
    </style>
@endpush

@push('script')
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var swiper = new Swiper(".swiper-container", {
                loop: true,
                slidesPerView: 1,
                spaceBetween: 20,
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                breakpoints: {
                    640: {
                        slidesPerView: 1, // On mobile, 1 slide
                    },
                    768: {
                        slidesPerView: 2, // On tablets, 2 slides
                    },
                    1024: {
                        slidesPerView: 3, // On larger screens, 3 slides
                    },
                },
            });


            const modal = document.getElementById("subscription-modal");
            const openModalBtn = document.getElementById("open-modal");
            const closeModalBtn = document.getElementById("close-modal");

            function disableScroll() {
                document.body.style.overflow = "hidden";
            }

            function enableScroll() {
                document.body.style.overflow = "";
            }

            openModalBtn.addEventListener("click", function() {
                modal.style.display = "flex";
                disableScroll();
            });

            closeModalBtn.addEventListener("click", function() {
                modal.style.display = "none";
                enableScroll();
            });

            window.addEventListener("click", function(event) {
                if (event.target === modal) {
                    modal.style.display = "none";
                    enableScroll();
                }
            });
        });

        $('#nclex').click(function(e) {
            e.preventDefault();
            $('.nclex-modal').toggleClass('hidden');
        });
        $(document).ready(function() {
            let exchangeRates = {};
            async function fetchExchangeRates() {
                try {
                    const response = await fetch(`https://api.exchangerate-api.com/v4/latest/USD`);
                    const data = await response.json();
                    exchangeRates = data.rates;
                    console.log(exchangeRates);


                } catch (error) {
                    console.error("Error fetching exchange rates:", error);
                }
            }
            fetchExchangeRates();
            $('.currency').change(function(e) {
                e.preventDefault();
                let currency = $(this).val();
                $('.currency-input').val(currency);
                let exchangeRate = exchangeRates[currency];
                let symbol = $(this).find(':selected').data('symbol');

                let amount = "{{ $plans[3]->price }}";
                let newAmount = exchangeRate * amount;
                $('#amount-input').val(newAmount);

                $(`#amount`).text(newAmount.toFixed(2));
                $(`#symbol`).text(symbol);
            });
        });
    </script>
@endpush
