@extends('website.app')
@section('title', 'Our Courses')
@section('main')
    <section class="courses h-[85vh] flex items-center justify-center">
        <h1 class="text-white text-[48px] font-bold">
            Courses
        </h1>
    </section>

    <section class="py-10 px-5 lg:p-20 w-full">
        <div class="sm:flex justify-between">
            <div>
                <span class="text-[12px] sm:text-[18px] lg:text-[20px] text-[#493BE6] uppercase">
                    Browse Courses
                </span>
                <h2 class="text-[22px] sm:text-[32px] lg:text-[36px] text-[#102935] font-bold uppercase my-2 lg:my-5">
                    Courses
                </h2>
            </div>
            <div class="grid grid-cols-2 sm:flex">
                <div class="mr-2">
                    <select name="" id="category" class="w-full sm:w-[200px] border border-[#493BE6] rounded p-2">
                        @foreach ($categories as $category)
                            <option value="{{ $category->id }}">{{ $category->title }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="relative">
                    <input type="text" id="search-course" placeholder="search"
                        class="w-full sm:w-auto border border-[#493BE6] rounded">
                    <svg width="16" height="17" viewBox="0 0 16 17" fill="none" class="absolute right-2 top-3"
                        xmlns="http://www.w3.org/2000/svg">
                        <circle cx="7" cy="7" r="6.5" stroke="#624EE7" />
                        <path d="M11 12L15 16" stroke="#624EE7" />
                    </svg>

                </div>
            </div>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 p-3" id="course-list">

        </div>
    </section>

    @push('script')
        <script>
            function getCourses() {
                $.ajax({
                    type: "GET",
                    url: "{{ route('get-course') }}",
                    data: {
                        search: $('#search-course').val(),
                        category: $('#category').val()
                    },
                    success: function(response) {
                        if (response.error) {
                            console.log(response.message);
                            return
                        }
                        $('#course-list').empty();
                        $('#course-list').append(response.html);
                    }
                });
            }
            getCourses();
            $('#search-course').on('keyup', function(e) {
                getCourses()
            });
            $('#category').change(function (e) { 
                e.preventDefault();
                getCourses()
                
            });
        </script>
    @endpush
@endsection
