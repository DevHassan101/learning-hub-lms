@extends('website.app')
@section('title', 'Course Detail')
@section('main')
    <section class="course-detail min-h-[283px] py-10 px-5 lg:p-20 w-full">
        <h1 class="text-[14px] md:text-[16px] lg:text-[20px] font-medium text-[#FFFFFF]">
            {{ $course->title }}
        </h1>
        <h1 class="text-[12px] md:text-[14px] lg:text-[18px] text-[#FFFFFF]">
            Program: {{ $course->category->title ?? '' }}
        </h1>
        <p class="text-[14px] md:text-[16px] lg:text-[20px] text-[#FFFFFF] my-4">
            {{ $course->description }}
        </p>
        @if ($userEnrolledInCourse)
            <span class="py-2 px-7 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[14px] md:text-[16px] lg:text-[18px] font-bold hover:bg-indigo-500">
                Enrolled
            </span>
        @else
            <a href="{{ route('course-enroll', ['course' => $course->slug]) }}"
                class="py-2 px-7 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[14px] md:text-[16px] lg:text-[18px] font-bold hover:bg-indigo-500">
                Enroll Now
            </a>
        @endif
    </section>

    <section class="min-h-[283px] py-10 px-5 lg:p-20 w-full">
        <div class="bg-white py-20 px-10" style="box-shadow: 0px 2px 10px rgba(90, 90, 90, 0.452);">
            <h1 class="text-[#102935] text-[25px] md:text-[30px] lg:text-[36px] font-medium mb-5">
                Course Curriculum
            </h1>
            @forelse ($course->lessons as $lesson)
                <div class="sm:flex border-b-2 border-[#6651E7] py-5 items-center">
                    <div class="min-w-[210px]">
                        @if (is_null($lesson->file))
                            <img src="{{ asset('pdf.png') }}" class="sm:h-40" alt="" srcset="">
                        @else
                            <img src="{{ asset($lesson->thumbnail) }}" class="sm:h-40" alt="" srcset="">
                        @endif
                    </div>
                    <div class="w-full p-4">
                        <div class="sm:flex justify-between items-center">
                            @php
                                $url = is_null($lesson->file)
                                    ? 'course/' . $course->slug . '/' . $lesson->slug . '/lectures-pdf'
                                    : // ? asset($lesson->attachments)
                                        'course/' . $course->slug . '/' . $lesson->slug;
                            @endphp
                            <a href="{{ url($url) }}" target="{{ is_null($lesson->file) ? '_blank' : '' }}" class="text-[#102935] font-medium text-[24px] md:text-[28px] lg:text-[34px] hover:underline">
                                {{ $lesson->title }}
                            </a>
                            <a href="{{ url($url) }}" target="{{ is_null($lesson->file) ? '_blank' : '' }}"
                                class="text-[#102935] text-[14px] md:text-[16px] lg:text-[18px] underline">
                                Read Script
                            </a>
                        </div>
                        <h2 class="text-[18px] md:text-[24px] lg:text-[27px] text-[#102935] my-3">
                            By CHINAZOM NDUKWU
                        </h2>
                        <p class="text-[16px] md:text-[18px] lg:text-[20px] text-[#102935]">
                            {{ $lesson->description }}
                        </p>
                    </div>
                </div>

            @empty
            @endforelse
            <div class="sm:flex border-b-2 border-[#6651E7] py-5 items-center">
                <div class="w-full sm:w-auto">
                    <img src="{{ asset('flash-card.png') }}" class="w-full sm:w-auto" alt="" srcset="">
                    {{-- <video src=""></video> --}}
                </div>
                <div class="w-full p-4">
                    <div class="sm:flex justify-between items-center">
                        <button onclick="flashCard()"
                            class="hover:underline text-[#102935] font-medium text-[24px] md:text-[28px] lg:text-[34px]">
                            Flash Card
                        </button>
                    </div>
                    <p class="text-[16px] md:text-[18px] lg:text-[20px] text-[#102935]">
                        Flashcards are learning tools that consist of a card with a question on one side and the answer on
                        the other. They are commonly used for memorization and reinforcement of information, such as
                        vocabulary, concepts, or facts. Flashcards can be physical cards or digital apps, making them
                        versatile for various study methods. </p>
                </div>
            </div>
            <div class="sm:flex border-b-2 border-[#6651E7] py-5 items-center">
                <div class="w-full sm:w-auto">
                    <img src="{{ asset('practice-quiz.png') }}" class="w-full sm:w-auto" alt="" srcset="">
                    {{-- <video src=""></video> --}}
                </div>
                <div class="w-full p-4">
                    <div class="sm:flex justify-between items-center">
                        <a href="{{ url('course/' . $course->slug . '/quiz') }}"
                            class="hover:underline text-[#102935] font-medium text-[24px] md:text-[28px] lg:text-[34px]">
                            Practice Quiz
                        </a>
                    </div>
                    <p class="text-[16px] md:text-[18px] lg:text-[20px] text-[#102935]">
                        Flashcards are learning tools that consist of a card with a question on one side and the answer on
                        the other. They are commonly used for memorization and reinforcement of information, such as
                        vocabulary, concepts, or facts. Flashcards can be physical cards or digital apps, making them
                        versatile for various study methods.
                    </p>
                </div>
            </div>
            <div class="sm:flex border-b-2 border-[#6651E7] py-5 items-center">
                <div class="w-full sm:w-auto">
                    <img src="{{ asset('practice-exam.png') }}" class="w-full sm:w-auto" alt="" srcset="">
                    {{-- <video src=""></video> --}}
                </div>
                <div class="w-full p-4">
                    <div class="sm:flex justify-between items-center">
                        <a href="{{ url('course/' . $course->slug . '/exam') }}"
                            class="hover:underline text-[#102935] font-medium text-[24px] md:text-[28px] lg:text-[34px]">
                            Practice Exam
                        </a>
                    </div>
                    <p class="text-[16px] md:text-[18px] lg:text-[20px] text-[#102935]">
                        A practice quiz is a tool used to assess knowledge and understanding of a specific subject or topic.
                        It typically consists of a series of questions that help users gauge their grasp of the material and
                        identify areas needing improvement. Practice quizzes can be used in educational settings or for
                        self-study, helping reinforce learning through active engagement.
                    </p>
                </div>
            </div>
        </div>
    </section>


    <section class="explanation-modal hidden" id="flashcard-modal">
        <div class="modal-content border border-[#472EE3] py-14">
            <button class="close-btn text-[#472EE3] font-bold text-[22px]" onclick="cancelFlashcard()">✕</button>
            <h2 class="text-[20px] font-bold text-[#102935]">Flash Cards</h2>
            <div id="flashCardContainer">
                @forelse ($course->flashCards as $index => $flashCard)
                    <div class="flash-card hidden" data-index="{{ $index }}">
                        <p class="text-[18px] font-bold text-[#102935] my-5">{{ $flashCard->title }}</p>
                        <p class="text-[18px] text-[#102935] max-h-[300px] overflow-y-auto">
                            {{ $flashCard->description }}
                        </p>
                    </div>
                @empty
                    <p>No Flashcards Available</p>
                @endforelse
            </div>
            <div class="mt-5">
                <button id="prevBtn"
                    class="py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500 min-w-[100px] mr-5">
                    Previous
                </button>
                <button id="nextBtn"
                    class="py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500 min-w-[100px]">
                    Next
                </button>
            </div>
        </div>
    </section>

    @push('script')
        <script>
            function flashCard() {
                document.getElementById('flashcard-modal').classList.remove('hidden');
            }

            function cancelFlashcard() {
                document.getElementById('flashcard-modal').classList.add('hidden');
            }

            document.addEventListener("DOMContentLoaded", function() {
                let flashCards = document.querySelectorAll(".flash-card");
                let currentIndex = 0;

                function showFlashCard(index) {
                    flashCards.forEach((card, i) => {
                        card.classList.toggle("hidden", i !== index);
                    });
                }

                document.getElementById("prevBtn").addEventListener("click", function() {
                    currentIndex = (currentIndex - 1 + flashCards.length) % flashCards.length;
                    showFlashCard(currentIndex);
                });

                document.getElementById("nextBtn").addEventListener("click", function() {
                    currentIndex = (currentIndex + 1) % flashCards.length;
                    showFlashCard(currentIndex);
                });

                // Show the first flashcard initially
                showFlashCard(currentIndex);
            });
        </script>
    @endpush
@endsection
