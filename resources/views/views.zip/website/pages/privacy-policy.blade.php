@extends('website.app')

@section('main')
    <section class="py-16 px-5 lg:px-20 bg-gray-100 text-[#102935]">
        <div class="max-w-4xl mx-auto">
            <h1 class="text-3xl lg:text-4xl font-bold text-center text-[#493BE6] uppercase mb-2">
                Privacy Policy
            </h1>
        </div>
        <h2 class="text-md lg:text-xl font-semibold text-center uppercase mb-5">
            Welcome to ClinEd Learning Hub.
        </h2>
        <p class="text-center text-lg mb-10">
            By using this website, you agree to the our privacy policy outlined below.
            <br>
            If you do not agree, please refrain from using our services.
        </p>

        <div class="bg-white p-6 shadow-lg rounded-lg">
            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Introduction</h2>
            <p class="text-gray-700 mb-5">
                Welcome to ClinEd Learning Hub ("we," "our," or "us"). We are committed to protecting your privacy and
                ensuring that your personal data is handled securely. This Privacy Policy outlines how we collect, use, and
                safeguard your information when you access our website and services.
            </p>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Information We Collect</h2>
            <p class="text-gray-700 mb-2">
                We collect the following types of information:
                Personal Information: Name, email address, phone number, billing details, and other identifiers you provide
                during registration.
                Account Information: Login credentials, course enrollments, and progress reports.
            </p>
            <p class="text-gray-700 mb-5">
                Payment Information: When making purchases, we collect payment details, though we do not store credit card
                information. Payments are processed through secure third-party payment providers.
                Technical Information: IP address, browser type, device details, and usage data collected through cookies
                and similar tracking technologies.
            </p>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">How We Use Your Information</h2>
            <div class="text-gray-700 mb-5">
                <p>
                    We use your information for the following purposes:
                </p>
                <p>
                    To provide and improve our learning services.
                </p>
                <p>
                    To personalize your experience on our platform.
                </p>
                <p>
                    To process transactions and manage subscriptions.
                </p>
                <p>
                    To communicate with you about courses, promotions, and updates.
                </p>
                <p>
                    To comply with legal obligations and enforce our terms of service.
                </p>
            </div>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Data Sharing and Disclosure</h2>
            <div class="text-gray-700 mb-5">
                <p>
                    We do not sell your personal data. However, we may share your information with:
                </p>
                <p>
                    Service Providers: Third-party companies that help us operate our website, process payments, or provide
                    technical support.
                </p>
                <p>
                    Service Providers: Third-party companies that help us operate our website, process payments, or provide
                    technical support.
                </p>
                <p>
                    Legal Authorities: When required by law, we may disclose information in response to legal processes or
                    government requests.
                </p>
                <p>
                    Business Transfers: In the event of a merger, acquisition, or sale of assets, your data may be
                    transferred
                    to the new entity.
                </p>
            </div>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Data Security</h2>
            <p class="text-gray-700 mb-5">
                We implement appropriate security measures to protect your data from unauthorized access, alteration, or
                disclosure.
            </p>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Your Rights and Choices</h2>
            <div class="text-gray-700 mb-5">
                <p>
                    ou have the following rights regarding your personal data:
                </p>
                <p>
                    Access, update, or delete your account information.
                </p>
                <p>
                    Opt-out of marketing communications.
                </p>
                <p>
                    Restrict or object to certain data processing activities.
                </p>
                <p>
                    Request a copy of your data in a portable format.
                </p>
                <p>
                    To exercise these rights, contact us at clinedlearninghub@gmail.com
                </p>
            </div>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Cookies and Tracking Technologies</h2>
            <p class="text-gray-700 mb-5">
                We use cookies and similar tracking technologies to enhance user experience, analyze site traffic, and
                deliver targeted content. You can manage cookie preferences through your browser settings.
            </p>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Third-Party Links</h2>
            <p class="text-gray-700 mb-5">
                Our platform may contain links to third-party websites. We are not responsible for their privacy practices
                and encourage you to review their policies.
            </p>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Changes to This Privacy Policy</h2>
            <p class="text-gray-700 mb-5">
                We may update this policy from time to time. We will notify you of significant changes by posting a notice
                on our website or sending an email.
            </p>
            
            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Contact Us</h2>
            <p class="text-gray-700 mb-5">
                If you have any questions about this Privacy Policy, please contact us at:
            </p>
            <p class="text-gray-900 font-semibold">
                📧 Email: <a href="mailto:ClinEdlearninghub@gmail.com"
                    class="text-[#493BE6] hover:underline">ClinEdlearninghub@gmail.com</a>
                    Website: <a href="{{url('/')}}">clinedlearninghub.com</a>
            </p>
        </div>
    </section>
@endsection
