@foreach ($courses as $course)
<div class="group bg-white hover:bg-[#876AEB] overflow-hidden"
    style="box-shadow: 0px 5px 10px rgba(90, 90, 90, 0.600);">
    <div class="h-60 shadow-xl">
        <img src="{{ asset($course->thumbnail) }}" loading="lazy" class="h-full w-full" alt="" srcset="">
    </div>
    <div class="p-4">
        <div class="flex justify-between mb-3">
            <div class="flex items-center text-[12px] text-[#876AEB] group-hover:text-white">
                <svg width="20" height="15" viewBox="0 0 20 15" fill="none" class="mr-2"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M18.8274 0.00181828C16.9246 0.105947 13.1426 0.484963 10.8078 1.86308C10.6467 1.95817 10.5554 2.12725 10.5554 2.30404V14.4871C10.5554 14.8738 10.9939 15.1183 11.3637 14.9388C13.7659 13.773 17.2399 13.4549 18.9576 13.3678C19.5441 13.338 20 12.8847 20 12.3413V1.02972C20.0003 0.436749 19.467 -0.033003 18.8274 0.00181828ZM9.19217 1.86308C6.85776 0.484963 3.07575 0.106282 1.17294 0.00181828C0.533342 -0.033003 0 0.436749 0 1.02972V12.3416C0 12.8854 0.455911 13.3387 1.04238 13.3682C2.76081 13.4552 6.23657 13.7736 8.63869 14.9401C9.00745 15.1193 9.44461 14.8752 9.44461 14.4895V2.29801C9.44461 2.12089 9.35363 1.95851 9.19217 1.86308Z"
                        fill="currentColor" />
                </svg>
                {{count($course->lessons)}} Lessons
            </div>

            {{-- <div class="flex items-center text-[12px] text-[#876AEB] group-hover:text-white">
                <svg width="20" height="25" viewBox="0 0 20 25" fill="none" class="mr-2"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M19.9988 14.8438C19.9988 20.4541 15.5231 25 9.9994 25C4.47569 25 0 20.4541 0 14.8438C0 9.76562 3.66805 5.55664 8.46103 4.80957V3.125H7.11496C6.79767 3.125 6.53807 2.86133 6.53807 2.53906V0.585938C6.53807 0.263672 6.79767 0 7.11496 0H12.8838C13.2011 0 13.4607 0.263672 13.4607 0.585938V2.53906C13.4607 2.86133 13.2011 3.125 12.8838 3.125H11.5378V4.80957C13.3405 5.09277 14.9847 5.86426 16.3307 6.98731L17.6528 5.64453C17.8787 5.41504 18.2441 5.41504 18.47 5.64453L19.8305 7.02637C20.0565 7.25586 20.0565 7.62695 19.8305 7.85644L18.4172 9.29199L18.3883 9.32129C19.4075 10.9033 19.9988 12.8027 19.9988 14.8438ZM11.5378 16.6016V9.2041C11.5378 8.88184 11.2782 8.61816 10.9609 8.61816H9.03792C8.72063 8.61816 8.46103 8.88184 8.46103 9.2041V16.6016C8.46103 16.9238 8.72063 17.1875 9.03792 17.1875H10.9609C11.2782 17.1875 11.5378 16.9238 11.5378 16.6016Z"
                        fill="currentColor" />
                </svg>
                1hr 17min
            </div> --}}
        </div>
        <a href="{{ route('course-detail', ['course' => $course->slug]) }}"
            class="hover:underline text-[22px] font-medium text-[#102935] group-hover:text-white">
            {{$course->title}}
        </a>
        <p class="text-[16px] text-[#102935] mt-3 group-hover:text-white">
            {{$course->description}}
        </p>
    </div>
</div>
@endforeach