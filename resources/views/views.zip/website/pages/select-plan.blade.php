@extends('layouts.app2')
@section('main')
    <section class="p-5">
        <div class="flex justify-between">
            <a href="{{ url('/programs') }}">
                <svg width="18" height="14" viewBox="0 0 18 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd"
                        d="M0.21934 7.29865C0.0788893 7.15802 -2.87182e-07 6.9674 -2.9587e-07 6.76865C-3.04557e-07 6.56989 0.0788893 6.37927 0.21934 6.23865L6.21934 0.238644C6.288 0.164958 6.3708 0.105856 6.4628 0.0648639C6.5548 0.0238721 6.65411 0.00183076 6.75482 5.40642e-05C6.85552 -0.00172264 6.95555 0.0168015 7.04894 0.0545222C7.14233 0.0922429 7.22716 0.148389 7.29838 0.219607C7.3696 0.290826 7.42574 0.37566 7.46346 0.469048C7.50118 0.562437 7.51971 0.662464 7.51793 0.763167C7.51615 0.86387 7.49411 0.963185 7.45312 1.05518C7.41213 1.14718 7.35303 1.22998 7.27934 1.29865L2.55934 6.01865L16.7493 6.01864C16.9483 6.01864 17.139 6.09766 17.2797 6.23831C17.4203 6.37897 17.4993 6.56973 17.4993 6.76864C17.4993 6.96756 17.4203 7.15832 17.2797 7.29897C17.139 7.43963 16.9483 7.51864 16.7493 7.51864L2.55934 7.51865L7.27934 12.2386C7.35303 12.3073 7.41213 12.3901 7.45312 12.4821C7.49411 12.5741 7.51616 12.6734 7.51793 12.7741C7.51971 12.8748 7.50118 12.9749 7.46346 13.0682C7.42574 13.1616 7.3696 13.2465 7.29838 13.3177C7.22716 13.3889 7.14233 13.445 7.04894 13.4828C6.95555 13.5205 6.85552 13.539 6.75482 13.5372C6.65412 13.5355 6.5548 13.5134 6.4628 13.4724C6.3708 13.4314 6.288 13.3723 6.21934 13.2986L0.21934 7.29865Z"
                        fill="#442AE2" />
                </svg>
            </a>
            <select name="" id="" class="currency w-[100px] border border-slate-300 rounded py-1 px-3">
                <option value="USD" data-symbol="$">USD</option>
                <option value="NGN" data-symbol="₦">Naira</option>
                <option value="GBP" data-symbol="£">GBP</option>
            </select>

        </div>
        <h1 class="text-[#102935] font-bold text-[22px] sm:text-[36px] capitalize text-center">
            select Your Plan
        </h1>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 p-3">
            @foreach ($plans as $i => $plan)
                <form action="{{ route('selected-plan') }}" method="post">
                    @csrf
                    <input type="hidden" name="currency" value="USD" class="currency-input">
                    <input type="hidden" name="plan_id" value="{{ $plan->id }}">
                    <input type="hidden" name="amount" value="{{ $plan->price }}"
                        id="purchase-amount-{{ $i }}">
                    <div class="bg-white p-5 2xl:py-20 border border-[#442AE2] rounded-2xl shadow shadow-xl h-full">
                        <center>
                            <h1
                                class="text-center text-[20px] sm:text-[28px] lg:text-[32px] xl:text-[36px] 2xl:text-[40px] text-[#102935]">
                                {{ $plan->name }}
                            </h1>
                            <h2
                                class=" font-bold text-center text-[20px] sm:text-[28px] lg:text-[32px] xl:text-[36px] 2xl:text-[40px] text-[#102935] mb-7 flex justify-center items-center">
                                <span id="symbol-{{ $i }}" class="mr-2">
                                    $
                                </span>
                                <span id="amount-{{ $i }}" data-original-amount="{{ $plan->price }}">
                                    {{ $plan->price }}
                                </span>
                            </h2>
                            <button type="submit"
                                class="py-2 px-8 mb-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white  text-[14px] sm:text-[15px] lg:text-[16px] xl:text-[18px] 2xl:text-[20px] font-semibold hover:bg-[#442AE2]">
                                Buy Now
                            </button>
                            <span
                                class="text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px] text-[#102935] block mt-4 mb-8">
                                Cancel anytime
                            </span>
                        </center>

                        <ul class="space-y-5 list-none 2xl:p-5">
                            @foreach ($plan->points as $point)
                                <li class="flex">
                                    <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                            stroke="black" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg>
                                    <span
                                        class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">
                                        {{ $point->point }}
                                    </span>
                                </li>
                            @endforeach
                            {{-- <li class="flex">
                            <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                    stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <span
                                class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                                is a long established fact that a reader will be.</span>
                        </li>
                        <li class="flex">
                            <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                    stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <span
                                class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                                is a long established fact that a reader will be.</span>
                        </li>
                        <li class="flex">
                            <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                    stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <span
                                class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                                is a long established fact that a reader will be.</span>
                        </li>
                        <li class="flex">
                            <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                    stroke="black" stroke-width="1.5" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                            <span
                                class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                                is a long established fact that a reader will be.</span>
                        </li> --}}
                        </ul>

                    </div>
                </form>
            @endforeach
            {{-- @for ($i = 0; $i < 3; $i++)
                <form action="{{ route('selected-plan') }}" method="post">
                    @csrf
                    <input type="hidden" name="currency" value="USD" class="currency-input">
                    <input type="hidden" name="plan_id" value="{{ $plans[$i]->id }}">
                    <input type="hidden" name="amount" value="{{ $plans[$i]->price }}"
                        id="purchase-amount-{{ $i }}">
                    <div class="bg-white p-5 2xl:py-20 border border-[#442AE2] rounded-2xl shadow shadow-xl">
                        <center>
                            <h1
                                class="text-center text-[20px] sm:text-[28px] lg:text-[32px] xl:text-[36px] 2xl:text-[40px] text-[#102935]">
                                {{ $plans[$i]->name }}
                            </h1>
                            <h2
                                class=" font-bold text-center text-[20px] sm:text-[28px] lg:text-[32px] xl:text-[36px] 2xl:text-[40px] text-[#102935] mb-7 flex justify-center items-center">
                                <span id="symbol-{{ $i }}" class="mr-2">
                                    $
                                </span>
                                <span id="amount-{{ $i }}" data-original-amount="{{ $plans[$i]->price }}">
                                    {{ $plans[$i]->price }}
                                </span>
                            </h2>
                            <button type="submit"
                                class="py-2 px-8 mb-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white  text-[14px] sm:text-[15px] lg:text-[16px] xl:text-[18px] 2xl:text-[20px] font-semibold hover:bg-[#442AE2]">
                                Buy Now
                            </button>
                            <span
                                class="text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px] text-[#102935] block mt-4 mb-8">
                                Cancel anytime
                            </span>
                        </center>

                        <ul class="space-y-5 list-none 2xl:p-5">
                            <li class="flex">
                                <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                        stroke="black" stroke-width="1.5" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                                <span
                                    class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                                    is a long established fact that a reader will be.</span>
                            </li>
                            <li class="flex">
                                <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                        stroke="black" stroke-width="1.5" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                                <span
                                    class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                                    is a long established fact that a reader will be.</span>
                            </li>
                            <li class="flex">
                                <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                        stroke="black" stroke-width="1.5" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                                <span
                                    class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                                    is a long established fact that a reader will be.</span>
                            </li>
                            <li class="flex">
                                <svg width="16" class="mt-2" height="13" viewBox="0 0 16 13" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                        stroke="black" stroke-width="1.5" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                                <span
                                    class="ml-2 text-[14px] sm:text-[16px] md:text-[17px] lg:text-[18px] xl:text-[22px] 2xl:text-[24px]">It
                                    is a long established fact that a reader will be.</span>
                            </li>
                        </ul>

                    </div>
                </form>
            @endfor --}}
        </div>
    </section>

    <script>
        $(document).ready(function() {
            let exchangeRates = {};
            async function fetchExchangeRates() {
                try {
                    const response = await fetch(`https://api.exchangerate-api.com/v4/latest/USD`);
                    const data = await response.json();
                    exchangeRates = data.rates;
                    console.log(exchangeRates);


                } catch (error) {
                    console.error("Error fetching exchange rates:", error);
                }
            }
            fetchExchangeRates();
            $('.currency').change(function(e) {
                e.preventDefault();
                let currency = $(this).val();
                $('.currency-input').val(currency);
                let exchangeRate = exchangeRates[currency];
                let symbol = $(this).find(':selected').data('symbol');
                let count = "{{count($plans)}}";

                for (let index = 0; index < count; index++) {
                    let amount = $(`#amount-${index}`).data('original-amount');
                    let newAmount = exchangeRate * amount;
                    $(`#purchase-amount-${index}`).val(newAmount);
                    $(`#amount-${index}`).text(newAmount.toFixed(2));
                    $(`#symbol-${index}`).text(symbol);
                }
            });
        });
    </script>
@endsection
