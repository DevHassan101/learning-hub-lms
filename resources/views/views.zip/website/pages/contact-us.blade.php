@extends('website.app')
@section('title', 'Contact us')
@section('main')
    <section class="min-h-[85vh] flex py-10 px-5 lg:px-20  justify-center">
        <div class="bg-gray-100 rounded-3xl py-10 px-5 sm:px-10 lg:px-20 min-w-full">
            <h1 class="text-center text-4xl font-semibold">
                Get in Touch
            </h1>

            <p class="m-auto text-center xl:max-w-[80%] mt-3">
                We’d love to hear from you! Whether you have questions about our courses, need support, or want to
                collaborate, we’re here to help.
            </p>

            <div class="grid sm:grid-cols-2 gap-5 mt-10 xl:w-[80%] m-auto">
                <div class="rounded-xl border border-[#4329E2] text-[#102935] p-5 flex items-center">
                    <svg class="h-[30px] sm:h-[50px] w-[30px] sm:w-[50px]" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 9.00005L10.2 13.65C11.2667 14.45 12.7333 14.45 13.8 13.65L20 9" stroke="#000000"
                            stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        <path
                            d="M3 9.17681C3 8.45047 3.39378 7.78123 4.02871 7.42849L11.0287 3.5396C11.6328 3.20402 12.3672 3.20402 12.9713 3.5396L19.9713 7.42849C20.6062 7.78123 21 8.45047 21 9.17681V17C21 18.1046 20.1046 19 19 19H5C3.89543 19 3 18.1046 3 17V9.17681Z"
                            stroke="#000000" stroke-width="2" stroke-linecap="round" />
                    </svg>
                    <a href="mailto:clinEdlearninghub@gmail.com" class="text-lg font-medium ml-2 hover:underline">
                        clinEdlearninghub@gmail.com
                    </a>
                </div>
                <div class="rounded-xl border border-[#4329E2] text-[#102935] p-5 flex items-center">
                    <svg class="h-[30px] sm:h-[50px] w-[30px] sm:w-[50px]" viewBox="0 0 24 24" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M6.014 8.00613C6.12827 7.1024 7.30277 5.87414 8.23488 6.01043L8.23339 6.00894C9.14051 6.18132 9.85859 7.74261 10.2635 8.44465C10.5504 8.95402 10.3641 9.4701 10.0965 9.68787C9.7355 9.97883 9.17099 10.3803 9.28943 10.7834C9.5 11.5 12 14 13.2296 14.7107C13.695 14.9797 14.0325 14.2702 14.3207 13.9067C14.5301 13.6271 15.0466 13.46 15.5548 13.736C16.3138 14.178 17.0288 14.6917 17.69 15.27C18.0202 15.546 18.0977 15.9539 17.8689 16.385C17.4659 17.1443 16.3003 18.1456 15.4542 17.9421C13.9764 17.5868 8 15.27 6.08033 8.55801C5.97237 8.24048 5.99955 8.12044 6.014 8.00613Z"
                            fill="#0F0F0F" />
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M12 23C10.7764 23 10.0994 22.8687 9 22.5L6.89443 23.5528C5.56462 24.2177 4 23.2507 4 21.7639V19.5C1.84655 17.492 1 15.1767 1 12C1 5.92487 5.92487 1 12 1C18.0751 1 23 5.92487 23 12C23 18.0751 18.0751 23 12 23ZM6 18.6303L5.36395 18.0372C3.69087 16.4772 3 14.7331 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12C21 16.9706 16.9706 21 12 21C11.0143 21 10.552 20.911 9.63595 20.6038L8.84847 20.3397L6 21.7639V18.6303Z"
                            fill="#0F0F0F" />
                    </svg>
                    <a href="https://wa.me/2348167506755" class="text-lg font-medium ml-2 hover:underline">
                        +2348167506755
                    </a>
                </div>

            </div>

            <div class=" mt-10 xl:w-[80%] m-auto">
                <form action="{{route('contact-us.store')}}" method="POST">
                    @csrf
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="mb-4">
                            <label for="">
                                Full Name
                            </label>
                            <input type="text" placeholder="fullname" name="name" value="{{ old('name') }}"
                                class="border border-[#482EE3] bg-transparent rounded block w-full mt-1">
                            @error('name')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-4">
                            <label for="">
                                Email
                            </label>
                            <input type="email" name="email" placeholder="email" value="{{ old('email') }}"
                                class="border border-[#482EE3] bg-transparent rounded block w-full mt-1">
                            @error('email')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                    </div>
                    <div class="mb-4">
                        <label for="message">
                            Message
                        </label>
                        <textarea name="message" id="message" cols="30" rows="10"
                            class="border border-[#482EE3] bg-transparent rounded block w-full mt-1">{{ old('message')}}</textarea>
                        @error('message')
                            <span class="text-red-500">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
    
                    <button type="submit"
                        class="float-right text-white bg-gradient-to-r from-[#442AE2] to-[#6956E7] hover:bg-[#442AE2] focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 sm:px-10 py-2 text-center">
                        Send
                    </button>

                </form>
            </div>
        </div>
    </section>
@endsection
