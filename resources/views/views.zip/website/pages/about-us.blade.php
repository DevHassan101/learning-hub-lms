@extends('website.app')

@section('main')
    <section class="py-16 px-5 lg:px-20  text-[#102935]">
        <div class="grid grid-cols-5 bg-gray-100 rounded-3xl py-10 px-5 sm:px-10 lg:px-20">
            <div class="my-auto col-span-5 pr-5">
                <h1 class="text-center text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#493BE6]">
                    ABOUT US
                </h1>
                <p class="text-center text-lg mt-4">
                    Empowering Healthcare Students, Professionals and Transforming Careers.
                    At Clined Learning Hub, we don’t just teach—we equip, inspire, and elevate.
                </p>
                <p class="text-center text-lg">
                    Whether you're a student preparing for exams, a healthcare professional looking to upskill, or an
                    employer aiming to boost workforce productivity, we provide cutting-edge, expert-led courses tailored to
                    your success.
                </p>
            </div>
            {{-- <div class="flex justify-end col-span-2">
                <img src="{{ asset('about-us.webp') }}" class="h-[400px]" alt="">
            </div> --}}
        </div>

        <p class="text-center text-xl sm:text-2xl md:text-3xl font-bold mt-10">
            Our platform is designed to meet the evolving demands of the healthcare industry by offering
        </p>
        <ul class="my-5 list-disc px-5">
            <li class="text-sm lg:text-xl py-2"> High-impact courses for students and professionals across various healthcare fields
            </li>
            <li class="text-sm lg:text-xl py-2">Flexible, self-paced learning that fits your schedule—anytime, anywhere</li>
            <li class="text-sm lg:text-xl py-2">Real-world insights from top healthcare educators and industry leaders</li>
            <li class="text-sm lg:text-xl py-2">Custom workforce training solutions for organizations seeking to enhance staff
                performance</li>
        </ul>
        <p class="text-sm lg:text-lg font-semibold">
            With our growing catalog of specialized courses, we make learning practical, engaging, and career-focused. Our
            mission is simple: to bridge the gap between education and professional excellence, ensuring that healthcare
            providers are equipped with the skills and confidence to thrive.
        </p>
    </section>
    {{-- <div style="background: url({{ asset('banner-completed-course.png') }})"
        class=" text-white font-semibold min-h-[400px] flex justify-center items-center">
        <p class="max-w-[80%] text-center text-2xl">
            With our growing catalog of specialized courses, we make learning practical, engaging, and career-focused. Our
            mission is simple: to bridge the gap between education and professional excellence, ensuring that healthcare
            providers are equipped with the skills and confidence to thrive.
        </p>
    </div> --}}
    <div class="bg-gray-100 rounded-3xl py-10 px-5 sm:px-10 lg:px-20">
        <div class="my-auto pr-5">
            <h1 class="text-center text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#493BE6]">
                Ready to take the next step?
            </h1>
            <p class="text-lg mt-4 text-center">
                Join Clined Learning Hub today and gain access to world-class healthcare education that sets you apart.
            </p>
            <p class="text-lg sm:text-xl font-medium text-center mt-3">
                Start Learning Now! <br>
            </p>
            <div class="flex justify-center">
                <a href="{{url('programs')}}" class="bg-[#493BE6] my-2 py-3 px-10 rounded-xl text-white text-[14px] sm:text-[15px] lg:text-[16px] font-medium">
                    SIGNUP
                </a>
            </div>
        </div>
    </div>
@endsection
