@extends('website.app')
@section('title', 'Lectures')
@section('main')

    <section class="py-10 px-5 lg:p-20 w-full">
        <div class="w-full">
            @if ($lecture->file)
                <video src="{{ asset($lecture->file) }}" id="video-lecture" controls class="w-full max-h-[600px]"></video>
            @endif
            @if ($lecture->attachments)
                <div>
                    <a href="{{ asset($lecture->attachments) }}" target="_blank"
                        class="text-[#493BE6] font-semibold float-right text-lg underline">Attachment</a>
                </div>
            @endif

        </div>
        <div>

            @forelse ($course->lessons as $lesson)
                <div class="sm:flex border-b-2 border-[#6651E7] py-5 items-center">
                    <div class="min-w-[210px]">
                        @if (is_null($lesson->file))
                            <img src="{{ asset('pdf.png') }}" class="sm:h-40" alt="" srcset="">
                        @else
                            <img src="{{ asset($lesson->thumbnail) }}" class="sm:h-40" alt="" srcset="">
                        @endif
                    </div>
                    <div class="w-full p-4">
                        <div class="sm:flex justify-between items-center">
                            @php
                                $url = is_null($lesson->file)
                                    ? 'course/' . $course->slug . '/' . $lesson->slug . '/lectures-pdf'
                                    : // ? asset($lesson->attachments)
                                        'course/' . $course->slug . '/' . $lesson->slug;
                            @endphp
                            <a href="{{ url($url) }}" target="{{ is_null($lesson->file) ? '_blank' : '' }}" class="text-[#102935] font-medium text-[24px] md:text-[28px] lg:text-[34px] hover:underline">
                                {{ $lesson->title }}
                            </a>
                            <a href="{{ url($url) }}" target="{{ is_null($lesson->file) ? '_blank' : '' }}"
                                class="text-[#102935] text-[14px] md:text-[16px] lg:text-[18px] underline">
                                Read Script
                            </a>
                        </div>
                        <h2 class="text-[18px] md:text-[24px] lg:text-[27px] text-[#102935] my-3">
                            By CHINAZOM NDUKWU
                        </h2>
                        <p class="text-[16px] md:text-[18px] lg:text-[20px] text-[#102935]">
                            {{ $lesson->description }}
                        </p>
                    </div>
                </div>

            @empty
            @endforelse
            <div class="sm:flex border-b-2 border-[#6651E7] py-5 items-center">
                <div class="w-full sm:w-auto">
                    <img src="{{ asset('flash-card.png') }}" class="w-full sm:w-auto" alt="" srcset="">
                    {{-- <video src=""></video> --}}
                </div>
                <div class="w-full p-4">
                    <div class="sm:flex justify-between items-center">
                        <button onclick="flashCard()"
                            class="hover:underline text-[#102935] font-medium text-[24px] md:text-[28px] lg:text-[34px]">
                            Flash Card
                        </button>
                    </div>
                    <p class="text-[16px] md:text-[18px] lg:text-[20px] text-[#102935]">
                        Flashcards are learning tools that consist of a card with a question on one side and the answer on
                        the other. They are commonly used for memorization and reinforcement of information, such as
                        vocabulary, concepts, or facts. Flashcards can be physical cards or digital apps, making them
                        versatile for various study methods. </p>
                </div>
            </div>
            <div class="sm:flex border-b-2 border-[#6651E7] py-5 items-center">
                <div class="w-full sm:w-auto">
                    <img src="{{ asset('practice-quiz.png') }}" class="w-full sm:w-auto" alt="" srcset="">
                    {{-- <video src=""></video> --}}
                </div>
                <div class="w-full p-4">
                    <div class="sm:flex justify-between items-center">
                        <a href="{{ route('course-quiz', ['course' => $course->slug]) }}"
                            class="hover:underline text-[#102935] font-medium text-[24px] md:text-[28px] lg:text-[34px]">
                            Practice Quiz
                        </a>
                    </div>
                    <p class="text-[16px] md:text-[18px] lg:text-[20px] text-[#102935]">
                        Flashcards are learning tools that consist of a card with a question on one side and the answer on
                        the other. They are commonly used for memorization and reinforcement of information, such as
                        vocabulary, concepts, or facts. Flashcards can be physical cards or digital apps, making them
                        versatile for various study methods.
                    </p>
                </div>
            </div>
            <div class="sm:flex border-b-2 border-[#6651E7] py-5 items-center">
                <div class="w-full sm:w-auto">
                    <img src="{{ asset('practice-exam.png') }}" class="w-full sm:w-auto" alt="" srcset="">
                    {{-- <video src=""></video> --}}
                </div>
                <div class="w-full p-4">
                    <div class="sm:flex justify-between items-center">
                        <a href="{{ url('course/' . $course->slug . '/exam') }}"
                            class="hover:underline text-[#102935] font-medium text-[24px] md:text-[28px] lg:text-[34px]">
                            Practice Exam
                        </a>
                    </div>
                    <p class="text-[16px] md:text-[18px] lg:text-[20px] text-[#102935]">
                        A practice quiz is a tool used to assess knowledge and understanding of a specific subject or topic.
                        It typically consists of a series of questions that help users gauge their grasp of the material and
                        identify areas needing improvement. Practice quizzes can be used in educational settings or for
                        self-study, helping reinforce learning through active engagement.
                    </p>
                </div>
            </div>
        </div>
    </section>


    {{-- <section class="explanation-modal hidden" id="flashcard-modal">
        <div class="modal-content border border-[#472EE3] py-14">
            <button class="close-btn text-[#472EE3] font-bold text-[22px]" onclick="cancelFlashcard()">✕</button>
            <h2 class="text-[20px] font-bold text-[#102935]">Flash Cards</h2>
            <p class="text-[18px] font-bold text-[#102935] my-5">Pharmacokinetics</p>
            <p class="text-[18px] text-[#102935]">
                Pharmacokinetics is the branch of pharmacology that studies the movement of drugs within the body. It
                focuses on four key processes: absorption, distribution, metabolism, and excretion (ADME), determining how a
                drug is absorbed into the bloodstream, distributed to tissues, broken down into active or inactive forms,
                and eliminated from the body.
            </p>
            <div class="mt-5">
                <button
                    class="py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500 min-w-[100px] mr-5">
                    Previous
                </button>
                <button
                    class="py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500 min-w-[100px]">
                    Next
                </button>
            </div>
        </div>
    </section> --}}


    <section class="explanation-modal hidden" id="flashcard-modal">
        <div class="modal-content border border-[#472EE3] py-14">
            <button class="close-btn text-[#472EE3] font-bold text-[22px]" onclick="cancelFlashcard()">✕</button>
            <h2 class="text-[20px] font-bold text-[#102935]">Flash Cards</h2>
            <div id="flashCardContainer">
                @forelse ($course->flashCards as $index => $flashCard)
                    <div class="flash-card hidden" data-index="{{ $index }}">
                        <p class="text-[18px] font-bold text-[#102935] my-5">{{ $flashCard->title }}</p>
                        <p class="text-[18px] text-[#102935]">
                            {{ $flashCard->description }}
                        </p>
                    </div>
                @empty
                    <p>No Flashcards Available</p>
                @endforelse
            </div>
            <div class="mt-5">
                <button id="prevBtn"
                    class="py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500 min-w-[100px] mr-5">
                    Previous
                </button>
                <button id="nextBtn"
                    class="py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500 min-w-[100px]">
                    Next
                </button>
            </div>
        </div>
    </section>


    <script>
        function flashCard() {
            document.getElementById('flashcard-modal').classList.remove('hidden');
        }

        function cancelFlashcard() {
            document.getElementById('flashcard-modal').classList.add('hidden');
        }

        document.addEventListener("DOMContentLoaded", function() {
            let flashCards = document.querySelectorAll(".flash-card");
            let currentIndex = 0;

            function showFlashCard(index) {
                flashCards.forEach((card, i) => {
                    card.classList.toggle("hidden", i !== index);
                });
            }

            document.getElementById("prevBtn").addEventListener("click", function() {
                currentIndex = (currentIndex - 1 + flashCards.length) % flashCards.length;
                showFlashCard(currentIndex);
            });

            document.getElementById("nextBtn").addEventListener("click", function() {
                currentIndex = (currentIndex + 1) % flashCards.length;
                showFlashCard(currentIndex);
            });

            // Show the first flashcard initially
            showFlashCard(currentIndex);

            let videoElement = document.getElementById('video-lecture');
            videoElement.onended = function() {
                $.ajax({
                    type: "POST",
                    url: "{{ route('user-lesson') }}",
                    headers: {
                        'X-CSRF-TOKEN': "{{ csrf_token() }}"
                    },
                    data: {
                        lessonId: {{ $lecture->id }},
                        userCourseId: {{ $userCourse->id }}
                    },
                    success: function(response) {
                        console.log(response);
                    }
                });
            }
        });
    </script>
@endsection
