@extends('website.app')
@section('title', 'Quiz')
@section('main')
    <section class="courses h-[85vh] flex items-center justify-center">
        <h1 class="text-white text-[48px] font-bold">
            Quiz
        </h1>
    </section>

    <section class="min-h-[283px] py-10 px-5 lg:p-20 w-full">
        <div class="flex justify-between items-center">
            <h1 class="text-[22px] sm:text-[30px] md:text-[36px] font-bold text-[#102935]">
                Pharmacology Quiz
            </h1>
            @if ($userQuiz->type == 'time restricted')
                <span id="counterDisplay"
                    class="text-[14px] sm:text-[16px] md:text-[20px] font-semibold text-[#102935]"></span>
            @endif
        </div>

        <h2 class="text-[23px] sm:text-[30px] md:text-[36px] text-[#102935] mb-4">
            Question <span id="question-count">1</span> of {{ count($quizQuestions) }}
        </h2>
        <form action="{{ route('submit-quiz', ['quizId' => $userQuiz->user_quiz_id]) }}" id="quizForm" method="post">
            @csrf
            @foreach ($quizQuestions as $index => $question)
                <div class="question-card hidden" data-index="{{ $index }}">
                    <p class="text-[20px] sm:text-[25px] md:text-[32px] text-[#102935] mb-4">
                        {{ $question->question }}
                    </p>
                    <div>
                        <div
                            class="text-[20px] sm:text-[25px] md:text-[32px] text-[#102935] bg-[#D9D9D9] flex items-center py-2 px-5 mb-5">
                            <input type="radio" name="answer[{{ $question->id }}]" value="option_a"
                                class="mr-5 h-5 w-5 ring-0 focus:ring-0 focus:border-none">
                            {{ $question->option_a }}
                        </div>
                        <div
                            class="text-[20px] sm:text-[25px] md:text-[32px] text-[#102935] bg-[#D9D9D9] flex items-center py-2 px-5 mb-5">
                            <input type="radio" name="answer[{{ $question->id }}]" value="option_b"
                                class="mr-5 h-5 w-5 ring-0 focus:ring-0 focus:border-none">
                            {{ $question->option_b }}
                        </div>
                        <div
                            class="text-[20px] sm:text-[25px] md:text-[32px] text-[#102935] bg-[#D9D9D9] flex items-center py-2 px-5 mb-5">
                            <input type="radio" name="answer[{{ $question->id }}]" value="option_c"
                                class="mr-5 h-5 w-5 ring-0 focus:ring-0 focus:border-none">
                            {{ $question->option_c }}
                        </div>
                        <div
                            class="text-[20px] sm:text-[25px] md:text-[32px] text-[#102935] bg-[#D9D9D9] flex items-center py-2 px-5 mb-5">
                            <input type="radio" name="answer[{{ $question->id }}]" value="option_d"
                                class="mr-5 h-5 w-5 ring-0 focus:ring-0 focus:border-none">
                            {{ $question->option_d }}
                        </div>
                    </div>
                </div>
            @endforeach
            <input type="hidden" name="time_spent" id="timeSpent">


            <div class="flex justify-between items-center mt-10">
                <button id="prevBtn" type="button"
                    class="{{ count($quizQuestions) == 1 ? 'hidden' : '' }} py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500 w-[150px]">
                    Previous
                </button>
                <button id="nextBtn" type="button"
                    class="{{ count($quizQuestions) == 1 ? 'hidden' : '' }} py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500 w-[150px]">
                    Next
                </button>
                <button type="submit" href="{{ url('course/quiz/1/result') }}" id="submitBtn"
                    class="{{ count($quizQuestions) != 1 ? 'hidden' : '' }} py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500 w-[150px]">
                    Submit
                </button>
            </div>
        </form>
    </section>

    {{-- @push('script')
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                let flashCards = document.querySelectorAll(".question-card");
                let currentIndex = 0;
                let form = document.getElementById("quizForm");
                let isFormSubmitted = false;
                let isWarningShown = false;
                let isTimeUp = false;
                if (currentIndex == 0) {
                    document.getElementById('prevBtn').classList.add('hidden');
                }

                function showFlashCard(index) {
                    flashCards.forEach((card, i) => {
                        card.classList.toggle("hidden", i !== index);
                    });
                }
                let totalQuestions = {{ count($quizQuestions) }} - 1;
                document.getElementById("prevBtn").addEventListener("click", function() {
                    currentIndex = (currentIndex - 1 + flashCards.length) % flashCards.length;
                    showFlashCard(currentIndex);
                    document.getElementById('question-count').innerText = currentIndex + 1;
                    if (currentIndex != totalQuestions) {
                        document.getElementById('nextBtn').classList.remove('hidden');
                        document.getElementById('submitBtn').classList.add('hidden');
                    }
                    if (currentIndex == 0) {
                        document.getElementById('prevBtn').classList.add('hidden');
                    } else {
                        document.getElementById('prevBtn').classList.remove('hidden');
                    }
                });

                document.getElementById("nextBtn").addEventListener("click", function() {
                    currentIndex = (currentIndex + 1) % flashCards.length;
                    showFlashCard(currentIndex);
                    document.getElementById('question-count').innerText = currentIndex + 1;
                    if (currentIndex == totalQuestions) {
                        document.getElementById('nextBtn').classList.add('hidden');
                        document.getElementById('submitBtn').classList.remove('hidden');
                    }
                    if (currentIndex == 0) {
                        document.getElementById('prevBtn').classList.add('hidden');
                    } else {
                        document.getElementById('prevBtn').classList.remove('hidden');
                    }
                });

                // Show the first flashcard initially
                showFlashCard(currentIndex);

                // Show warning alert
                function showWarning() {
                    if (!isFormSubmitted && !isWarningShown) {
                        isWarningShown = true;
                        const confirmLeave = confirm(
                            "WARNING: Leaving this page will automatically submit your quiz with current answers. Do you want to leave?"
                        );

                        if (confirmLeave) {
                            form.submit();
                            isFormSubmitted = true;
                            return true;
                        } else {
                            isWarningShown = false;
                            return false;
                        }
                    }
                    return isFormSubmitted;
                }

                // Handle page visibility change (when user switches tabs)
                document.addEventListener("visibilitychange", function() {
                    if (document.visibilityState === "hidden" && !isFormSubmitted && !isTimeUp) {
                        const shouldSubmit = showWarning();
                        if (shouldSubmit) {
                            form.submit();
                            isFormSubmitted = true;
                        }
                    }
                });

                // Handle page unload (browser close, navigation away)
                window.addEventListener("beforeunload", function(e) {
                    if (!isFormSubmitted && !isTimeUp) {
                        e.preventDefault();
                        e.returnValue = "";
                    }
                });


                // Handle normal form submission
                form.addEventListener("submit", function() {
                    isFormSubmitted = true;
                });

                // Handle navigation through browser buttons
                window.addEventListener("popstate", function(e) {
                    if (!isFormSubmitted) {
                        const shouldSubmit = showWarning();
                        if (!shouldSubmit) {
                            history.pushState(null, null, window.location.pathname);
                        }
                    }
                });

                // Handle clicks on links leading away from the page
                document.addEventListener("click", function(e) {
                    const clicked = e.target.closest("a");
                    if (clicked && !clicked.hasAttribute("download") &&
                        clicked.href && !clicked.href.startsWith("#") &&
                        !isFormSubmitted) {
                        e.preventDefault();

                        const shouldSubmit = showWarning();
                        if (shouldSubmit) {
                            window.location.href = clicked.href;
                        }
                    }
                });

                // Additional protection for modern browsers that might ignore beforeunload
                window.onunload = function() {
                    if (!isFormSubmitted) {
                        form.submit();
                        isFormSubmitted = true;
                    }
                };

            });
        </script>
        @if ($userQuiz->type == 'time restricted')
            <script>
                function preventExit(event) {
                    event.preventDefault();
                    event.returnValue = ''; // Required for modern browsers
                }

                function startReverseCounter(minutes) {
                    let totalSeconds = minutes * 60;
                    let display = document.getElementById("counterDisplay");
                    let form = document.getElementById("quizForm");
                    let timeSpent = 0; // Track time spent
                    let timeSpentInput = document.getElementById("timeSpent");

                    let isTimeUp = false;
                    let isFormSubmitted = false;

                    function updateCounter() {
                        let min = Math.floor(totalSeconds / 60);
                        let sec = totalSeconds % 60;
                        display.innerText = `${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;

                        if (totalSeconds === 0) {
                            clearInterval(interval);
                            display.innerText = "Time's up!";
                            isTimeUp = true;
                            isFormSubmitted = true;

                            // Remove the beforeunload event since the quiz is submitted
                            window.removeEventListener("beforeunload", preventExit);

                            if (form) {
                                form.submit();
                            }
                        } else {
                            totalSeconds--;
                        }

                        timeSpent++;
                        timeSpentInput.value = timeSpent;
                    }

                    // Add the beforeunload event to prevent accidental exit
                    window.addEventListener("beforeunload", preventExit);

                    updateCounter(); // Show initial value
                    let interval = setInterval(updateCounter, 1000);
                }

                let minutes = {{ $course->quiz_duration ?? 0 }};
                document.addEventListener("DOMContentLoaded", function() {
                    startReverseCounter(minutes);
                });
            </script>
        @endif
    @endpush --}}

    @push('script')
        <script>
            let isFormSubmitted = false;
            let isTimeUp = false;
            let isWarningShown = false;

            // Prevent accidental exit
            function preventExit(event) {
                if (!isFormSubmitted && !isTimeUp) {
                    event.preventDefault();
                    event.returnValue = '';
                }
            }

            document.addEventListener("DOMContentLoaded", function() {
                let flashCards = document.querySelectorAll(".question-card");
                let currentIndex = 0;
                let form = document.getElementById("quizForm");

                // Hide previous button initially
                if (currentIndex == 0) {
                    document.getElementById('prevBtn').classList.add('hidden');
                }

                function showFlashCard(index) {
                    flashCards.forEach((card, i) => {
                        card.classList.toggle("hidden", i !== index);
                    });
                }

                let totalQuestions = {{ count($quizQuestions) }} - 1;

                document.getElementById("prevBtn").addEventListener("click", function() {
                    currentIndex = (currentIndex - 1 + flashCards.length) % flashCards.length;
                    showFlashCard(currentIndex);
                    document.getElementById('question-count').innerText = currentIndex + 1;

                    if (currentIndex != totalQuestions) {
                        document.getElementById('nextBtn').classList.remove('hidden');
                        document.getElementById('submitBtn').classList.add('hidden');
                    }

                    if (currentIndex == 0) {
                        document.getElementById('prevBtn').classList.add('hidden');
                    } else {
                        document.getElementById('prevBtn').classList.remove('hidden');
                    }
                });

                document.getElementById("nextBtn").addEventListener("click", function() {
                    currentIndex = (currentIndex + 1) % flashCards.length;
                    showFlashCard(currentIndex);
                    document.getElementById('question-count').innerText = currentIndex + 1;

                    if (currentIndex == totalQuestions) {
                        document.getElementById('nextBtn').classList.add('hidden');
                        document.getElementById('submitBtn').classList.remove('hidden');
                    }

                    if (currentIndex == 0) {
                        document.getElementById('prevBtn').classList.add('hidden');
                    } else {
                        document.getElementById('prevBtn').classList.remove('hidden');
                    }
                });

                // Show first flashcard initially
                showFlashCard(currentIndex);

                // Add event listener to prevent accidental exit
                window.addEventListener("beforeunload", preventExit);

                // Show warning before leaving
                function showWarning() {
                    if (!isFormSubmitted && !isWarningShown) {
                        isWarningShown = true;
                        const confirmLeave = confirm(
                            "WARNING: Leaving this page will automatically submit your quiz with current answers. Do you want to leave?"
                        );

                        if (confirmLeave) {
                            isFormSubmitted = true;
                            window.removeEventListener("beforeunload", preventExit);
                            form.submit();
                            return true;
                        } else {
                            isWarningShown = false;
                            return false;
                        }
                    }
                    return isFormSubmitted;
                }

                // Handle page visibility change (tab switch)
                document.addEventListener("visibilitychange", function() {
                    if (document.visibilityState === "hidden" && !isFormSubmitted && !isTimeUp) {
                        showWarning();
                    }
                });

                // Handle navigation through browser buttons
                window.addEventListener("popstate", function() {
                    if (!isFormSubmitted && !isTimeUp) {
                        const shouldSubmit = showWarning();
                        if (!shouldSubmit) {
                            history.pushState(null, null, window.location.pathname);
                        }
                    }
                });

                // Handle clicks on links leading away from the page
                document.addEventListener("click", function(e) {
                    const clicked = e.target.closest("a");
                    if (clicked && !clicked.hasAttribute("download") &&
                        clicked.href && !clicked.href.startsWith("#") &&
                        !isFormSubmitted && !isTimeUp) {
                        e.preventDefault();
                        const shouldSubmit = showWarning();
                        if (shouldSubmit) {
                            window.location.href = clicked.href;
                        }
                    }
                });

                // Additional protection for modern browsers that might ignore beforeunload
                window.onunload = function() {
                    if (!isFormSubmitted && !isTimeUp) {
                        form.submit();
                        isFormSubmitted = true;
                    }
                };

                // Ensure the form is properly marked as submitted when the user submits it
                form.addEventListener("submit", function() {
                    isFormSubmitted = true;
                    window.removeEventListener("beforeunload", preventExit);
                });
            });

            @if ($userQuiz->type == 'time restricted')
                function startReverseCounter(minutes) {
                    let totalSeconds = minutes * 60;
                    let display = document.getElementById("counterDisplay");
                    let form = document.getElementById("quizForm");
                    let timeSpent = 0;
                    let timeSpentInput = document.getElementById("timeSpent");

                    function updateCounter() {
                        let min = Math.floor(totalSeconds / 60);
                        let sec = totalSeconds % 60;
                        display.innerText = `${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;

                        if (totalSeconds === 0) {
                            clearInterval(interval);
                            display.innerText = "Time's up!";
                            isTimeUp = true;
                            isFormSubmitted = true;

                            // Remove the beforeunload event since the quiz is submitted
                            window.removeEventListener("beforeunload", preventExit);

                            if (form) {
                                form.submit();
                            }
                        } else {
                            totalSeconds--;
                        }

                        timeSpent++;
                        timeSpentInput.value = timeSpent;
                    }

                    updateCounter(); // Show initial value
                    let interval = setInterval(updateCounter, 1000);
                }

                let minutes = {{ $course->quiz_duration ?? 0 }};
                document.addEventListener("DOMContentLoaded", function() {
                    startReverseCounter(minutes);
                });
            @endif
            history.pushState(null, "", location.href);
            window.onpopstate = function() {
                history.go(1);
            };
        </script>
    @endpush

@endsection
