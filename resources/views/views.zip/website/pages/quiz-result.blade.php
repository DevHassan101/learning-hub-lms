@extends('website.app')
@section('title', 'Quiz Result')
@section('main')
    <section class="courses h-[85vh] flex items-center justify-center">
        <h1 class="text-white text-[48px] font-bold">
            Quiz Result
        </h1>
    </section>

    <section class="min-h-[283px] py-10 px-5 lg:p-20 w-full">
        <div class="grid sm:grid-cols-2">
            <div>
                <h3 class="text-[25px] sm:text-[30px] md:text-[36px] font-bold text-[#102935] mb-3">
                    Result
                </h3>
                <p class="text-[20px] sm:text-[25px] md:text-[32px] text-[#102935] mb-3">
                    Total Questions : {{ $totalQuestions }}
                </p>
                <p class="text-[20px] sm:text-[25px] md:text-[32px] text-[#102935] mb-3">
                    Attempted Questions : {{ count($attemptedQuestions) }}
                </p>
                <p class="text-[20px] sm:text-[25px] md:text-[32px] text-[#102935] mb-3">
                    Correct Answers : {{ $correctAnswers }}
                </p>
                <p class="text-[20px] sm:text-[25px] md:text-[32px] text-[#102935] mb-3">
                    Percentage : {{ $percentage }}%
                </p>
                @if ($userQuiz->type == 'time restricted')
                    <p class="text-[20px] sm:text-[25px] md:text-[32px] text-[#102935] mb-3">
                        Time Spent : {{ $userQuiz->time_spent }}
                    </p>
                @endif
                <h5 class="text-[20px] sm:text-[25px] md:text-[32px] text-[#102935] font-bold mb-5">
                    You must study hard
                </h5>
                <div class="sm:flex">
                    <a href="{{ url('course/quiz/' . $userQuiz->user_quiz_id . '/result/answers') }}"
                        class="text-nowrap block sm:inline mb-2 sm:mb-0 py-2 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[12px] md:text-[13px] lg:text-[16px] font-semibold hover:bg-indigo-500 min-w-[130px] md:min-w-[140px] lg:min-w-[150px]">
                        Check answers
                    </a>
                    <a href="{{ url('course/' . $userQuiz->course->slug . '/quiz') }}"
                        class="text-nowrap block sm:inline mb-2 sm:mb-0 py-2 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[12px] md:text-[13px] lg:text-[16px] font-semibold hover:bg-indigo-500 min-w-[130px] md:min-w-[140px] lg:min-w-[150px] sm:mx-3">
                        Try again
                    </a>
                    <a href="{{ route('course') }}"
                        class="text-nowrap block sm:inline mb-2 sm:mb-0 py-2 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[12px] md:text-[13px] lg:text-[16px] font-semibold hover:bg-indigo-500 min-w-[130px] md:min-w-[140px] lg:min-w-[150px]">
                        Back to course
                    </a>
                </div>

            </div>
            <div class="flex justify-center items-center">
                <img src="{{ asset('result.png') }}" alt="" srcset="">
            </div>
        </div>
    </section>
    @push('script')
        <script type="text/javascript">
            history.pushState(null, "", location.href);
            window.addEventListener("popstate", function(event) {
                alert("You can not go backward");
            });
        </script>
    @endpush
    @push('head')
        <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
        <meta http-equiv="Pragma" content="no-cache">
        <meta http-equiv="Expires" content="0">
    @endpush
@endsection
