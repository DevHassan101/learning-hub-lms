@extends('website.app')

@section('main')
    <section class="py-16 px-5 lg:px-20 bg-gray-100 text-[#102935]">
        <div class="max-w-4xl mx-auto">
            <h1 class="text-3xl lg:text-4xl font-bold text-center text-[#493BE6] uppercase mb-2">
                Terms and Conditions
            </h1>
        </div>
        <h2 class="text-md lg:text-xl font-semibold text-center uppercase mb-5">
            Welcome to ClinEd Learning Hub.
        </h2>
        <p class="text-center text-lg mb-10">
            By using this website, you agree to the our terms and conditions outlined below.
            <br>
            If you do not agree, please refrain from using our services.
        </p>

        <div class="bg-white p-6 shadow-lg rounded-lg">
            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Introduction</h2>
            <p class="text-gray-700 mb-5">
                Welcome to Clined Learning Hub ("we," "our," or "us"). These Terms and Conditions ("Terms") govern your use
                of our website and services. By accessing or using our platform, you agree to comply with these Terms. If
                you do not agree, please do not use our services.
            </p>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">User Eligibility</h2>
            <p class="text-gray-700 mb-2">
                You must be at least 18 years old or have parental/guardian consent to use our platform. By using our
                services, you confirm that you meet this requirement.
            </p>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Account Registration and Security</h2>
            <div class="text-gray-700 mb-5">
                <p>
                    To access certain services, you must create an account.
                    You are responsible for maintaining the confidentiality of your account credentials.
                </p>
                <p>
                    Account details should be personal and not to be shared with a third party.
                    You agree to provide accurate and up-to-date information during registration.
                    We reserve the right to suspend or terminate accounts that violate these Terms.
                </p>
            </div>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Payments and Refunds</h2>
            <div class="text-gray-700 mb-5">
                <p>
                    Some services require payment, and fees are stated at the time of purchase.
                </p>
                <p>
                    All transactions are processed securely. We do not store payment information.
                </p>
                <p>
                    Refund requests are subject to our refund policy. If eligible, refunds will be processed within a
                    specified time-frame.
                </p>
            </div>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">User Conduct</h2>
            <div class="text-gray-700 mb-5">
                <p>
                    By using our services, you agree not to:
                </p>
                <p>
                    Engage in illegal or fraudulent activities.
                </p>
                <p>
                    Post or share offensive, harmful, or inappropriate content.
                </p>
                <p>
                    Attempt to interfere with our platform’s security or operations.
                </p>
            </div>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Termination of Access</h2>
            <div class="text-gray-700 mb-5">
                <p>
                    We reserve the right to suspend or terminate your account if you violate these Terms or engage in
                    activities that harm our platform or users.
                </p>
            </div>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Disclaimer of Warranties</h2>
            <div class="text-gray-700 mb-5">
                <p>
                    Our services are provided "as is" without warranties of any kind.
                </p>
                <p>
                    We do not guarantee uninterrupted or error-free access to our platform.
                </p>
            </div>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Limitation of Liability</h2>
            <p class="text-gray-700 mb-5">
                To the maximum extent permitted by law, Clined Learning Hub is not liable for any direct, indirect,
                incidental, or consequential damages resulting from your use of our platform.
            </p>

            <h2 class="text-xl lg:text-2xl font-semibold mb-4">Contact Us</h2>
            <p class="text-gray-700 mb-5">
                For any questions or concerns regarding these Terms, please contact us at:
            </p>
            <p class="text-gray-900 font-semibold">
                📧 Email: <a href="mailto:ClinEdlearninghub@gmail.com"
                    class="text-[#493BE6] hover:underline">ClinEdlearninghub@gmail.com</a>
                Website: <a href="{{ url('/') }}">clinedlearninghub.com</a>
            </p>
        </div>
    </section>
@endsection
