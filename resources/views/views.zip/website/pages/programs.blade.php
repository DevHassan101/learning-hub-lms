@extends('website.app')
@section('title', 'Subscriptions')
@section('main')
    <section class="min-h-[85vh] flex py-10 justify-center">
        <div class="grid grid-cols-3 gap-8 lg:px-20 w-full">
            @foreach ($categories as $category)
                <div class="h-[200px] relative">
                    <a href="{{url('plan/' . encrypt($category->title))}}">
                        <img src="{{ $category->banner }}" class="h-full min-w-full" alt="">
                        <span class="bg-white bg-opacity-70 text-[22px] absolute bottom-0 opacity-90 px-5">{{ $category->title }}</span>    
                    </a>
                </div>
            @endforeach
        </div>
    </section>
@endsection
