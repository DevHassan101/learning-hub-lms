@extends('layouts.app2')
@section('main')
    <style>
        h2,
        p {
            margin-bottom: 20px;
            font-size: 30px
        }

        p {
            font-weight: 400
        }
    </style>
    <section class="py-10 px-5 lg:p-20 w-full">
        <a href="{{ url('courses/' . $lecture->course->slug) }}" class="float-right text-[#6451E7] text-[36px]">
            <svg width="38" height="38" viewBox="0 0 38 38" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g filter="url(#filter0_d_3096_1352)">
                    <path d="M31 3L7 27M7 3L31 27" stroke="#6451E7" stroke-width="5.53846" stroke-linecap="round"
                        stroke-linejoin="round" shape-rendering="crispEdges" />
                </g>
                <defs>
                    <filter id="filter0_d_3096_1352" x="0.230469" y="0.230713" width="37.5391" height="37.5386"
                        filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                        <feFlood flood-opacity="0" result="BackgroundImageFix" />
                        <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                            result="hardAlpha" />
                        <feOffset dy="4" />
                        <feGaussianBlur stdDeviation="2" />
                        <feComposite in2="hardAlpha" operator="out" />
                        <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0" />
                        <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_3096_1352" />
                        <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_3096_1352" result="shape" />
                    </filter>
                </defs>
            </svg>

        </a>
        <h2 class="text-[36px] font-bold text-[#102935] capitalize">
            {{ $lecture->title }}
        </h2>
        <canvas id="pdf-canvas"></canvas>        
    </section>
    @push('head')
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.10.377/pdf.min.js"></script>
    @endpush

    @push('script')
        <script>
            var url = '{{ asset($lecture->attachments) }}';

            // Load the PDF
            pdfjsLib.getDocument(url).promise.then(function(pdf) {
                var pageNumber = 1;
                pdf.getPage(pageNumber).then(function(page) {
                    var scale = 1.5;
                    var viewport = page.getViewport({
                        scale: scale
                    });

                    // Prepare canvas using PDF page dimensions
                    var canvas = document.getElementById('pdf-canvas');
                    var context = canvas.getContext('2d');
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;

                    // Render PDF page to canvas context
                    var renderContext = {
                        canvasContext: context,
                        viewport: viewport
                    };
                    page.render(renderContext);
                });
            });
        </script>

        <script>
            setTimeout(() => {
                $.ajax({
                    type: "POST",
                    url: "{{ route('user-lesson') }}",
                    headers: {
                        'X-CSRF-TOKEN': "{{ csrf_token() }}"
                    },
                    data: {
                        lessonId: {{ $lecture->id }},
                        userCourseId: {{ $userCourse->id }}
                    },
                    success: function(response) {
                        console.log(response);
                    }
                });
            }, 200);
        </script>
    @endpush
@endsection
