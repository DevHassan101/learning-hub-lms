<nav class="bg-white border-gray-200">
    <div class="flex flex-wrap items-center justify-between lg:px-20   mx-auto p-4">
        <a href="{{ url('/') }}" class="flex items-center space-x-3 rtl:space-x-reverse">
            <img src="{{ asset('logo.png') }}" class="h-16" alt="Flowbite Logo" />
        </a>
        <div class="flex items-center md:order-2 space-x-3 md:space-x-0 rtl:space-x-reverse mt-2 lg:mt-0">
            @if (Auth::user())
                @role('admin')
                    <a href="{{ route('dashboard') }}" type="button"
                        class="text-white bg-gradient-to-r from-[#442AE2] to-[#6956E7] hover:bg-[#442AE2] focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 sm:px-10 py-2 text-center mr-2 hidden md:block">Dashboard</a>
                @else
                    <!-- Notification Bell -->
                    <div class="relative flex">
                        <button id="notificationButton" class="relative">
                            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="28" viewBox="0 0 26 28"
                                fill="none">
                                <path
                                    d="M17.1509 20.487H8.84603M17.1509 20.487H22.1201C24.6995 20.487 24.2637 17.9234 22.9588 16.6223C18.2591 11.9431 24.9346 1.19128 12.9985 1.19128C1.06228 1.19128 7.73917 11.9418 3.0395 16.6223C1.78414 17.8738 1.24928 20.487 3.87823 20.487H8.84603M17.1509 20.487C17.1509 23.1402 16.2599 26.0001 12.9985 26.0001C9.73701 26.0001 8.84603 23.1402 8.84603 20.487"
                                    stroke="#6B50E7" stroke-width="2.0674" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <span id="notificationCount"
                                class="absolute top-0 right-0 inline-block w-4 h-4 text-xs font-semibold text-white bg-red-600 rounded-full">
                                {{-- {{ Auth::user()->unreadNotifications->count() }} 1 --}}
                            </span>
                        </button>

                        <!-- Notification Dropdown -->
                        <div id="notificationDropdown"
                            class="hidden absolute right-0 mt-7 w-64 bg-white border border-[#4329E2] rounded-md shadow-lg z-50">
                            <div class="p-3 text-sm font-medium border-b">Notifications</div>
                            <div class="max-h-64 overflow-y-auto" id="notification-list">
                                {{-- @forelse(Auth::user()->unreadNotifications as $notification)
                                <a href="#" class="block px-4 py-2 text-sm hover:bg-gray-100">
                                    <p class="text-gray-700">{{ $notification->data['message'] ?? 'New Notification' }}</p>
                                    <span class="text-xs text-gray-500">{{ $notification->created_at->diffForHumans() }}</span>
                                </a>
                            @empty
                                <p class="px-4 py-2 text-sm text-gray-500">No new notifications</p>
                            @endforelse --}}
                            </div>
                            <div class="p-2 border-t">
                                <a href="{{ route('read-all') }}" class="block text-center text-blue-500 text-sm">
                                    Mark all as read
                                </a>
                            </div>
                        </div>
                    </div>
                    <x-dropdown>
                        <x-slot name="trigger">
                            <button @click="dropdownOpen = ! dropdownOpen"
                                class="relative  overflow-hidden flex items-center">
                                <svg width="28px" height="28px" viewBox="0 0 24 24" fill="none"
                                    class="ml-2 sm:ml-4 mr-1 sm:mr-2" xmlns="http://www.w3.org/2000/svg">
                                    <path opacity="0.4"
                                        d="M12.1207 12.78C12.0507 12.77 11.9607 12.77 11.8807 12.78C10.1207 12.72 8.7207 11.28 8.7207 9.50998C8.7207 7.69998 10.1807 6.22998 12.0007 6.22998C13.8107 6.22998 15.2807 7.69998 15.2807 9.50998C15.2707 11.28 13.8807 12.72 12.1207 12.78Z"
                                        stroke="#442AE2" stroke-width="1.5" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                    <path opacity="0.34"
                                        d="M18.7398 19.3801C16.9598 21.0101 14.5998 22.0001 11.9998 22.0001C9.39977 22.0001 7.03977 21.0101 5.25977 19.3801C5.35977 18.4401 5.95977 17.5201 7.02977 16.8001C9.76977 14.9801 14.2498 14.9801 16.9698 16.8001C18.0398 17.5201 18.6398 18.4401 18.7398 19.3801Z"
                                        stroke="#6956E7" stroke-width="1.5" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                    <path
                                        d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"
                                        stroke="#6956E7" stroke-width="1.5" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                                {{ Auth::user()->name }}
                            </button>
                        </x-slot>

                        <x-slot name="content">
                            <x-dropdown-link href="{{ route('user.profile') }}">
                                {{ __('Profile') }}
                            </x-dropdown-link>

                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <x-dropdown-link href="{{ route('logout') }}"
                                    onclick="event.preventDefault(); this.closest('form').submit();">
                                    {{ __('Log out') }}
                                </x-dropdown-link>
                            </form>
                        </x-slot>
                    </x-dropdown>
                @endrole
            @else
                <a href="{{ route('login') }}" type="button"
                    class="text-white bg-gradient-to-r from-[#442AE2] to-[#6956E7] hover:bg-[#442AE2] focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 sm:px-10 py-2 text-center mr-2 hidden md:block">Login</a>
                <a href="{{ route('register') }}" type="button"
                    class="text-white bg-gradient-to-r from-[#442AE2] to-[#6956E7] hover:bg-[#442AE2] focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 sm:px-10 py-2 text-center hidden md:block">Signup</a>
            @endif
            <button data-collapse-toggle="navbar-cta" type="button"
                class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200"
                aria-controls="navbar-cta" aria-expanded="false">
                <span class="sr-only">Open main menu</span>
                <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                    viewBox="0 0 17 14">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M1 1h15M1 7h15M1 13h15" />
                </svg>
            </button>
        </div>
        <div class="items-center justify-between hidden w-full md:flex md:w-auto md:order-1" id="navbar-cta">
            <ul
                class="flex flex-col font-medium p-4 md:p-0 mt-4 border border-gray-100 rounded-lg bg-gray-50 md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0 md:bg-white">
                <li>
                    <a href="{{ url('/') }}"
                        class="block py-2 px-3 md:p-0 text-gray-900 bg-gradient-to-r from-[#442AE2] to-[#6956E7] md:bg-none rounded-sm md:bg-transparent md:hover:text-[#442AE2] {{ request()->is('/') ? 'active-nav' : '' }}"
                        aria-current="page">Home</a>
                </li>
                <li>
                    <a href="{{ url('about-us') }}"
                        class="block py-2 px-3 md:p-0 text-gray-900 rounded-sm hover:bg-gray-100 md:hover:bg-transparent md:hover:text-[#442AE2] {{ request()->is('about-us') ? 'active-nav' : '' }}">About
                        us</a>
                </li>
                <li>
                    <a href="{{ url('courses') }}"
                        class="block py-2 px-3 md:p-0 text-gray-900 rounded-sm hover:bg-gray-100 md:hover:bg-transparent md:hover:text-[#442AE2] {{ request()->is('courses') ? 'active-nav' : '' }}">Courses</a>
                </li>
                <li>
                    <a href="{{ url('programs') }}"
                        class="block py-2 px-3 md:p-0 text-gray-900 rounded-sm hover:bg-gray-100 md:hover:bg-transparent md:hover:text-[#442AE2] {{ request()->is('programs') ? 'active-nav' : '' }}">Programs</a>
                </li>
                <li>
                    <a href="{{ url('blogs') }}"
                        class="block py-2 px-3 md:p-0 text-gray-900 rounded-sm hover:bg-gray-100 md:hover:bg-transparent md:hover:text-[#442AE2] {{ request()->is('blog') ? 'active-nav' : '' }}">Blogs</a>
                </li>
                <li>
                    <a href="{{ url('contact-us') }}"
                        class="block py-2 px-3 md:p-0 text-gray-900 rounded-sm hover:bg-gray-100 md:hover:bg-transparent md:hover:text-[#442AE2] {{ request()->is('blog') ? 'active-nav' : '' }}">Contact us</a>
                </li>
                {{-- <li class="relative">
                    <button id="subscriptionsDropdownButton"
                        class="block py-2 px-3 md:p-0 text-gray-900 rounded-sm hover:bg-gray-100 md:hover:bg-transparent md:hover:text-[#442AE2] flex items-center {{ request()->has('subscription') ? 'active-nav' : '' }}">
                        Subscriptions
                        <svg class="w-4 h-4 ml-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>

                    <!-- Dropdown Menu -->
                    <div id="subscriptionsDropdownMenu"
                        class="hidden absolute left-0 mt-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-50">
                        @foreach (\App\Models\Category::all() as $category)
                            <a href="{{ url('/plan/' . encrypt($category->title)) }}"
                                class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-200">{{ $category->title }}</a>
                        @endforeach
                    </div>
                </li> --}}

                @role('user')
                    <li>
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <a href="{{ route('logout') }}" onclick="event.preventDefault(); this.closest('form').submit();"
                                class="block md:hidden py-2 px-3 md:p-0 text-gray-900 rounded-sm hover:bg-gray-100 md:hover:bg-transparent md:hover:text-blue-700">
                                Logout
                            </a>
                        </form>
                    </li>
                @else
                    <li>
                        <a href="{{ route('login') }}"
                            class="block md:hidden py-2 px-3 md:p-0 text-gray-900 rounded-sm hover:bg-gray-100 md:hover:bg-transparent md:hover:text-blue-700">
                            Login</a>
                    </li>
                    <li>
                        <a href="{{ route('register') }}"
                            class="block md:hidden py-2 px-3 md:p-0 text-gray-900 rounded-sm hover:bg-gray-100 md:hover:bg-transparent md:hover:text-blue-700">
                            Register</a>
                    </li>
                @endrole
            </ul>
        </div>
    </div>
</nav>
