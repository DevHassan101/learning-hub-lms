@section('title', 'Add User')
<x-app-layout>

    <div class="bg-[#DFDCF3] border border-[#4228E2] overflow-hidden shadow-sm rounded-xl min-h-full">
        <div class="p-6 border-b border-gray-200 overflow-x-auto relative">
            <a href="{{ route('users.index') }}" class="sm:absolute top-[40px]">
                <svg width="20" height="15" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1.81818 7.54545H19M7.54545 1L1 7.54545L7.54545 14.0909" stroke="#6D51E7"
                        stroke-width="1.63636" stroke-linecap="round" stroke-linejoin="round" />
                </svg>

            </a>
            <div class="w-full flex justify-center">
                <div class="w-full max-w-[450px]">
                    <h1 class="text-[36px] font-bold mb-5">
                        Add User
                    </h1>
                    <form action="{{ route('users.store') }}" method="post">
                        @csrf
                        <div class="mb-4">
                            <label for="">
                                Full Name
                            </label>
                            <input type="text" placeholder="fullname" name="name" value="{{ old('name') }}"
                                class="border border-[#482EE3] bg-transparent rounded block w-full mt-1">
                            @error('name')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-4">
                            <label for="">
                                Email
                            </label>
                            <input type="email" name="email" placeholder="email" value="{{ old('email') }}"
                                class="border border-[#482EE3] bg-transparent rounded block w-full mt-1">
                            @error('email')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-4">
                            <label for="">
                                Password
                            </label>
                            <input type="password" name="password" placeholder="Enter your password"
                                value="{{ old('password') }}"
                                class="border border-[#482EE3] bg-transparent rounded block w-full mt-1">
                            @error('password')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-4">
                            <label for="">
                                Confirm Password
                            </label>
                            <input type="password" placeholder="Re-enter your password" name="password_confirmation"
                                value="{{ old('password_confirmation') }}"
                                class="border border-[#482EE3] bg-transparent rounded block w-full mt-1">
                            @error('password_confirmation')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>

                        <button
                            class="mt-5 w-full py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500">
                            Add
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
