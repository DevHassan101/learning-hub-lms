@section('title', 'Add Course')
<x-app-layout>

    <div class="bg-[#DFDCF3] border border-[#4228E2] overflow-hidden shadow-sm rounded-xl min-h-full">
        <div class="p-6 border-b border-gray-200 overflow-x-auto relative">
            <a href="{{ route('course.index') }}" class="sm:absolute top-[40px]">
                <svg width="20" height="15" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1.81818 7.54545H19M7.54545 1L1 7.54545L7.54545 14.0909" stroke="#6D51E7"
                        stroke-width="1.63636" stroke-linecap="round" stroke-linejoin="round" />
                </svg>

            </a>
            <div class="w-full flex justify-center">
                <div class="w-full max-w-[450px]">
                    <h1 class="text-[30px] font-bold mb-5">
                        Course Details
                    </h1>
                    <form action="{{ route('course.store') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="mb-3">
                            <select name="category_id" id="category_id"
                                class="border border-[#482EE3] bg-transparent rounded block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2">
                                <option value="">Select category</option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}" @selected(old('category_id') == $category->id)>{{ $category->title }}</option>
                                @endforeach
                            </select>
                            @error('category_id')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-3">
                            <textarea name="title" id="" cols="30" rows="3" placeholder="Title (required)"
                                class="border border-[#482EE3] bg-transparent rounded block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2">{{ old('title') }}</textarea>
                            @error('title')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-3">
                            <textarea name="description" id="" cols="30" rows="6" placeholder="Description"
                                class="border border-[#482EE3] bg-transparent rounded block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2">{{ old('description') }}</textarea>
                            @error('description')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-3">
                            <label for="" class="text-[#102935] font-medium text-[20px]">Thumbnail</label>
                            <span class="text-[14px] block">
                                Set a thumbnail that stands out
                                <br>
                                and draws viewer’s attention
                            </span>


                            <div id="drop-area" class=" rounded-lg mt-3">
                                <input type="file" id="input-file" name="file" hidden
                                    accept=".png, .jpg, .jpeg" />
                                <div
                                    class="bg-transparent border border-dashed border-[#4229E2] text-center p-5 max-w-[200px]">
                                    <div class="flex justify-center">
                                        <svg width="35" height="35" viewBox="0 0 35 35" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M35 17.5C35 16.5335 34.2165 15.75 33.25 15.75C32.2835 15.75 31.5 16.5335 31.5 17.5H35ZM17.5 3.5C18.4665 3.5 19.25 2.7165 19.25 1.75C19.25 0.783501 18.4665 0 17.5 0V3.5ZM30.625 31.5H4.375V35H30.625V31.5ZM3.5 30.625V4.375H0V30.625H3.5ZM31.5 17.5V30.625H35V17.5H31.5ZM4.375 3.5H17.5V0H4.375V3.5ZM4.375 31.5C3.89176 31.5 3.5 31.1083 3.5 30.625H0C0 33.0412 1.95875 35 4.375 35V31.5ZM30.625 35C33.0412 35 35 33.0412 35 30.625H31.5C31.5 31.1083 31.1083 31.5 30.625 31.5V35ZM3.5 4.375C3.5 3.89176 3.89175 3.5 4.375 3.5V0C1.95876 0 0 1.95875 0 4.375H3.5Z"
                                                fill="#102935" />
                                            <path
                                                d="M1.75 27.1246L11.1065 18.5479C11.759 17.9496 12.7557 17.933 13.4278 18.5092L24.5 27.9996"
                                                stroke="#102935" stroke-width="3.5" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path
                                                d="M21 23.6249L25.1768 19.4481C25.7925 18.8323 26.7675 18.763 27.4642 19.2856L33.25 23.6249"
                                                stroke="#102935" stroke-width="3.5" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path d="M28.875 12.25V1.75" stroke="#102935" stroke-width="3.5"
                                                stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M24.5 6.125L28.875 1.75L33.25 6.125" stroke="#102935"
                                                stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                    <button type="button" id="browse" class="6">
                                        Upload File
                                    </button>
                                </div>
                                @error('file')
                                    <span class="text-red-500 text-left">
                                        {{ $message }}
                                    </span>
                                @enderror

                                <ul id="file-list" class="mt-4 text-sm text-left"></ul>
                            </div>
                        </div>

                        <button
                            class="mt-5 py-2 px-10 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500">
                            Create
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="absolute left-0 z-[100] top-0 bg-[#00000038] h-screen w-full flex justify-center items-center hidden"
        id="image-type-modal">
        <div class="w-[400px] bg-white rounded-md p-5 text-center">
            <p class="text-red-500 text-[20px] text-bold" id="heading"></p>
            <span id="text"></span>
            <br>
            <button onclick="closeImageTypeModal()"
                class="bg-[#EBBD04] border border-[#EBBD04] hover:bg-white text-[18px] font-[600] text-white hover:text-[#EBBD04] px-[60px] py-[15px] rounded-lg mt-10">
                Cancel
            </button>
        </div>
    </div>

    <script>
        const dropArea = document.getElementById("drop-area");
        const inputFile = document.getElementById("input-file");
        const fileList = document.getElementById("file-list");
        const browseBtn = document.getElementById("browse");
        const validFileTypes = [".png", ".jpg", ".jpeg"];

        dropArea.addEventListener("dragover", e => {
            e.preventDefault();
            e.dataTransfer.dropEffect = "copy";
        });
        dropArea.addEventListener("drop", e => {
            e.preventDefault();
            handleFiles(e.dataTransfer.files);
        });

        browseBtn.addEventListener("click", () => {
            inputFile.click();
        });

        inputFile.addEventListener("change", e => {
            if (e.target.files.length === 0) {
                fileList.innerHTML = "";
            } else {
                handleFiles(e.target.files);
            }
        });

        function handleFiles(f) {
            const v = Array.from(f).filter(i => {
                const fileExtension = i.name.split('.').pop().toLowerCase();
                console.log(fileExtension);
                return validFileTypes.includes(`.${fileExtension}`);
            });

            console.log(v.length);

            if (!v.length) {
                document.getElementById('image-type-modal').classList.remove('hidden');
                document.getElementById('heading').innerText = "Invalid File Types";
                document.getElementById('text').innerHTML =
                    `<b>Allowed Types: </b><span id="allowed-types">${validFileTypes.join(", ")}</span>`;
                return;
            }

            // Manually clear input if cancelled
            if (f.length === 0) {
                document.getElementById('file-list').innerHTML = "";
            } else {
                const d = new DataTransfer();
                v.forEach(i => d.items.add(i));
                inputFile.files = d.files;
                updateFileListDisplay(inputFile.files);
            }
        }

        function updateFileListDisplay(f) {
            console.warn(f);

            fileList.innerHTML = "";
            Array.from(f).forEach(i => {
                const li = document.createElement("li");
                li.textContent = i.name;
                fileList.appendChild(li);
            });
        }

        function closeImageTypeModal() {
            document.getElementById('image-type-modal').classList.add('hidden')
        }
    </script>
</x-app-layout>
