@section('title', 'Edit Quiz')
<x-app-layout>

    <div class="bg-[#DFDCF3] border border-[#4228E2] overflow-hidden shadow-sm rounded-xl min-h-full">
        <div class="p-6 border-b border-gray-200 overflow-x-auto relative">

            <form action="{{ route('course.quiz.update', ['quiz' => $quiz]) }}" method="post">
                @csrf
                <div class="w-full">
                    <div class="flex justify-between items-center mb-7">
                        <h1 class="text-[22px] sm:text-[26px] md:text-[30px] lg:text-[36px] font-bold flex items-center">
                            <a href="{{ route('course.manage-quiz', ['course' => $quiz->course_id]) }}" class="mr-3">
                                <svg width="20" height="15" viewBox="0 0 20 15" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.81818 7.54545H19M7.54545 1L1 7.54545L7.54545 14.0909" stroke="#6D51E7"
                                        stroke-width="1.63636" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>

                            </a>
                            Edit Questions
                        </h1>

                        <button type="submit"
                            class="py-2 px-5 sm:px-10 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500">
                            Update
                        </button>

                    </div>
                    <div class="gap-2 grid grid-cols-2">
                        <div class="mb-3 w-full col-span-2">
                            <select name="type" id="" required
                                class="resize-none border border-[#482EE3] bg-transparent rounded-lg block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2">
                                <option value="">Select Quiz Type</option>
                                <option value="normal" @selected($quiz->type == 'normal')>Normal</option>
                                <option value="time restricted" @selected($quiz->type == 'time restricted')>Time restricted</option>
                            </select>
                            @error('type')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-3 w-full">
                            <textarea name="question" id="" cols="30" rows="2" placeholder="Write Question"
                                class="resize-none border border-[#482EE3] bg-transparent rounded-lg block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2">{{ $quiz->question }}</textarea>
                            @error('question')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-3 w-full">
                            <select name="answer" id="answer"
                                class="resize-none border border-[#482EE3] bg-transparent rounded-lg block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2 h-16">
                                <option value="">Select Answer</option>
                                <option value="option_a" data-option="a" @selected($quiz->answer == 'option_a')>Option A: {{$quiz->option_a}}</option>
                                <option value="option_b" data-option="b" @selected($quiz->answer == 'option_b')>Option B: {{$quiz->option_b}}</option>
                                <option value="option_c" data-option="c" @selected($quiz->answer == 'option_c')>Option C: {{$quiz->option_c}}</option>
                                <option value="option_d" data-option="d" @selected($quiz->answer == 'option_d')>Option D: {{$quiz->option_d}}</option>
                            </select>
                            @error('answer')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-3 w-full">
                            <textarea name="option_a" data-option="a" id="" cols="30" rows="2" placeholder="Write Option"
                                class="options resize-none border border-[#482EE3] bg-transparent rounded-lg block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2">{{ $quiz->option_a }}</textarea>
                            @error('option_a')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-3 w-full">
                            <textarea name="option_b" data-option="b" id="" cols="30" rows="2" placeholder="Write Option"
                                class="options resize-none border border-[#482EE3] bg-transparent rounded-lg block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2">{{ $quiz->option_b }}</textarea>
                            @error('option_b')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-3 w-full">
                            <textarea name="option_c" data-option="c" id="" cols="30" rows="2" placeholder="Write Option"
                                class="options resize-none border border-[#482EE3] bg-transparent rounded-lg block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2">{{ $quiz->option_c }}</textarea>
                            @error('option_c')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-3 w-full">
                            <textarea name="option_d" data-option="d" id="" cols="30" rows="2" placeholder="Write Option"
                                class="options resize-none border border-[#482EE3] bg-transparent rounded-lg block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2">{{ $quiz->option_d }}</textarea>
                            @error('option_d')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-3 w-full col-span-2">
                            <textarea name="description" id="" cols="30" rows="5" placeholder="Write Description"
                                class="resize-none border border-[#482EE3] bg-transparent rounded-lg block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2">{{ $quiz->description }}</textarea>
                            @error('description')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>


    <div class="absolute left-0 z-[100] top-0 bg-[#00000038] h-screen w-full flex justify-center items-center hidden"
        id="image-type-modal">
        <div class="w-[400px] bg-white rounded-md p-5 text-center">
            <p class="text-red-500 text-[20px] text-bold" id="heading"></p>
            <span id="text"></span>
            <br>
            <button onclick="closeImageTypeModal()"
                class="bg-[#EBBD04] border border-[#EBBD04] hover:bg-white text-[18px] font-[600] text-white hover:text-[#EBBD04] px-[60px] py-[15px] rounded-lg mt-10">
                Cancel
            </button>
        </div>
    </div>

    @push('script')
        <script>
            $(document).ready(function() {
                $('.options').on('input', function() {
                    let option = $(this).data('option');
                    let text = $(this).val();

                    let answerDropDown = $('#answer option[data-option="' + option + '"]');

                    $(answerDropDown).text("Option " + option.toUpperCase() + ": " + text);
                });
            });
        </script>
    @endpush
</x-app-layout>
