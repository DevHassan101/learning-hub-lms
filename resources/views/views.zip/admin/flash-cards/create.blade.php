@section('title', 'Add Flash Card')
<x-app-layout>

    <div class="bg-[#DFDCF3] border border-[#4228E2] overflow-hidden shadow-sm rounded-xl min-h-full">
        <div class="p-6 border-b border-gray-200 overflow-x-auto relative">
            <a href="{{ route('flash-card.index') }}" class="sm:absolute top-[40px]">
                <svg width="20" height="15" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1.81818 7.54545H19M7.54545 1L1 7.54545L7.54545 14.0909" stroke="#6D51E7"
                        stroke-width="1.63636" stroke-linecap="round" stroke-linejoin="round" />
                </svg>

            </a>
            <div class="w-full flex justify-center">
                <div class="w-full max-w-[450px]">
                    <h1 class="text-[36px] font-bold mb-5">
                        Add Flash Card
                    </h1>
                    <form action="{{ route('flash-card.store') }}" method="post">
                        @csrf
                        <div class="mb-4">
                            <label for="title">
                                Title
                            </label>
                            <input type="title" placeholder="title" name="title" value="{{ old('title') }}"
                                class="border border-[#482EE3] bg-transparent rounded-lg block w-full mt-1 p-2 focus:ring-[#482EE3] focus:outline-[#482EE3]">
                            @error('title')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-4">
                            <label for="course_id">
                                Course
                            </label>
                            <select name="course_id" id="course_id" class="block mt-1 w-full rounded-md form-input border-[#482EE3] focus:ring-[#482EE3] text-[14px] bg-[#DFDCF3]">
                                <option value="">Select Course</option>
                                @foreach ($courses as $course)
                                    <option value="{{$course->id}}">{{$course->title}}</option>
                                @endforeach
                            </select>
                            @error('course_id')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-3 w-full col-span-2">
                            <label for="description">
                                Description
                            </label>
                            <textarea name="description" id="" cols="30" rows="8" placeholder="Write Description"
                                class="mt-1 resize-none border border-[#482EE3] bg-transparent rounded-lg block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2 focus:ring-[#482EE3]">{{ old('description') }}</textarea>
                            @error('description')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>

                        <button
                            class="mt-5 w-full py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500">
                            Add
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
