@section('title', 'Flash Cards')
<x-app-layout>
    <x-slot name="header">
        <div class="sm:flex justify-between items-center">
            {{ __('Flash Cards') }}
            <div class="sm:flex">
                <div class="relative flex items-center my-2 sm:my-0">
                    <input type="search" id="searchInput"
                        class="w-full sm:w-[300px] bg-[#DFDCF3] border border-[#4228E2] rounded-lg px-4 pr-10 h-10 outline-none focus:ring-2 focus:ring-[#4228E2]"
                        placeholder="Search flash card">
                    <svg width="18" height="20"
                        class="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none"
                        viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="7" cy="7" r="6.25" stroke="#6C6C6C" stroke-width="1.5" />
                        <path d="M11 12L15 16" stroke="#6C6C6C" stroke-width="1.5" />
                    </svg>
                </div>

                <a href="{{ route('flash-card.create') }}"
                    class="sm:ml-4 py-2 px-10 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[15px] font-medium hover:bg-indigo-500">
                    Add flash card
                </a>
            </div>
        </div>
    </x-slot>

    <div class="bg-[#DFDCF3] border border-[#4228E2] overflow-hidden shadow-sm rounded-xl">
        <div class="p-6 border-b border-gray-200 overflow-x-auto">
            <table class="min-w-full">
                <thead>
                    <tr>
                        <th class="text-nowrap px-3">Title</th>
                        <th class="text-nowrap px-3">Course</th>
                        <th class="text-nowrap px-3">Description</th>
                        <th class="text-nowrap px-3">Actions</th>
                    </tr>
                </thead>
                <tbody id="myTable">
                    @forelse ($flashCards as $flashCard)
                        <tr class="border-b border-[#102935]">
                            <td class="text-[16px] font-regular text-center text-nowrap p-3">{{ $flashCard->title }}
                            </td>
                            <td class="text-[16px] font-regular text-center text-nowrap p-3">{{ $flashCard->course->title }}
                            </td>
                            <td class="text-[16px] font-regular text-center text-nowrap p-3">                            
                                {{ substr($flashCard->description, 0, 120) }}
                                {{ strlen($flashCard->description) > 120 ? '...' : '' }}
                            </td>
                            <td class="text-[16px] font-regular py-3 text-center">
                                <div class="flex justify-center">
                                    <a href="{{ route('flash-card.edit', ['flash_card' => $flashCard]) }}"
                                        class="mx-2">
                                        <svg width="33" height="33" viewBox="0 0 33 33" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <circle cx="16.5" cy="16.5" r="16.5"
                                                fill="url(#paint0_linear_3085_4505)" />
                                            <path
                                                d="M18.9591 10.1077C18.9251 10.0736 18.8846 10.0465 18.8401 10.028C18.7955 10.0095 18.7478 10 18.6995 10C18.6513 10 18.6036 10.0095 18.559 10.028C18.5145 10.0465 18.474 10.0736 18.44 10.1077L11 17.5484V20.6334C11 20.7306 11.0386 20.8239 11.1074 20.8926C11.1761 20.9614 11.2694 21 11.3666 21H14.4516L21.8923 13.56C21.9264 13.526 21.9535 13.4855 21.972 13.441C21.9905 13.3964 22 13.3487 22 13.3005C22 13.2522 21.9905 13.2045 21.972 13.1599C21.9535 13.1154 21.9264 13.0749 21.8923 13.0409L18.9591 10.1077Z"
                                                fill="white" />
                                            <defs>
                                                <linearGradient id="paint0_linear_3085_4505" x1="16.5"
                                                    y1="0" x2="16.5" y2="33"
                                                    gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#4229E2" />
                                                    <stop offset="1" stop-color="#6552E7" />
                                                </linearGradient>
                                            </defs>
                                        </svg>
                                    </a>
                                    <button type="button" class="delete-flash-card" data-id="{{ $flashCard->id }}">
                                        <svg width="33" height="33" viewBox="0 0 33 33" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <circle cx="16.5" cy="16.5" r="16.5"
                                                fill="url(#paint0_linear_3085_4508)" />
                                            <path
                                                d="M12 25C11.45 25 10.9793 24.8043 10.588 24.413C10.1967 24.0217 10.0007 23.5507 10 23V10H9V8H14V7H20V8H25V10H24V23C24 23.55 23.8043 24.021 23.413 24.413C23.0217 24.805 22.5507 25.0007 22 25H12ZM22 10H12V23H22V10ZM14 21H16V12H14V21ZM18 21H20V12H18V21Z"
                                                fill="white" />
                                            <defs>
                                                <linearGradient id="paint0_linear_3085_4508" x1="16.5"
                                                    y1="0" x2="16.5" y2="33"
                                                    gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#4229E2" />
                                                    <stop offset="1" stop-color="#6653E7" />
                                                </linearGradient>
                                            </defs>
                                        </svg>

                                    </button>
                                </div>
                            </td>
                        </tr>

                    @empty
                        <tr>
                            <td colspan="4">
                                <div class="flex justify-center items-center">
                                    <img class="h-[300px] w-[300px] my-10" src="{{ asset('not-found.png') }}"
                                        alt="">
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="8">
                            {{ $flashCards->links() }}
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    @push('script')
        <script>
            function paginate(a) {
                let paginate = $(a).val();
                let search = $('#searchInput').val();
                fetchData(1, search, paginate)
            };

            let searchQuery = '';
            $(document).on('click', '#paginationLinks a', function(event) {
                event.preventDefault();

                var page = $(this).attr('href').split('page=')[1];

                fetchData(page, searchQuery);
            });
            $('#searchInput').on('keyup', function() {
                searchQuery = $(this).val();
                console.log(searchQuery);

                fetchData(1, searchQuery); // Always fetch from page 1 when searching
            });

            function fetchData(page, search, paginate = 10) {
                let baseUrl = "{{ url('/flash-card') }}";
                $.ajax({
                    url: baseUrl + "?page=" + page + "&search=" + search + '&paginate=' + paginate,
                    type: "GET",
                    dataType: "json",
                    success: function(data) {
                        $('#myTable').html(data.table);
                        $('#paginationLinks').html(data.pagination);
                        $('.pagination-paginate').val(paginate);
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                    }
                });
            }

            $('#close-modal').click(function(e) {
                e.preventDefault();
                $('#status-modal').addClass('hidden');
                $('#status-modal').removeClass('flex');
            });
             $(document).on('click','.delete-flash-card', function(e) {
                e.preventDefault();
                $('#object').text("flash card");
                $('#delete-modal').removeClass('hidden');
                $('#delete-modal').addClass('flex');
                let id = $(this).data('id');
                let url = "{{ url('flash-card') }}" + "/" + id;
                $("#delete-form").attr('action', url);
            });
        </script>
    @endpush
</x-app-layout>
