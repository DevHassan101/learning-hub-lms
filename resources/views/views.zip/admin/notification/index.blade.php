@section('title', 'Add Quiz')
<x-app-layout>

    <div class="bg-[#DFDCF3] border border-[#4228E2] overflow-hidden shadow-sm rounded-xl min-h-full">
        <div class="p-6 border-b border-gray-200 overflow-x-auto relative">

            <div class="w-full">
                <div class="flex justify-between items-center mb-7">
                    <h1 class="text-[26px] sm:text-[30px] md:text-[36px] font-bold flex items-center">
                        {{-- <a href="{{ route('course.manage-exam', ['course' => $course]) }}" class="mr-3">
                            <svg width="20" height="15" viewBox="0 0 20 15" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M1.81818 7.54545H19M7.54545 1L1 7.54545L7.54545 14.0909" stroke="#6D51E7"
                                    stroke-width="1.63636" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>

                        </a> --}}
                        Notification Management
                    </h1>
                </div>
                <form action="{{ route('notification.store') }}" method="post">
                    @csrf
                    <div class="mb-3 w-full">
                        <textarea name="title" id="" cols="30" rows="2" placeholder="Title (required)"
                            class="resize-none border border-[#482EE3] bg-transparent rounded block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2"></textarea>
                        @error('title')
                            <span class="text-red-500">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                    <div class="mb-3 w-full col-span-2">
                        <textarea name="description" id="" cols="30" rows="5" placeholder="Description"
                            class="resize-none border border-[#482EE3] bg-transparent rounded block w-full placeholder:text-[#102935] placeholder:text-[14px] p-2"></textarea>
                        @error('description')
                            <span class="text-red-500">
                                {{ $message }}
                            </span>
                        @enderror
                    </div>
                    <button
                        class="py-2 px-10 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[18px] font-semibold hover:bg-indigo-500">
                        Send
                    </button>
                </form>
            </div>
        </div>
    </div>


    <div class="absolute left-0 z-[100] top-0 bg-[#00000038] h-screen w-full flex justify-center items-center hidden"
        id="image-type-modal">
        <div class="w-[400px] bg-white rounded-md p-5 text-center">
            <p class="text-red-500 text-[20px] text-bold" id="heading"></p>
            <span id="text"></span>
            <br>
            <button onclick="closeImageTypeModal()"
                class="bg-[#EBBD04] border border-[#EBBD04] hover:bg-white text-[18px] font-[600] text-white hover:text-[#EBBD04] px-[60px] py-[15px] rounded-lg mt-10">
                Cancel
            </button>
        </div>
    </div>
</x-app-layout>
