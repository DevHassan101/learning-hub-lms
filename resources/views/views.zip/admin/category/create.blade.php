@section('title', 'Add Program')
<x-app-layout>

    <div class="bg-[#DFDCF3] border border-[#4228E2] overflow-hidden shadow-sm rounded-xl min-h-full">
        <div class="p-6 border-b border-gray-200 overflow-x-auto relative">
            <a href="{{ route('program.index') }}" class="sm:absolute top-[40px]">
                <svg width="20" height="15" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1.81818 7.54545H19M7.54545 1L1 7.54545L7.54545 14.0909" stroke="#6D51E7"
                        stroke-width="1.63636" stroke-linecap="round" stroke-linejoin="round" />
                </svg>

            </a>
            <div class="w-full flex justify-center">
                <div class="w-full max-w-[450px]">
                    <h1 class="text-[36px] font-bold mb-5">
                        Add Program
                    </h1>
                    <form action="{{ route('program.store') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="mb-4">
                            <label for="title">
                                Title
                            </label>
                            <input type="title" placeholder="title" name="title" value="{{ old('title') }}"
                                class="border border-[#482EE3] bg-transparent rounded-lg block w-full mt-1 p-2 focus:ring-[#482EE3] focus:outline-[#482EE3]">
                            @error('title')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-4">
                            <label for="banner">
                                Banner
                            </label>

                            <div id="banner-drop-area" class="mt-1 text-center">
                                <input type="file" id="banner-input-file" name="banner" hidden accept="image/*" />
                                <div
                                    class="bg-transparent border rounded-lg border-[#4229E2] text-center p-5 w-full py-10">
                                    <div class="flex justify-center">
                                        <svg width="35" height="35" viewBox="0 0 35 35" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M35 17.5C35 16.5335 34.2165 15.75 33.25 15.75C32.2835 15.75 31.5 16.5335 31.5 17.5H35ZM17.5 3.5C18.4665 3.5 19.25 2.7165 19.25 1.75C19.25 0.783501 18.4665 0 17.5 0V3.5ZM30.625 31.5H4.375V35H30.625V31.5ZM3.5 30.625V4.375H0V30.625H3.5ZM31.5 17.5V30.625H35V17.5H31.5ZM4.375 3.5H17.5V0H4.375V3.5ZM4.375 31.5C3.89176 31.5 3.5 31.1083 3.5 30.625H0C0 33.0412 1.95875 35 4.375 35V31.5ZM30.625 35C33.0412 35 35 33.0412 35 30.625H31.5C31.5 31.1083 31.1083 31.5 30.625 31.5V35ZM3.5 4.375C3.5 3.89176 3.89175 3.5 4.375 3.5V0C1.95876 0 0 1.95875 0 4.375H3.5Z"
                                                fill="#4229E2" />
                                            <path
                                                d="M1.75 27.1246L11.1065 18.5479C11.759 17.9496 12.7557 17.933 13.4278 18.5092L24.5 27.9996"
                                                stroke="#4229E2" stroke-width="3.5" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path
                                                d="M21 23.6249L25.1768 19.4481C25.7925 18.8323 26.7675 18.763 27.4642 19.2856L33.25 23.6249"
                                                stroke="#4229E2" stroke-width="3.5" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path d="M28.875 12.25V1.75" stroke="#4229E2" stroke-width="3.5"
                                                stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M24.5 6.125L28.875 1.75L33.25 6.125" stroke="#4229E2"
                                                stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                    <button type="button" id="banner-browse">Upload File</button>
                                </div>
                                <ul id="banner-file-list" class="mt-4 text-sm text-left"></ul>
                            </div>
                            @error('banner')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>

                        <p class="text-red-500 mt-10">
                           <b>Note:</b> Set the price to $0 to exclude this plan.
                        </p>
                        <table class="w-full">
                            <thead>
                                <tr class="border-b-2 border-white">
                                    <th class="py-2 text-left">Subscription</th>
                                    <th class="py-2 text-center">Price</th>
                                    {{-- <th class="py-2 text-right">Description</th> --}}
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="border-b border-white">
                                    <td class="text-left py-1 pl-2">Monthly</td>
                                    <td>
                                        <p class="border-[#482EE3] flex justify-center items-center py-1">
                                            <input type="text" name="monthly_price"
                                                class="price-input text-center bg-transparent border-none rounded w-[70px] p-0 focus:ring-0"
                                                value="$10" />
                                        </p>
                                    </td>
                                    {{-- <td>
                                        <div class="flex justify-end pr-2">
                                            <button type="button"
                                                class="add-description border rounded-full border-black text-center h-[20px] w-[20px] flex justify-center items-center">
                                                +
                                            </button>
                                        </div>
                                    </td> --}}
                                </tr>
                                <tr class="border-b border-white">
                                    <td class="text-left py-1 pl-2">Quarterly</td>
                                    <td>
                                        <p class="border-[#482EE3] flex justify-center items-center py-1">
                                            <input type="text" name="quarterly_price"
                                                class="price-input text-center bg-transparent border-none rounded w-[70px] p-0 focus:ring-0"
                                                value="$20" />
                                        </p>
                                    </td>
                                    {{-- <td>
                                        <div class="flex justify-end pr-2">
                                            <button type="button"
                                                class="add-description border rounded-full border-black text-center h-[20px] w-[20px] flex justify-center items-center">
                                                +
                                            </button>
                                        </div>
                                    </td> --}}
                                </tr>
                                <tr class="border-b border-white">
                                    <td class="text-left py-1 pl-2">Annually</td>
                                    <td>
                                        <p class="border-[#482EE3] flex justify-center items-center py-1">
                                            <input type="text" name="annually_price"
                                                class="price-input text-center bg-transparent border-none rounded w-[70px] p-0 focus:ring-0"
                                                value="$30" />
                                        </p>
                                    </td>
                                    {{-- <td>
                                        <div class="flex justify-end pr-2">
                                            <button type="button"
                                                class="add-description border rounded-full border-black text-center h-[20px] w-[20px] flex justify-center items-center">
                                                +
                                            </button>
                                        </div>
                                    </td> --}}
                                </tr>
                                <tr class="border-b border-white">
                                    <td class="text-left py-1 pl-2">All time</td>
                                    <td>
                                        <p class="border-[#482EE3] flex justify-center items-center py-1">
                                            <input type="text" name="alltime_price"
                                                class="price-input text-center bg-transparent border-none rounded w-[70px] p-0 focus:ring-0"
                                                value="$100" />
                                        </p>
                                    </td>
                                    {{-- <td>
                                        <div class="flex justify-end pr-2">
                                            <button type="button"
                                                class="add-description border rounded-full border-black text-center h-[20px] w-[20px] flex justify-center items-center">
                                                +
                                            </button>
                                        </div>
                                    </td> --}}
                                </tr>
                            </tbody>
                        </table>
                        <button
                            class="mt-5 w-full py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500">
                            Add
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="absolute left-0 z-[100] top-0 bg-[#00000038] h-screen w-full flex justify-center items-center hidden"
        id="image-type-modal">
        <div class="w-[400px] bg-white rounded-md p-5 text-center">
            <center>
                <svg fill="#6956E7" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink" width="100px" height="100px"
                    viewBox="0 0 55.704 55.703" xml:space="preserve">
                    <g>
                        <path
                            d="M27.852,0C19.905,0,12.743,3.363,7.664,8.72C7.628,8.751,7.583,8.762,7.549,8.796C7.495,8.85,7.476,8.922,7.426,8.98
      C2.833,13.949,0,20.568,0,27.852c0,15.357,12.493,27.851,27.851,27.851c15.356,0,27.851-12.494,27.851-27.851
      C55.703,12.494,43.208,0,27.852,0z M4.489,27.851c0-5.315,1.805-10.207,4.806-14.138l32.691,32.694
      c-3.93,3.001-8.819,4.806-14.135,4.806C14.969,51.213,4.489,40.732,4.489,27.851z M45.282,43.352l-32.933-32.93
      c4.13-3.678,9.551-5.934,15.503-5.934c12.881,0,23.362,10.48,23.362,23.363C51.213,33.803,48.958,39.225,45.282,43.352z" />
                    </g>
                </svg>
            </center>
            <p class="text-red-500 text-[20px] text-bold mt-4" id="heading"></p>
            <span id="text"></span>
            <br>
            <button onclick="closeImageTypeModal()"
                class="py-2 px-7 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500 mt-3">
                Cancel
            </button>
        </div>
    </div>


    @push('script')
        <script>
            $('.add-description').click(function(e) {
                e.preventDefault();
                $('#description-modal').removeClass("hidden");
            });

            $('.close-modal').click(function(e) {
                e.preventDefault();
                $('#description-modal').addClass('hidden');
            });

            function closeModal() {
                $('#description-modal').addClass('hidden');
            }
            $('.price-input').on("keyup", function() {
                let input = $(this).val();
                let numericInput = input.replace(/[^0-9]/g, '');
                $(this).val("$"+numericInput);
            });





            function setupFileUpload(areaId, inputId, listId, browseBtnId, allowedTypes) {
                const dropArea = document.getElementById(areaId);
                const inputFile = document.getElementById(inputId);
                const fileList = document.getElementById(listId);
                const browseBtn = document.getElementById(browseBtnId);

                dropArea.addEventListener("dragover", e => {
                    e.preventDefault();
                    e.dataTransfer.dropEffect = "copy";
                });

                dropArea.addEventListener("drop", e => {
                    e.preventDefault();
                    handleFiles(e.dataTransfer.files);
                });

                browseBtn.addEventListener("click", () => inputFile.click());

                inputFile.addEventListener("change", e => {
                    if (e.target.files.length) handleFiles(e.target.files);
                });

                function handleFiles(files) {
                    const dataTransfer = new DataTransfer();
                    const filteredFiles = Array.from(files).filter(file =>
                        allowedTypes.includes(file.name.split('.').pop().toLowerCase())
                    );

                    if (!filteredFiles.length) {
                        document.getElementById('image-type-modal').classList.remove('hidden');
                        document.getElementById('heading').innerText = "Invalid File Type";
                        document.getElementById('text').innerHTML = `<b>Allowed Types:</b> ${allowedTypes.join(", ")}`;
                        return;
                    }

                    filteredFiles.forEach(file => dataTransfer.items.add(file));
                    inputFile.files = dataTransfer.files;

                    fileList.innerHTML = filteredFiles.map(file => `<li>${file.name}</li>`).join('');
                }
            }

            setupFileUpload("banner-drop-area", "banner-input-file", "banner-file-list", "banner-browse", ["jpg",
                "jpeg", "png"
            ]);
            setupFileUpload("attachment-drop-area", "attachment-input-file", "attachment-file-list", "attachment-browse", [
                "pdf"
            ]);

            function closeImageTypeModal() {
                document.getElementById('image-type-modal').classList.add('hidden');
            }
        </script>
    @endpush

</x-app-layout>

<div id="description-modal"
    class="hidden z-[100] h-screen w-full bg-black bg-opacity-20 flex justify-center items-center absolute top-0">
    <div class="bg-white rounded-lg w-[90%] sm:max-w-lg  p-5 relative">
        <button type="button" onclick="closeModal()"
            class="close-modal absolute top-[10px] right-[20px] text-slate-500">
            X
        </button>
        <h1 class="text-center text-[22px] underline font-semibold">
            Monthly Subscription
        </h1>

        <form action="" method="post" class="my-4">
            <div class="flex">
                <input type="text"
                    class="border border-[#482EE3] bg-transparent rounded-lg w-full mt-1 p-2 focus:ring-[#482EE3] focus:outline-[#482EE3]">
                <button
                    class="mt-2 ml-2 w-[100px] py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[14px] hover:bg-indigo-500">Add</button>
            </div>
        </form>

        <ul class="space-y-5 list-none 2xl:p-5">
            <li class="flex">
                <svg width="12" class="mt-2" height="10" viewBox="0 0 16 13" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                        stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                <span
                    class="ml-2 text-[10px] sm:text-[12px] md:text-[13px] lg:text-[14px] xl:text-[15px] 2xl:text-[16px]">
                    It is a long established fact that a reader will be.
                </span>
            </li>
            <li class="flex">
                <svg width="12" class="mt-2" height="10" viewBox="0 0 16 13" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                        stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                <span
                    class="ml-2 text-[10px] sm:text-[12px] md:text-[13px] lg:text-[14px] xl:text-[15px] 2xl:text-[16px]">
                    It is a long established fact that a reader will be.
                </span>
            </li>
            <li class="flex">
                <svg width="12" class="mt-2" height="10" viewBox="0 0 16 13" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                        stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                <span
                    class="ml-2 text-[10px] sm:text-[12px] md:text-[13px] lg:text-[14px] xl:text-[15px] 2xl:text-[16px]">
                    It is a long established fact that a reader will be.
                </span>
            </li>
            <li class="flex">
                <svg width="12" class="mt-2" height="10" viewBox="0 0 16 13" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                        stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                <span
                    class="ml-2 text-[10px] sm:text-[12px] md:text-[13px] lg:text-[14px] xl:text-[15px] 2xl:text-[16px]">
                    It is a long established fact that a reader will be.
                </span>
            </li>
        </ul>
    </div>
</div>
