@section('title', 'Edit Category')
<x-app-layout>

    <div class="bg-[#DFDCF3] border border-[#4228E2] overflow-hidden shadow-sm rounded-xl min-h-full">
        <div class="p-6 border-b border-gray-200 overflow-x-auto relative">
            <a href="{{ route('program.index') }}" class="sm:absolute top-[40px]">
                <svg width="20" height="15" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1.81818 7.54545H19M7.54545 1L1 7.54545L7.54545 14.0909" stroke="#6D51E7"
                        stroke-width="1.63636" stroke-linecap="round" stroke-linejoin="round" />
                </svg>

            </a>
            <div class="w-full flex justify-center">
                <div class="w-full max-w-[450px]">
                    <h1 class="text-[36px] font-bold mb-5">
                        Edit Program
                    </h1>
                    <form action="{{ route('program.update', ['program' => $program]) }}" method="post">
                        @csrf
                        @method('PUT')
                        <div class="mb-4">
                            <label for="title">
                                Title
                            </label>
                            <input type="title" placeholder="title" name="title" value="{{ $program->title }}"
                                class="border border-[#482EE3] bg-transparent rounded-lg block w-full mt-1 p-2 focus:ring-[#482EE3] focus:outline-[#482EE3]">
                            @error('title')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>
                        <div class="mb-4">
                            <label for="banner">
                                Banner
                            </label>

                            <div id="banner-drop-area" class="mt-1 text-center">
                                <input type="file" id="banner-input-file" name="banner" hidden accept="image/*" />
                                <div
                                    class="bg-transparent border rounded-lg border-[#4229E2] text-center p-5 w-full py-10">
                                    <div class="flex justify-center">
                                        <svg width="35" height="35" viewBox="0 0 35 35" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M35 17.5C35 16.5335 34.2165 15.75 33.25 15.75C32.2835 15.75 31.5 16.5335 31.5 17.5H35ZM17.5 3.5C18.4665 3.5 19.25 2.7165 19.25 1.75C19.25 0.783501 18.4665 0 17.5 0V3.5ZM30.625 31.5H4.375V35H30.625V31.5ZM3.5 30.625V4.375H0V30.625H3.5ZM31.5 17.5V30.625H35V17.5H31.5ZM4.375 3.5H17.5V0H4.375V3.5ZM4.375 31.5C3.89176 31.5 3.5 31.1083 3.5 30.625H0C0 33.0412 1.95875 35 4.375 35V31.5ZM30.625 35C33.0412 35 35 33.0412 35 30.625H31.5C31.5 31.1083 31.1083 31.5 30.625 31.5V35ZM3.5 4.375C3.5 3.89176 3.89175 3.5 4.375 3.5V0C1.95876 0 0 1.95875 0 4.375H3.5Z"
                                                fill="#4229E2" />
                                            <path
                                                d="M1.75 27.1246L11.1065 18.5479C11.759 17.9496 12.7557 17.933 13.4278 18.5092L24.5 27.9996"
                                                stroke="#4229E2" stroke-width="3.5" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path
                                                d="M21 23.6249L25.1768 19.4481C25.7925 18.8323 26.7675 18.763 27.4642 19.2856L33.25 23.6249"
                                                stroke="#4229E2" stroke-width="3.5" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path d="M28.875 12.25V1.75" stroke="#4229E2" stroke-width="3.5"
                                                stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M24.5 6.125L28.875 1.75L33.25 6.125" stroke="#4229E2"
                                                stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                    <button type="button" id="banner-browse">Upload File</button>
                                </div>
                                <ul id="banner-file-list" class="mt-4 text-sm text-left"></ul>
                            </div>
                            @error('banner')
                                <span class="text-red-500">
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>

                        <table class="w-full mt-5">
                            <thead>
                                <tr class="border-b-2 border-white">
                                    <th class="py-2 text-left">Subscription</th>
                                    <th class="py-2 text-center">Price</th>
                                    <th class="py-2 text-right">Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($program->plans as $plan)
                                    <tr class="border-b border-white">
                                        <td class="text-left py-1 pl-2">{{ $plan->name }}</td>
                                        <td>
                                            <p class="border-[#482EE3] flex justify-center items-center py-1">
                                                <input type="text" name="prices[{{ $plan->id }}]"
                                                    class="price-input text-center bg-transparent border-none rounded w-[70px] p-0 focus:ring-0"
                                                    value="${{ $plan->price }}" />
                                            </p>
                                        </td>
                                        <td>
                                            <div class="flex justify-end pr-2">
                                                <button type="button" data-name="{{ $plan->name }}"
                                                    data-points="{{ $plan->points }}" data-id="{{ $plan->id }}"
                                                    class="add-description border rounded-full border-black text-center h-[20px] w-[20px] flex justify-center items-center">
                                                    +
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                                {{-- <tr class="border-b border-white">
                                    <td class="text-left py-1 pl-2">Monthly</td>
                                    <td>
                                        <p class="border-[#482EE3] flex justify-center items-center py-1">
                                            <input type="text" name="monthly_price"
                                                class="price-input text-center bg-transparent border-none rounded w-[70px] p-0 focus:ring-0"
                                                value="${{$program->}}" />
                                        </p>
                                    </td>
                                    <td>
                                        <div class="flex justify-end pr-2">
                                            <button type="button"
                                                class="add-description border rounded-full border-black text-center h-[20px] w-[20px] flex justify-center items-center">
                                                +
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="border-b border-white">
                                    <td class="text-left py-1 pl-2">Quarterly</td>
                                    <td>
                                        <p class="border-[#482EE3] flex justify-center items-center py-1">
                                            <input type="text" name="quarterly_price"
                                                class="price-input text-center bg-transparent border-none rounded w-[70px] p-0 focus:ring-0"
                                                value="$20" />
                                        </p>
                                    </td>
                                    <td>
                                        <div class="flex justify-end pr-2">
                                            <button type="button"
                                                class="add-description border rounded-full border-black text-center h-[20px] w-[20px] flex justify-center items-center">
                                                +
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="border-b border-white">
                                    <td class="text-left py-1 pl-2">Annually</td>
                                    <td>
                                        <p class="border-[#482EE3] flex justify-center items-center py-1">
                                            <input type="text" name="annually_price"
                                                class="price-input text-center bg-transparent border-none rounded w-[70px] p-0 focus:ring-0"
                                                value="$30" />
                                        </p>
                                    </td>
                                    <td>
                                        <div class="flex justify-end pr-2">
                                            <button type="button"
                                                class="add-description border rounded-full border-black text-center h-[20px] w-[20px] flex justify-center items-center">
                                                +
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="border-b border-white">
                                    <td class="text-left py-1 pl-2">All time</td>
                                    <td>
                                        <p class="border-[#482EE3] flex justify-center items-center py-1">
                                            <input type="text" name="alltime_price"
                                                class="price-input text-center bg-transparent border-none rounded w-[70px] p-0 focus:ring-0"
                                                value="$100" />
                                        </p>
                                    </td>
                                    <td>
                                        <div class="flex justify-end pr-2">
                                            <button type="button"
                                                class="add-description border rounded-full border-black text-center h-[20px] w-[20px] flex justify-center items-center">
                                                +
                                            </button>
                                        </div>
                                    </td>
                                </tr> --}}
                            </tbody>
                        </table>

                        <button
                            class="mt-5 w-full py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[16px] font-semibold hover:bg-indigo-500">
                            Update
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    @push('script')
        <script>
            $('.add-description').click(function(e) {
                e.preventDefault();
                $('#description-modal').removeClass("hidden");
                let planName = $(this).data("name");
                $('#plan-name').text(planName);
                let planPoints = $(this).data("points");
                let planId = $(this).data("id");
                $('#plan-id').val(planId);
                $('#point-id').val(null);
                getPoints(planId)
                // $('#decription-points').empty();

                //     planPoints.forEach(point => {
                //         $('#decription-points').append(`
        // <li class="flex items-center">
        //     <svg width="12" height="10" viewBox="0 0 16 13" fill="none"
        //         xmlns="http://www.w3.org/2000/svg">
        //         <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
        //             stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
        //     </svg>
        //     <span
        //         class="ml-2 text-[12px] md:text-[13px] lg:text-[14px] xl:text-[15px] 2xl:text-[16px]">
        //         ${point.point}
        //     </span>
        // </li>`);
                //     });

                // $('#plan-name').text(planPoints);
            });

            $('.close-modal').click(function(e) {
                e.preventDefault();
                $('#description-modal').addClass('hidden');
            });

            function closeModal() {
                $('#description-modal').addClass('hidden');
            }
            $('.price-input').on("keyup", function() {
                let input = $(this).val();
                let numericInput = input.replace(/[^0-9]/g, '');
                $(this).val("$" + numericInput);
            });





            function setupFileUpload(areaId, inputId, listId, browseBtnId, allowedTypes) {
                const dropArea = document.getElementById(areaId);
                const inputFile = document.getElementById(inputId);
                const fileList = document.getElementById(listId);
                const browseBtn = document.getElementById(browseBtnId);

                dropArea.addEventListener("dragover", e => {
                    e.preventDefault();
                    e.dataTransfer.dropEffect = "copy";
                });

                dropArea.addEventListener("drop", e => {
                    e.preventDefault();
                    handleFiles(e.dataTransfer.files);
                });

                browseBtn.addEventListener("click", () => inputFile.click());

                inputFile.addEventListener("change", e => {
                    if (e.target.files.length) handleFiles(e.target.files);
                });

                function handleFiles(files) {
                    const dataTransfer = new DataTransfer();
                    const filteredFiles = Array.from(files).filter(file =>
                        allowedTypes.includes(file.name.split('.').pop().toLowerCase())
                    );

                    if (!filteredFiles.length) {
                        document.getElementById('image-type-modal').classList.remove('hidden');
                        document.getElementById('heading').innerText = "Invalid File Type";
                        document.getElementById('text').innerHTML = `<b>Allowed Types:</b> ${allowedTypes.join(", ")}`;
                        return;
                    }

                    filteredFiles.forEach(file => dataTransfer.items.add(file));
                    inputFile.files = dataTransfer.files;

                    fileList.innerHTML = filteredFiles.map(file => `<li>${file.name}</li>`).join('');
                }
            }

            setupFileUpload("banner-drop-area", "banner-input-file", "banner-file-list", "banner-browse", ["jpg",
                "jpeg", "png"
            ]);
            setupFileUpload("attachment-drop-area", "attachment-input-file", "attachment-file-list", "attachment-browse", [
                "pdf"
            ]);

            function closeImageTypeModal() {
                document.getElementById('image-type-modal').classList.add('hidden');
            }

            function planPointStore(event) {
                event.preventDefault();

                let form = event.target;
                let fd = new FormData(form);
                let planId = fd.get('plan_id')
                $.ajax({
                    type: "POST",
                    url: "{{ route('plan-point.store') }}",
                    data: fd,
                    headers: {
                        'X-CSRF-TOKEN': "{{ csrf_token() }}"
                    },
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.error) {
                            Toast.fire({
                                icon: "error",
                                title: response.message
                            });
                            return;
                        }
                        getPoints(planId)
                        Toast.fire({
                            icon: "success",
                            title: response.message
                        });
                        $("#point").val(null);
                        $("#point-id").val(null);

                        // closeModal();
                    },
                    error: function(xhr, status, error) {
                        console.error("Error:", error);
                    }
                });
            }

            // const descriptionForm = document.getElementById("description-form");
            // if (descriptionForm) {
            //     descriptionForm.addEventListener("submit", planPointStore);
            // }

            function closeModal() {
                document.getElementById("description-modal").classList.add("hidden");
            }

            function getPoints(planId) {
                $.ajax({
                    type: "GET",
                    url: "{{ route('get-points') }}",
                    data: {
                        planId: planId
                    },
                    success: function(response) {
                        if (response.error) {
                            console.error(response.message);
                            return;
                        }
                        $('#decription-points').empty();
                        let points = response.points;
                        points.forEach(point => {
                            $('#decription-points').append(`
                                <li class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <svg width="12" height="10" viewBox="0 0 16 13" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                                                stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                        <span
                                            class="ml-2 text-[12px] md:text-[13px] lg:text-[14px] xl:text-[15px] 2xl:text-[16px]">
                                            ${point.point}
                                        </span>
                                    </div>
                                    <div>
                                        <button onclick="editPoint(${point.id}, '${point.point}')">
                                            <svg width="20px" height="20px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M21.2799 6.40005L11.7399 15.94C10.7899 16.89 7.96987 17.33 7.33987 16.7C6.70987 16.07 7.13987 13.25 8.08987 12.3L17.6399 2.75002C17.8754 2.49308 18.1605 2.28654 18.4781 2.14284C18.7956 1.99914 19.139 1.92124 19.4875 1.9139C19.8359 1.90657 20.1823 1.96991 20.5056 2.10012C20.8289 2.23033 21.1225 2.42473 21.3686 2.67153C21.6147 2.91833 21.8083 3.21243 21.9376 3.53609C22.0669 3.85976 22.1294 4.20626 22.1211 4.55471C22.1128 4.90316 22.0339 5.24635 21.8894 5.5635C21.7448 5.88065 21.5375 6.16524 21.2799 6.40005V6.40005Z" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M11 4H6C4.93913 4 3.92178 4.42142 3.17163 5.17157C2.42149 5.92172 2 6.93913 2 8V18C2 19.0609 2.42149 20.0783 3.17163 20.8284C3.92178 21.5786 4.93913 22 6 22H17C19.21 22 20 20.2 20 18V13" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                        </button>
                                        <button onclick="deletePoint(${point.id})">
                                            <svg width="20px" height="20px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M4 7H20" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M6 10L7.70141 19.3578C7.87432 20.3088 8.70258 21 9.66915 21H14.3308C15.2974 21 16.1257 20.3087 16.2986 19.3578L18 10" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5V7H9V5Z" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                        </button>
                                    </div>
                                </li>`);
                        });
                    }
                });
            }

            function editPoint(id, text) {
                $('#point-id').val(id);
                $('#point').val(text);
            }

            function deletePoint(id) {
                $('#object').text("point");
                $('#delete-modal').removeClass('hidden');
                $('#delete-modal').addClass('flex');
                let url = "{{ url('point') }}" + "/" + id;
                $("#delete-form").attr('action', url);
                $('#description-modal').addClass('hidden');
            }
        </script>
    @endpush
</x-app-layout>

<div id="description-modal"
    class="hidden z-[100] h-screen w-full bg-black bg-opacity-20 flex justify-center items-center absolute top-0">
    <div class="bg-white rounded-lg w-[90%] sm:max-w-lg  p-5 relative">
        <button type="button" onclick="closeModal()"
            class="close-modal absolute top-[10px] right-[20px] text-slate-500">
            X
        </button>
        <h1 class="text-center text-[22px] underline font-semibold">
            <span id="plan-name">Monthly</span> Subscription
        </h1>

        <form onsubmit="planPointStore(event)" method="post" class="my-4" id="description-form">
            @csrf
            <div class="flex">
                <input type="hidden" name="plan_id" id="plan-id">
                <input type="hidden" name="point_id" id="point-id">
                <input type="text" required name="point" id="point"
                    class="border border-[#482EE3] bg-transparent rounded-lg w-full mt-1 p-2 focus:ring-[#482EE3] focus:outline-[#482EE3]">
                <button
                    class="mt-2 ml-2 w-[100px] py-2 px-4 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[14px] hover:bg-indigo-500">Save</button>
            </div>
        </form>

        <ul class="space-y-5 list-none 2xl:p-5" id="decription-points">
            {{-- <li class="flex">
                <svg width="12" class="mt-2" height="10" viewBox="0 0 16 13" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                        stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                <span
                    class="ml-2 text-[10px] sm:text-[12px] md:text-[13px] lg:text-[14px] xl:text-[15px] 2xl:text-[16px]">
                    It is a long established fact that a reader will be.
                </span>
            </li>
            <li class="flex">
                <svg width="12" class="mt-2" height="10" viewBox="0 0 16 13" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                        stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                <span
                    class="ml-2 text-[10px] sm:text-[12px] md:text-[13px] lg:text-[14px] xl:text-[15px] 2xl:text-[16px]">
                    It is a long established fact that a reader will be.
                </span>
            </li>
            <li class="flex">
                <svg width="12" class="mt-2" height="10" viewBox="0 0 16 13" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                        stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                <span
                    class="ml-2 text-[10px] sm:text-[12px] md:text-[13px] lg:text-[14px] xl:text-[15px] 2xl:text-[16px]">
                    It is a long established fact that a reader will be.
                </span>
            </li>
            <li class="flex">
                <svg width="12" class="mt-2" height="10" viewBox="0 0 16 13" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 8.50006C1 8.50006 2.5 8.50006 4.5 12.0001C4.5 12.0001 10.059 2.83306 15 1.00006"
                        stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                <span
                    class="ml-2 text-[10px] sm:text-[12px] md:text-[13px] lg:text-[14px] xl:text-[15px] 2xl:text-[16px]">
                    It is a long established fact that a reader will be.
                </span>
            </li> --}}
        </ul>
    </div>
</div>
