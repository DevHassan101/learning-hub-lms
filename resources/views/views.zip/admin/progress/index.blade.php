@section('title', 'Progress Tracking & Reporting')
<x-app-layout>
    <x-slot name="header">
        <div class="sm:flex justify-between items-center">
            {{ __('Progress Tracking & Reporting') }}
            <div class="sm:flex">
                <div class="relative max-h-fit flex items-center my-3 sm:my-0">
                    <input type="search" id="searchInput"
                        class="w-full sm:w-[300px] bg-[#DFDCF3] border border-[#4228E2] rounded-lg"
                        placeholder="Search User">
                    <svg width="18" class="absolute right-[10px] top-[10px]" height="20" viewBox="0 0 16 17"
                        fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="7" cy="7" r="6.25" stroke="#6C6C6C" stroke-width="1.5" />
                        <path d="M11 12L15 16" stroke="#6C6C6C" stroke-width="1.5" />
                    </svg>

                </div>
                <a href="#" onclick="printDivAsPDF()"
                    class="sm:ml-4 py-2 px-10 text-center bg-gradient-to-r from-[#442AE2] to-[#6956E7] rounded-xl text-white text-[15px] font-medium hover:bg-indigo-500">
                    Export
                </a>
            </div>
        </div>
    </x-slot>

    <div class="bg-[#DFDCF3] border border-[#4228E2] overflow-hidden shadow-sm rounded-xl min-h-full">
        <div class="p-6 border-b border-gray-200 overflow-x-auto" id="progress-table">
            <table class="min-w-full">
                <thead>
                    <tr>
                        <th class="text-nowrap px-3 text-[17px]">Sr.No</th>
                        <th class="text-nowrap px-3 text-[17px]">Course</th>
                        <th class="text-nowrap px-3 text-[17px]">Enroll Student</th>
                        <th class="text-nowrap px-3 text-[17px]">Quiz Score</th>
                        <th class="text-nowrap px-3 text-[17px]">Exam Score</th>
                    </tr>
                </thead>
                <tbody id="myTable">
                    @forelse ($courses as $i => $course)
                        <tr class="border-b border-[#102935]">
                            <td class="text-[16px] font-regular py-3 text-center">{{ $i + 1 }}</td>
                            <td class="text-[16px] font-regular py-3 text-center">{{ $course->title }}</td>
                            <td class="text-[16px] font-regular py-3 text-center">{{ count($course->enrollments) }}</td>
                            <td class="text-[16px] font-regular py-3 text-center">
                                {{ number_format($course->user_quiz_average, 2) }}
                            </td>
                            <td class="text-[16px] font-regular py-3 text-center">
                                {{ number_format($course->user_exam_average, 2) }}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5">
                                <div class="flex justify-center items-center">
                                    <img class="h-[300px] w-[300px] my-10" src="{{ asset('not-found.png') }}"
                                        alt="">
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="5">
                            {{ $courses->links() }}
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    @push('script')
        <script>
            function paginate(a) {
                let paginate = $(a).val();
                let search = $('#searchInput').val();
                fetchData(1, search, paginate)
            };

            let searchQuery = '';
            $(document).on('click', '#paginationLinks a', function(event) {
                event.preventDefault();

                var page = $(this).attr('href').split('page=')[1];

                fetchData(page, searchQuery);
            });
            $('#searchInput').on('keyup', function() {
                searchQuery = $(this).val();
                console.log(searchQuery);

                fetchData(1, searchQuery); // Always fetch from page 1 when searching
            });

            function fetchData(page, search, paginate = 10) {
                let baseUrl = "{{ url('/progress') }}";
                $.ajax({
                    url: baseUrl + "?page=" + page + "&search=" + search + '&paginate=' + paginate,
                    type: "GET",
                    dataType: "json",
                    success: function(data) {
                        $('#myTable').html(data.table);
                        $('#paginationLinks').html(data.pagination);
                        $('.pagination-paginate').val(paginate);
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                    }
                });
            }

            function printDivAsPDF() {
                let divContent = document.getElementById('progress-table').innerHTML;
                let originalContent = document.body.innerHTML;

                document.body.innerHTML = divContent;
                window.print();
                document.body.innerHTML = originalContent;
            }
        </script>
    @endpush
</x-app-layout>
